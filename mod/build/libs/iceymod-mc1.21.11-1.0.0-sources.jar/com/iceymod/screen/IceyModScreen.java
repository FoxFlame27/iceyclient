package com.iceymod.screen;

import com.iceymod.IceyMod;
import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.compat.Input;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import com.iceymod.compat.Gfx;
import com.iceymod.compat.IceyScreen;

/**
 * The main Icey Client menu, opened with Y.
 * Paginated grid of module toggles with arrow-key navigation.
 */
public class IceyModScreen extends IceyScreen {

    private static HudModule.Category currentFilter = null; // null = ALL
    private static int page = 0;
    private static int selectedIndex = 0;
    // Persisted across rebuilds during typing so the field doesn't lose
    // text when the screen re-inits on each keystroke.
    private static String searchQuery = "";
    private class_342 searchField;
    // Instance field so settings mode resets every time the menu is reopened.
    private boolean settingsMode = false;

    private int gridCols = 4;
    private int gridRows = 5;
    private int perPage = 20;
    private List<HudModule> filtered = new ArrayList<>();
    private final List<class_4185> moduleButtons = new ArrayList<>();

    private static final class_2960 GEAR_TEXTURE = class_2960.method_60655(IceyMod.MOD_ID, "textures/gui/gear.png");
    private int gearX, gearY, gearW, gearH;

    public IceyModScreen() {
        super(class_2561.method_43470(com.iceymod.Branding.name()));
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int sh = this.field_22790;
        moduleButtons.clear();

        // Search bar — between title (y=8) and category filter row (y=44).
        int searchW = 220;
        int searchH = 16;
        searchField = new class_342(this.field_22793, centerX - searchW / 2, 22,
                searchW, searchH, class_2561.method_43470(""));
        searchField.method_1880(32);
        searchField.method_47404(class_2561.method_43470("§7Search modules…"));
        searchField.method_1852(searchQuery);
        searchField.method_1863(s -> {
            if (!s.equals(searchQuery)) {
                searchQuery = s;
                page = 0;
                selectedIndex = 0;
                rebuild();
            }
        });
        method_37063(searchField);
        // If the user is mid-search, the rebuild triggered by typing
        // would otherwise leave focus on nothing — re-grab it.
        if (searchQuery != null && !searchQuery.isEmpty()) {
            method_48265(searchField);
            searchField.method_25365(true);
        }

        // Filter buttons row — pushed below the search bar.
        int filterY = 44;
        int filterBtnW = 64;
        int filterBtnH = 18;
        int filterGap = 4;

        HudModule.Category[] cats = HudModule.Category.values();
        int filterCount = cats.length + 1; // +1 for ALL
        int filterRowW = filterCount * filterBtnW + (filterCount - 1) * filterGap;
        int filterStartX = centerX - filterRowW / 2;

        method_37063(class_4185.method_46430(
                class_2561.method_43470(currentFilter == null ? "\u00A7b\u00A7lALL" : "ALL"),
                btn -> { currentFilter = null; page = 0; selectedIndex = 0; rebuild(); }
        ).method_46434(filterStartX, filterY, filterBtnW, filterBtnH).method_46431());

        for (int i = 0; i < cats.length; i++) {
            HudModule.Category cat = cats[i];
            int x = filterStartX + (i + 1) * (filterBtnW + filterGap);
            String name = cat.name();
            String label = currentFilter == cat ? "\u00A7b\u00A7l" + name : name;
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    btn -> { currentFilter = cat; page = 0; selectedIndex = 0; rebuild(); }
            ).method_46434(x, filterY, filterBtnW, filterBtnH).method_46431());
        }

        // Filter modules: category gate + free-text name search.
        // ALL excludes OPTIMIZATION so it only appears in its own tab.
        String q = searchQuery == null ? "" : searchQuery.toLowerCase().trim();
        List<HudModule> all = HudManager.getModules();
        filtered = new ArrayList<>();
        for (HudModule m : all) {
            boolean catOk = currentFilter == null
                    ? m.getCategory() != HudModule.Category.OPTIMIZATION
                    : m.getCategory() == currentFilter;
            if (!catOk) continue;
            if (!q.isEmpty() && !m.getName().toLowerCase().contains(q)) continue;
            filtered.add(m);
        }

        // Grid sizing — bigger buttons, paginated so they always fit
        int bottomReserved = 80; // pagination + edit + done
        int gridTop = filterY + filterBtnH + 12;
        int availableH = sh - gridTop - bottomReserved;

        int btnW = 128;
        int btnH = 20;
        int gap = 4;

        gridCols = Math.max(2, Math.min(5, (this.field_22789 - 40) / (btnW + gap)));
        // Only as many rows as actually fit above the footer buttons — a
        // forced minimum of 3 rows overlapped the pagination row at large
        // GUI scales.
        gridRows = Math.max(1, availableH / (btnH + gap));
        perPage = gridCols * gridRows;

        int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        if (selectedIndex >= filtered.size()) selectedIndex = Math.max(0, filtered.size() - 1);

        int startIdx = page * perPage;
        int endIdx = Math.min(filtered.size(), startIdx + perPage);

        int gridW = gridCols * btnW + (gridCols - 1) * gap;
        int startX = centerX - gridW / 2;

        for (int i = startIdx; i < endIdx; i++) {
            final HudModule module = filtered.get(i);
            int rel = i - startIdx;
            int col = rel % gridCols;
            int row = rel / gridCols;
            int x = startX + col * (btnW + gap);
            int y = gridTop + row * (btnH + gap);

            final int thisIdx = i;
            class_4185 btn = class_4185.method_46430(
                    getModuleText(module, thisIdx == selectedIndex),
                    b -> {
                        selectedIndex = thisIdx;
                        if (settingsMode) {
                            com.iceymod.compat.MC.setScreen(field_22787, new ModuleSettingsScreen(module, this));
                        } else {
                            module.toggle();
                            b.method_25355(getModuleText(module, true));
                        }
                    }
            ).method_46434(x, y, btnW, btnH).method_46431();
            method_37063(btn);
            moduleButtons.add(btn);
        }

        // Gear icon (settings mode toggle) — top-right corner, renders as a texture
        gearW = 28;
        gearH = 28;
        gearX = this.field_22789 - gearW - 10;
        gearY = 10;
        class_4185 gear = class_4185.method_46430(
                class_2561.method_43470(""),
                b -> { settingsMode = !settingsMode; rebuild(); }
        ).method_46434(gearX, gearY, gearW, gearH).method_46431();
        method_37063(gear);

        // Pagination row
        int paginationY = sh - bottomReserved + 4;
        int pagBtnW = 80;
        int pagBtnH = 20;
        int pagGap = 6;

        boolean canPrev = page > 0;
        boolean canNext = page < totalPages - 1;

        class_4185 lessBtn = class_4185.method_46430(
                class_2561.method_43470(canPrev ? "\u00A7b\u25C0 Less" : "\u00A78\u25C0 Less"),
                btn -> { if (page > 0) { page--; selectedIndex = page * perPage; rebuild(); } }
        ).method_46434(centerX - pagBtnW - pagGap - 50, paginationY, pagBtnW, pagBtnH).method_46431();
        lessBtn.field_22763 = canPrev;
        method_37063(lessBtn);

        method_37063(class_4185.method_46430(
                class_2561.method_43470("\u00A77" + (page + 1) + "/" + totalPages),
                btn -> {}
        ).method_46434(centerX - 40, paginationY, 80, pagBtnH).method_46431());

        class_4185 moreBtn = class_4185.method_46430(
                class_2561.method_43470(canNext ? "\u00A7bMore \u25B6" : "\u00A78More \u25B6"),
                btn -> { if (page < totalPages - 1) { page++; selectedIndex = page * perPage; rebuild(); } }
        ).method_46434(centerX + 50 + pagGap, paginationY, pagBtnW, pagBtnH).method_46431();
        moreBtn.field_22763 = canNext;
        method_37063(moreBtn);

        // Bottom buttons
        int bottomBtnY = sh - 54;
        method_37063(class_4185.method_46430(
                class_2561.method_43470("\u2699 Edit HUD Layout"),
                btn -> com.iceymod.compat.MC.setScreen(field_22787, new HudEditScreen(this))
        ).method_46434(centerX - 110, bottomBtnY, 108, 22).method_46431());

        // Switch to the glass panel menu (also selectable in the launcher).
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Panel Menu"),
                btn -> {
                    HudManager.save();
                    com.iceymod.MenuPrefs.setStyle(com.iceymod.MenuPrefs.STYLE_PANELS);
                    com.iceymod.compat.MC.setScreen(field_22787, new PanelMenuScreen());
                }
        ).method_46434(centerX + 2, bottomBtnY, 108, 22).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.done"),
                btn -> method_25419()
        ).method_46434(centerX - 110, bottomBtnY + 26, 220, 22).method_46431());
    }

    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    private class_2561 getModuleText(HudModule module, boolean selected) {
        String prefix = selected ? "\u00A7b\u00BB \u00A7r" : "";
        if (settingsMode) {
            // No icons, no on/off suffix — the top-right gear already tells
            // you you're in settings mode. Just the clean module name.
            return class_2561.method_43470(prefix + module.getName());
        }
        String state = module.isEnabled() ? "\u00A7aON" : "\u00A7cOFF";
        return class_2561.method_43470(prefix + module.getName() + ": " + state);
    }

    // GLFW key polling: 1.21.11 changed Screen.keyPressed's signature to
    // take a KeyInput object, so our (int, int, int) override stops
    // overriding anything at runtime → arrow-key navigation silently
    // dies. We poll inside render() instead — works on both 1.21.8 and
    // 1.21.11 (Input.keyDown hides how each version reads the key state).
    private final java.util.HashMap<Integer, Boolean> prevKeyState = new java.util.HashMap<>();

    private boolean keyEdge(int keyCode) {
        try {
            boolean down = Input.keyDown(keyCode);
            boolean wasDown = prevKeyState.getOrDefault(keyCode, false);
            prevKeyState.put(keyCode, down);
            return down && !wasDown;
        } catch (Throwable t) { return false; }
    }

    private void pollNavigationKeys() {
        if (filtered.isEmpty()) return;
        // Skip nav-key polling when the search field is focused so
        // typing arrow keys / Enter / Space don't double-fire as
        // grid navigation while the user is editing the query.
        if (searchField != null && searchField.method_25370()) return;
        int startIdx = page * perPage;
        int localIdx = selectedIndex - startIdx;

        if (keyEdge(class_3675.field_31932)) {
            int next = selectedIndex - gridCols;
            if (next < 0) next = selectedIndex;
            moveSelection(next);
        }
        if (keyEdge(class_3675.field_31982)) {
            int next = selectedIndex + gridCols;
            if (next >= filtered.size()) next = selectedIndex;
            moveSelection(next);
        }
        if (keyEdge(class_3675.field_31983)) {
            if (localIdx > 0 && selectedIndex > 0) {
                moveSelection(selectedIndex - 1);
            } else if (page > 0) {
                page--;
                selectedIndex = Math.min(page * perPage + perPage - 1, filtered.size() - 1);
                rebuild();
            }
        }
        if (keyEdge(class_3675.field_31984)) {
            if (selectedIndex < filtered.size() - 1) moveSelection(selectedIndex + 1);
        }
        if (keyEdge(class_3675.field_31957) || keyEdge(class_3675.field_31947)) {
            if (selectedIndex >= 0 && selectedIndex < filtered.size()) {
                HudModule m = filtered.get(selectedIndex);
                if (settingsMode) {
                    com.iceymod.compat.MC.setScreen(field_22787, new ModuleSettingsScreen(m, this));
                } else {
                    m.toggle();
                    rebuild();
                }
            }
        }
        if (keyEdge(class_3675.field_31991)) {
            int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
            if (page < totalPages - 1) { page++; selectedIndex = page * perPage; rebuild(); }
        }
        if (keyEdge(class_3675.field_31992)) {
            if (page > 0) { page--; selectedIndex = page * perPage; rebuild(); }
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
        if (verticalAmount < 0 && page < totalPages - 1) {
            page++; selectedIndex = page * perPage; rebuild();
            return true;
        }
        if (verticalAmount > 0 && page > 0) {
            page--; selectedIndex = page * perPage; rebuild();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void moveSelection(int newIdx) {
        if (newIdx < 0 || newIdx >= filtered.size()) return;
        int newPage = newIdx / perPage;
        selectedIndex = newIdx;
        if (newPage != page) {
            page = newPage;
            rebuild();
        } else {
            // just refresh labels
            int startIdx = page * perPage;
            for (int i = 0; i < moduleButtons.size(); i++) {
                HudModule m = filtered.get(startIdx + i);
                moduleButtons.get(i).method_25355(getModuleText(m, startIdx + i == selectedIndex));
            }
        }
    }

    @Override
    protected void renderScreenBackground(Gfx context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.field_22789, this.field_22790, 0xC0101010);
    }

    @Override
    protected void renderScreen(Gfx context, int mouseX, int mouseY, float delta) {
        try { pollNavigationKeys(); } catch (Throwable ignored) {}
        superRender(context, mouseX, mouseY, delta);

        context.drawCenteredString(this.field_22793,
                com.iceymod.Branding.colorCode() + com.iceymod.Branding.name() + " \u00A77" + HudManager.getModules().size() + " modules",
                this.field_22789 / 2, 10, 0xFFFFFFFF);

        // Gear icon texture on top of the invisible button
        context.blit(
                GEAR_TEXTURE,
                gearX, gearY,
                0f, 0f,
                gearW, gearH,
                gearW, gearH
        );
        // Clear ON/OFF label directly below the gear
        String state = settingsMode ? "\u00A7aON" : "\u00A77OFF";
        context.drawCenteredString(this.field_22793, state,
                gearX + gearW / 2, gearY + gearH + 3, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        HudManager.save();
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
