package com.iceymod.screen;

import com.iceymod.compat.Gfx;
import com.iceymod.compat.IceyScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;

/**
 * iceymod+ leaderboard picker — one button per server-side category,
 * paginated (8 per page) so 16 entries don't crowd a single screen. Each
 * button dispatches {@code /leaderboard <id>} via the chat-command sender
 * and closes.
 *
 * <p>The category list is hardcoded against the server's known IDs so we
 * don't need a client/server packet protocol — iceymod stays useful on
 * vanilla servers (the command simply fails with "unknown command" if
 * iceymod+ isn't installed).
 */
public final class LeaderboardScreen extends IceyScreen {

    private static final Entry[] ENTRIES = new Entry[] {
            new Entry("mining",      "§b⛏ Mining",        "Haste"),
            new Entry("pvp",         "§c⚔ PvP",            "Strength"),
            new Entry("playtime",    "§e⏱ Playtime",       "Saturation"),
            new Entry("fishing",     "§b🎣 Fishing",       "Luck"),
            new Entry("walking",     "§a👟 Distance",      "Speed"),
            new Entry("jumps",       "§e⤴ Jumps",          "Jump Boost"),
            new Entry("water",       "§9~ Water Movement", "Dolphin's Grace"),
            new Entry("dmgtaken",    "§4❤ Damage Taken",   "Resistance"),
    };

    private static final int PER_PAGE = 8;
    private int page = 0;

    public LeaderboardScreen() {
        super(class_2561.method_43470("Icey SMP Leaderboard"));
    }

    private int pageCount() {
        return (ENTRIES.length + PER_PAGE - 1) / PER_PAGE;
    }

    @Override
    protected void method_25426() {
        int cols = 2;
        int btnW = 220;
        int btnH = 24;
        int gap = 6;
        int rowsPerPage = PER_PAGE / cols;
        int gridW = cols * btnW + (cols - 1) * gap;
        int gridH = rowsPerPage * btnH + (rowsPerPage - 1) * gap;
        int startX = this.field_22789 / 2 - gridW / 2;
        int startY = this.field_22790 / 2 - gridH / 2 - 8;

        int from = page * PER_PAGE;
        int to = Math.min(ENTRIES.length, from + PER_PAGE);
        for (int i = from; i < to; i++) {
            final Entry e = ENTRIES[i];
            int local = i - from;
            int col = local % cols;
            int row = local / cols;
            int x = startX + col * (btnW + gap);
            int y = startY + row * (btnH + gap);
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(e.label + " §7→ " + e.effect),
                    b -> {
                        try {
                            if (field_22787 != null && field_22787.field_1724 != null) {
                                field_22787.field_1724.field_3944.method_45730("leaderboard " + e.id);
                            }
                        } catch (Throwable ignored) {}
                        this.method_25419();
                    }
            ).method_46434(x, y, btnW, btnH).method_46431());
        }

        int navY = startY + gridH + 12;
        int navBtnW = 80;
        int navGap = 8;

        class_4185 prev = class_4185.method_46430(
                class_2561.method_43470("§7◀ Prev"),
                b -> { if (page > 0) { page--; rebuild(); } }
        ).method_46434(this.field_22789 / 2 - navBtnW - navGap - 50, navY, navBtnW, 20).method_46431();
        prev.field_22763 = page > 0;
        method_37063(prev);

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.cancel"),
                b -> this.method_25419()
        ).method_46434(this.field_22789 / 2 - 50, navY, 100, 20).method_46431());

        class_4185 next = class_4185.method_46430(
                class_2561.method_43470("Next §7▶"),
                b -> { if (page < pageCount() - 1) { page++; rebuild(); } }
        ).method_46434(this.field_22789 / 2 + 50 + navGap, navY, navBtnW, 20).method_46431();
        next.field_22763 = page < pageCount() - 1;
        method_37063(next);
    }

    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    @Override
    protected void renderScreenBackground(Gfx context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.field_22789, this.field_22790, 0xC0101010);
    }

    @Override
    protected void renderScreen(Gfx context, int mouseX, int mouseY, float delta) {
        superRender(context, mouseX, mouseY, delta);
        context.drawCenteredString(this.field_22793,
                "§b§lLeaderboard",
                this.field_22789 / 2, 20, 0xFFFFFFFF);
        context.drawCenteredString(this.field_22793,
                "§7Page §f" + (page + 1) + "§7 of §f" + pageCount()
                + " §8· §7requires §biceymod+§7 on the server",
                this.field_22789 / 2, 34, 0xFFAAAAAA);
    }

    private record Entry(String id, String label, String effect) {}
}
