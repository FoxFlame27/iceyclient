package com.iceymod.cape;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Loads the user-uploaded cape PNG from
 * {@code <gameDir>/config/iceyclient/cape.png} and exposes it as a
 * registered Minecraft texture identifier the
 * {@link com.iceymod.mixin.AbstractClientPlayerEntityMixin} can swap
 * into the local player's PlayerSkin.
 *
 * <h2>Why this exists</h2>
 * The launcher's "drop a PNG" UI writes the cape to a known path on
 * every installation's game dir; this class is the in-game half that
 * actually turns that file into a renderable cape texture. The
 * Mojang asset cache at {@code .minecraft/assets/skins} is keyed by
 * SHA-1 hashes — files there with arbitrary names are ignored. To
 * actually show a custom cape on the local player we have to load
 * the PNG ourselves, register it with the TextureManager, and inject
 * its Identifier into {@code AbstractClientPlayerEntity
 * .getSkinTextures()} for the local player only.
 *
 * <h2>Lifecycle</h2>
 * Lazily initialised on first call to {@link #getCapeIdentifier()}.
 * If the file is missing or fails to decode, returns null and the
 * mixin falls through to the original cape (Mojang's, or nothing).
 * mtimestamp is re-checked on each call so dropping a new PNG into
 * the config folder while MC is running picks up after a few seconds
 * of cache TTL without needing a restart.
 */
public final class CapeLoader {

    /** Registered texture identifier — namespaced under iceymod. */
    private static final class_2960 CAPE_ID = class_2960.method_60655("iceymod", "local_cape");
    /** Re-check the file every 3 seconds so the user can hot-swap. */
    private static final long FILE_CHECK_INTERVAL_MS = 3000L;

    private static final AtomicReference<class_2960> CACHED = new AtomicReference<>();
    private static long lastFileCheck = 0L;
    private static long lastFileMtime = 0L;
    private static boolean noCapeReported = false;
    private static boolean debugLogged = false;

    private CapeLoader() {}

    /**
     * Returns the registered identifier for the user's custom cape
     * texture, or {@code null} if no cape PNG is present / loadable.
     * Caller is responsible for limiting this to the local player.
     */
    public static class_2960 getCapeIdentifier() {
        long now = System.currentTimeMillis();
        if (now - lastFileCheck < FILE_CHECK_INTERVAL_MS) {
            return CACHED.get();
        }
        lastFileCheck = now;

        Path capePath = capeFilePath();
        boolean exists = capePath != null && Files.isRegularFile(capePath);
        if (!debugLogged) {
            System.out.println("[IceyMod] CapeLoader.getCapeIdentifier: path=" + capePath + " exists=" + exists);
            debugLogged = true;
        }
        if (!exists) {
            if (CACHED.get() != null) {
                // File deleted while running — clear cache.
                CACHED.set(null);
            }
            return null;
        }

        long mtime;
        try {
            mtime = Files.getLastModifiedTime(capePath).toMillis();
        } catch (Exception e) {
            return CACHED.get();
        }

        if (mtime == lastFileMtime && CACHED.get() != null) {
            return CACHED.get();
        }
        lastFileMtime = mtime;

        class_2960 loaded = loadAndRegister(capePath);
        CACHED.set(loaded);
        return loaded;
    }

    /** Path to {@code <gameDir>/config/iceyclient/cape.png}, or null
     *  if Fabric loader isn't available. */
    private static Path capeFilePath() {
        try {
            Path gameDir = FabricLoader.getInstance().getGameDir();
            return gameDir.resolve("config").resolve("iceyclient").resolve("cape.png");
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Read the PNG bytes off disk, decode via NativeImage, register
     * with the TextureManager under {@link #CAPE_ID}, and return the
     * identifier. Returns null on any failure.
     *
     * <p>Must run on the render thread — {@link
     * net.minecraft.class_310#method_1531()} +
     * {@code registerTexture} aren't thread-safe. Callers come from
     * the mixin path which fires during render, so this is fine.
     */
    private static class_2960 loadAndRegister(Path capePath) {
        try {
            byte[] bytes = Files.readAllBytes(capePath);
            class_1011 img;
            try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
                img = class_1011.method_4309(in);
            }
            // 1.21.10+ removed the single-arg (NativeImage) ctor —
            // it now requires a name supplier first (used by the
            // texture manager for debug labels / leak diagnostics).
            // The Supplier<String> form is stable on both 1.21.8 and
            // 1.21.11 so the same source compiles for both matrix
            // jars.
            Supplier<String> labelSupplier = () -> "iceymod_local_cape";
            class_1043 tex = new class_1043(labelSupplier, img);
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.method_1531() == null) return null;
            mc.method_1531().method_4616(CAPE_ID, tex);
            if (!noCapeReported) {
                System.out.println("[IceyMod] CapeLoader: registered custom cape from " + capePath);
            }
            noCapeReported = true;
            return CAPE_ID;
        } catch (Throwable t) {
            System.out.println("[IceyMod] CapeLoader: failed to load " + capePath + ": " + t);
            return null;
        }
    }
}
