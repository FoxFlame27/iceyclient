package com.iceymod;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.FreecamModule;
import com.iceymod.hud.modules.FreelookModule;
import com.iceymod.hud.modules.PerspectiveModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.modules.WaypointsModule;
import com.iceymod.hud.modules.ZoomModule;
import com.iceymod.screen.IceyModScreen;
import com.iceymod.screen.LeaderboardScreen;
import com.iceymod.screen.PanelMenuScreen;
import com.iceymod.screen.StructureMenuScreen;
import com.iceymod.screen.WaypointMenuScreen;
import com.iceymod.structure.StructureTracker;
import com.iceymod.structure.BiomeTracker;
import com.iceymod.screen.BiomeMenuScreen;
import com.iceymod.chat.ChatCoordParser;
import com.iceymod.render.WaypointBeamRenderer;
import com.iceymod.render.HitboxRenderer;
import com.iceymod.hud.IceyBadgeHud;
import com.iceymod.compat.KeyBindingCompat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.iceymod.compat.Chat;
import com.iceymod.compat.ClientCmd;
import com.iceymod.compat.HudHook;
import com.iceymod.compat.KeyRegistrar;
import com.iceymod.compat.ScreenHook;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import com.iceymod.compat.Input;

public class IceyMod implements ClientModInitializer {
    public static final String MOD_ID = "iceymod";
    public static final class_2960 LOGO_TEXTURE = class_2960.method_60655(MOD_ID, "textures/gui/logo.png");
    public static final String KEY_CATEGORY = "key.categories.iceymod";

    private static class_304 menuKey;
    private static class_304 zoomKey;
    private static class_304 perspectiveKey;
    private static class_304 waypointKey;
    private static class_304 hideHudKey;
    private static class_304 toggleSprintKey;
    private static class_304 toggleBrightKey;
    private static class_304 toggleTotemKey;
    private static class_304 freelookKey;
    private static class_304 copyCoordsKey;
    private static class_304 structureKey;
    private static class_304 freecamKey;
    private static class_304 biomeKey;
    private static class_304 leaderboardKey;
    private static class_304 javaStuffKey;

    @Override
    public void onInitializeClient() {
        // Startup banner so the test log unambiguously shows which build
        // is loaded — the iceymod jar is a single 1.0.0 across versions
        // so we hardcode a build tag here that bumps every release.
        System.out.println("[IceyMod] booted (build tag: v1.86.91)");
        // Each setup call is independently caught so a single failure (e.g.
        // a new MC version having renamed a class one of our modules
        // references) doesn't take the whole mod down — partial Icey >
        // entirely-broken Icey.
        try { HudManager.init(); }            catch (Throwable t) { System.out.println("[IceyMod] HudManager.init failed: " + t); }
        try { IceyBadgeHud.register(); }      catch (Throwable t) { System.out.println("[IceyMod] IceyBadgeHud.register failed: " + t); }
        try { WaypointManager.init(); }        catch (Throwable t) { System.out.println("[IceyMod] WaypointManager.init failed: " + t); }
        try { WaypointBeamRenderer.register(); } catch (Throwable t) { System.out.println("[IceyMod] WaypointBeamRenderer failed: " + t); }
        try { HitboxRenderer.register(); }     catch (Throwable t) { System.out.println("[IceyMod] HitboxRenderer failed: " + t); }
        // Health HUD now handled by the bundled HealthIndicators mod
        // (auto-installed by the launcher alongside iceymod).
        try { StructureTracker.register(); }   catch (Throwable t) { System.out.println("[IceyMod] StructureTracker failed: " + t); }
        try { BiomeTracker.register(); }       catch (Throwable t) { System.out.println("[IceyMod] BiomeTracker failed: " + t); }
        try { ChatCoordParser.register(); }    catch (Throwable t) { System.out.println("[IceyMod] ChatCoordParser failed: " + t); }

        menuKey         = registerKey("key.iceymod.menu",         class_3675.field_31914);
        zoomKey         = registerKey("key.iceymod.zoom",         class_3675.field_32027);
        perspectiveKey  = registerKey("key.iceymod.perspective",  class_3675.field_31907);
        waypointKey     = registerKey("key.iceymod.waypoint",     class_3675.field_32016);
        hideHudKey      = registerKey("key.iceymod.hidehud",      class_3675.field_32022);
        // N moved to leaderboard; user can rebind autosprint via Controls if they want.
        toggleSprintKey = registerKey("key.iceymod.togglesprint", class_3675.field_16237.method_1444());
        toggleBrightKey = registerKey("key.iceymod.togglebright", class_3675.field_32021);
        toggleTotemKey  = registerKey("key.iceymod.toggletotem",  class_3675.field_31909);
        freelookKey     = registerKey("key.iceymod.freelook",     class_3675.field_31949);
        copyCoordsKey   = registerKey("key.iceymod.copycoords",   class_3675.field_32024);
        structureKey    = registerKey("key.iceymod.structure",    class_3675.field_31911);
        freecamKey      = registerKey("key.iceymod.freecam",      class_3675.field_31919);
        biomeKey        = registerKey("key.iceymod.biome",        class_3675.field_32025);
        // Fresh keybind id ("openboard" instead of "leaderboard") so MC
        // doesn't fall back to a stale `;` binding saved in older options.txt.
        leaderboardKey  = registerKey("key.iceymod.openboard",    class_3675.field_32028);
        javaStuffKey    = registerKey("key.iceymod.javastuff",    class_3675.field_31910);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (wasPressed(menuKey)) {
                if (com.iceymod.compat.MC.screen(client) == null) {
                    com.iceymod.compat.MC.setScreen(client,
                            MenuPrefs.isPanels() ? new PanelMenuScreen() : new IceyModScreen());
                }
            }
            while (wasPressed(perspectiveKey)) {
                HudModule pm = findModule("perspective");
                if (pm instanceof PerspectiveModule) {
                    ((PerspectiveModule) pm).cyclePerspective();
                }
            }
            while (wasPressed(waypointKey)) {
                if (com.iceymod.compat.MC.screen(client) == null) {
                    com.iceymod.compat.MC.setScreen(client, new WaypointMenuScreen());
                }
            }
            while (wasPressed(structureKey)) {
                if (com.iceymod.compat.MC.screen(client) == null) {
                    com.iceymod.compat.MC.setScreen(client, new StructureMenuScreen());
                }
            }
            while (wasPressed(biomeKey)) {
                if (com.iceymod.compat.MC.screen(client) == null) {
                    com.iceymod.compat.MC.setScreen(client, new BiomeMenuScreen());
                }
            }
            while (wasPressed(javaStuffKey)) {
                try { JavaStuffToggle.toggle(client); } catch (Throwable t) { System.out.println("[IceyMod] Java & Stuff toggle failed: " + t); }
            }
            while (wasPressed(leaderboardKey)) {
                // Send /leaderboard to the server so it opens the
                // server-side chest GUI (which has live data + clickable
                // category drill-down). Falls back to the client-side
                // LeaderboardScreen on vanilla servers without iceymod+
                // — the client gets "unknown command" but no harm done.
                if (client.field_1724 != null && com.iceymod.compat.MC.screen(client) == null) {
                    try {
                        client.field_1724.field_3944.method_45730("leaderboard");
                    } catch (Throwable ignored) {}
                }
            }
            while (wasPressed(freecamKey)) {
                HudModule fc = findModule("freecam");
                if (fc instanceof FreecamModule fcm) {
                    fcm.toggle(client);
                }
            }
            while (wasPressed(hideHudKey)) {
                HudManager.toggleHudVisibility();
            }
            while (wasPressed(toggleSprintKey)) {
                HudModule m = findModule("autosprint");
                if (m != null) m.toggle();
            }
            while (wasPressed(toggleBrightKey)) {
                HudModule m = findModule("fullbright");
                if (m != null) m.toggle();
            }
            while (wasPressed(toggleTotemKey)) {
                HudModule m = findModule("autototem");
                if (m != null) m.toggle();
            }

            // Zoom: hold key
            HudModule zm = findModule("zoom");
            if (zm instanceof ZoomModule) {
                ((ZoomModule) zm).setZooming(isPressed(zoomKey));
            }

            // Freelook: hold key — camera rotates while character keeps facing forward
            HudModule fl = findModule("freelook");
            if (fl instanceof FreelookModule flm) {
                boolean shouldBeActive = fl.isEnabled() && isPressed(freelookKey);
                if (shouldBeActive && !FreelookModule.isActive()) {
                    flm.start(client);
                    if (client.field_1724 != null) {
                        com.iceymod.compat.Chat.message(net.minecraft.class_2561.method_43470("§b[Icey] §aFreelook ON"), true);
                    }
                } else if (!shouldBeActive && FreelookModule.isActive()) {
                    flm.stop(client);
                    if (client.field_1724 != null) {
                        com.iceymod.compat.Chat.message(net.minecraft.class_2561.method_43470("§b[Icey] §7Freelook off"), true);
                    }
                }
            }

            // Copy coords to clipboard on key press
            while (wasPressed(copyCoordsKey)) {
                if (client.field_1724 != null) {
                    int x = (int) Math.floor(client.field_1724.method_23317());
                    int y = (int) Math.floor(client.field_1724.method_23318());
                    int z = (int) Math.floor(client.field_1724.method_23321());
                    String coords = x + ", " + y + ", " + z;
                    client.field_1774.method_1455(coords);
                    com.iceymod.compat.Chat.message(
                            net.minecraft.class_2561.method_43470("\u00A7b[Icey] \u00A7rCopied \u00A7a" + coords),
                            true); // actionBar overlay — doesn't spam chat
                }
            }

            HudManager.tick();
        });

        HudHook.register("hud", (g, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && (com.iceymod.compat.MC.screen(client) == null
                    || com.iceymod.compat.MC.screen(client) instanceof net.minecraft.class_408)) {
                HudManager.render(g);
            }
        });

        // Client-side commands: /iceyhuds resets the HUD module state
        // (force visible, reset positions, re-enable modules that the
        // auto-disable-on-error logic killed in older builds).
        // (/lb removed in v1.84.7 per user — only /leaderboard now.
        // Keybind N sends /leaderboard to the server to open the
        // server-side chest GUI.)
        try {
            ClientCmd.onRegister(dispatcher -> {
                dispatcher.register(ClientCmd.literal("iceyhuds")
                    .executes(ctx -> {
                        if (!HudManager.isHudVisible()) HudManager.toggleHudVisibility();
                        HudManager.resetAllToDefaults();
                        ctx.getSource().sendFeedback(net.minecraft.class_2561.method_43470(
                                "§b[IceyMod] §aHUDs reset — visible + defaults restored. Open Y menu to reposition."));
                        return 1;
                    }));
            });
        } catch (Throwable t) {
            System.out.println("[IceyMod] Client command registration failed: " + t);
        }

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            // Title screen: no extra corner logo — the Icey Client logo is already drawn
            // in place of the vanilla MINECRAFT logo by LogoDrawerMixin.

            if (screen instanceof class_465) {
                ScreenHook.afterRender(screen, (ctx, mouseX, mouseY, delta) -> {
                    final net.minecraft.class_437 scr = screen;
                    // Skip brewing stands — tight layout, text overlaps the window
                    if (scr instanceof net.minecraft.class_472) return;
                    // Skip double chests — taller window pushes the text too far down
                    if (scr instanceof net.minecraft.class_476 gcs
                            && gcs.method_17577().method_17388() == 6) return;

                    int sw = client.method_22683().method_4486();
                    int windowTop = (scr.field_22790 - 166) / 2;
                    int y = Math.max(2, windowTop - 14);
                    ctx.drawCenteredString(
                            client.field_1772,
                            net.minecraft.class_2561.method_43470(Branding.colorCode() + Branding.name()),
                            sw / 2, y,
                            0xFFFFFFFF
                    );
                });
            }
        });
    }

    private static HudModule findModule(String id) {
        for (HudModule m : HudManager.getModules()) {
            if (m.getId().equals(id)) return m;
        }
        return null;
    }

    /**
     * Register a key via the compat helper so versions that removed the
     * (String, Type, int, String) KeyBinding constructor don't crash the mod.
     * Returns null if registration fails — all call sites null-check.
     */
    private static class_304 registerKey(String translationKey, int code) {
        try {
            class_304 kb = KeyBindingCompat.create(translationKey, Input.KEYBOARD, code, KEY_CATEGORY);
            if (kb == null) return null;
            return KeyRegistrar.register(kb);
        } catch (Throwable t) {
            System.out.println("[IceyMod] Failed to register key " + translationKey + ": " + t.getMessage());
            return null;
        }
    }

    private static boolean wasPressed(class_304 kb) {
        if (kb == null) return false;
        try { return kb.method_1436(); } catch (Throwable t) { return false; }
    }

    private static boolean isPressed(class_304 kb) {
        if (kb == null) return false;
        try { return kb.method_1434(); } catch (Throwable t) { return false; }
    }
}
