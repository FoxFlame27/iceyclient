package com.iceymod.render;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.modules.WaypointsModule;
import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_822;

/**
 * Renders each waypoint as a beacon-style vertical beam plus a billboarded
 * "name • 42m" tag floating above it. The beam geometry is a port of the
 * vanilla beacon renderer (the vertex layout is identical on every version;
 * only how vertices reach the GPU differs, which WorldRenderHook hides).
 */
public class WaypointBeamRenderer {

    public static void register() {
        if (!WorldRenderHook.registerAfterTranslucent(WaypointBeamRenderer::onRender)) {
            System.out.println("[IceyMod] WorldRenderEvents unavailable — waypoint beams disabled");
        }
    }

    private static boolean beamsEnabled() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof WaypointsModule) return m.isEnabled();
        }
        return false;
    }

    private static boolean layerWarned;

    private static void onRender(WorldRenderHook.Ctx ctx) {
        if (!beamsEnabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        List<WaypointManager.Waypoint> wps = WaypointManager.getWaypoints();
        if (wps.isEmpty()) return;

        class_4184 cam = ctx.camera();
        class_243 camPos = com.iceymod.Compat.cameraPos(cam);
        class_4587 ms = ctx.poseStack();
        if (ms == null) return;
        long worldTime = client.field_1687.method_75260();
        float tickDelta = ctx.tickDelta();
        class_243 playerPos = com.iceymod.Compat.entityPos(client.field_1724);

        class_1921 inner = ctx.beaconBeam(class_822.field_4338, false);
        class_1921 outer = ctx.beaconBeam(class_822.field_4338, true);
        if (inner == null || outer == null) {
            if (!layerWarned) { layerWarned = true; System.out.println("[IceyMod] beacon beam RenderType unavailable — waypoint beams disabled"); }
            return;
        }

        for (WaypointManager.Waypoint wp : wps) {
            // --- Beam ---
            ms.method_22903();
            ms.method_22904(wp.x + 0.5 - camPos.field_1352, -64 - camPos.field_1351, wp.z + 0.5 - camPos.field_1350);
            drawBeam(ctx, ms, inner, outer, tickDelta, worldTime, class_822.field_32822, wp.color, 0.2f, 0.25f);
            ms.method_22909();

            // --- Floating name + distance tag ---
            try {
                double dx = (wp.x + 0.5) - playerPos.field_1352;
                double dy = wp.y - playerPos.field_1351;
                double dz = (wp.z + 0.5) - playerPos.field_1350;
                int distance = (int) Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz));
                double tagX = wp.x + 0.5;
                double tagY = Math.max(playerPos.field_1351 + 20.0, wp.y + 3.0);
                double tagZ = wp.z + 0.5;
                String colored = toChatColor(wp.color) + wp.name + " §7• §f" + distance + "m";
                int cw = client.field_1772.method_1727(colored);

                ms.method_22903();
                ms.method_22904(tagX - camPos.field_1352, tagY - camPos.field_1351, tagZ - camPos.field_1350);
                ms.method_34425(new org.joml.Matrix4f().rotation(cam.method_23767()));   // billboard; mulPose(Quaternion) went away in 26.3
                float scale = 0.03f;
                ms.method_22905(-scale, -scale, scale);         // text is huge by default; flip so it reads upright
                ms.method_46416(-cw / 2f, 0f, 0f);
                ctx.worldText(class_2561.method_43470(colored), true, 0xFFFFFFFF, 0x66000000);
                ms.method_22909();
            } catch (Throwable ignored) {}
        }
    }

    /** Port of vanilla BeaconRenderer.renderBeaconBeam minus its own 0.5 translate (caller centres on the block). */
    private static void drawBeam(WorldRenderHook.Ctx ctx, class_4587 ms, class_1921 inner, class_1921 outer,
                                 float tickDelta, long worldTime, int maxY, int color, float innerRadius, float outerRadius) {
        int yOffset = 0;
        int endY = yOffset + maxY;
        float time = (float) Math.floorMod(worldTime, 40L) + tickDelta;
        float rot = maxY < 0 ? time : -time;
        float frac = class_3532.method_22450(rot * 0.2f - (float) class_3532.method_15375(rot * 0.1f));
        final int innerColor = color | 0xFF000000;
        final int outerColor = (color & 0x00FFFFFF) | (32 << 24);
        final float v1 = -1.0f + frac;
        final float v2 = (float) maxY * (0.5f / innerRadius) + v1;
        final float v4 = (float) maxY + v1;

        ms.method_22903();
        ms.method_34425(new org.joml.Matrix4f().rotation(class_7833.field_40716.rotationDegrees(time * 2.25f - 45.0f)));
        ctx.geometry(inner, (pose, vc) -> beamLayer(pose, vc, innerColor, yOffset, endY,
                0.0f, innerRadius, innerRadius, 0.0f, -innerRadius, 0.0f, 0.0f, -innerRadius, 0.0f, 1.0f, v2, v1));
        ms.method_22909();

        ctx.geometry(outer, (pose, vc) -> beamLayer(pose, vc, outerColor, yOffset, endY,
                -outerRadius, -outerRadius, outerRadius, -outerRadius, -outerRadius, outerRadius, outerRadius, outerRadius, 0.0f, 1.0f, v4, v1));
    }

    private static void beamLayer(class_4587.class_4665 pose, class_4588 vc, int color, int yOffset, int height,
                                  float x1, float z1, float x2, float z2, float x3, float z3, float x4, float z4,
                                  float u1, float u2, float v1, float v2) {
        beamFace(pose, vc, color, yOffset, height, x1, z1, x2, z2, u1, u2, v1, v2);
        beamFace(pose, vc, color, yOffset, height, x4, z4, x3, z3, u1, u2, v1, v2);
        beamFace(pose, vc, color, yOffset, height, x2, z2, x4, z4, u1, u2, v1, v2);
        beamFace(pose, vc, color, yOffset, height, x3, z3, x1, z1, u1, u2, v1, v2);
    }

    private static void beamFace(class_4587.class_4665 pose, class_4588 vc, int color, int yOffset, int height,
                                 float x1, float z1, float x2, float z2, float u1, float u2, float v1, float v2) {
        beamVertex(pose, vc, color, height, x1, z1, u2, v1);
        beamVertex(pose, vc, color, yOffset, x1, z1, u2, v2);
        beamVertex(pose, vc, color, yOffset, x2, z2, u1, v2);
        beamVertex(pose, vc, color, height, x2, z2, u1, v1);
    }

    private static void beamVertex(class_4587.class_4665 pose, class_4588 vc, int color, int y, float x, float z, float u, float v) {
        vc.method_56824(pose, x, (float) y, z)
          .method_39415(color)
          .method_22913(u, v)
          .method_22922(class_4608.field_21444)
          .method_60803(15728880)
          .method_60831(pose, 0.0f, 1.0f, 0.0f);
    }

    /** Map an ARGB color roughly to the nearest MC chat-color code so the tag matches the beam. */
    private static String toChatColor(int argb) {
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;
        if (r < 40 && g < 40 && b < 40) return "§0";
        if (r > 220 && g > 220 && b > 220) return "§f";
        if (Math.abs(r - g) < 30 && Math.abs(g - b) < 30) return "§7";
        if (r > 200 && g > 160 && b < 120) return "§6";
        if (r > 200 && g > 200 && b < 140) return "§e";
        if (r > 200 && g < 150 && b < 150) return "§c";
        if (r < 150 && g > 180 && b < 150) return "§a";
        if (r < 150 && g > 150 && b > 200) return "§b";
        if (r > 150 && g < 180 && b > 180) return "§d";
        return "§f";
    }
}
