package com.iceymod.render;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.HitboxModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/**
 * Wireframe bounding boxes around nearby entities, colored by the
 * HitboxModule's color setting. The box edges are emitted by hand so no
 * vanilla shape-renderer helper (which keeps moving) is needed.
 */
public class HitboxRenderer {

    public static void register() {
        if (!WorldRenderHook.registerAfterEntities(HitboxRenderer::onRender)) {
            System.out.println("[IceyMod] WorldRenderEvents unavailable — hitbox renderer disabled");
        }
    }

    private static HitboxModule findModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof HitboxModule hm) return hm;
        }
        return null;
    }

    private static void onRender(WorldRenderHook.Ctx ctx) {
        HitboxModule mod = findModule();
        if (mod == null || !mod.isEnabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        int argb = mod.color.get();
        float a = ((argb >>> 24) & 0xFF) / 255f;
        float r = ((argb >>> 16) & 0xFF) / 255f;
        float g = ((argb >>> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        if (a <= 0f) a = 1f;

        int rangeBlocks = mod.range.get();
        int rangeSq = rangeBlocks * rangeBlocks;
        boolean includeSelf = mod.showSelf.get();
        boolean onlyLiving = mod.onlyLiving.get();

        List<class_238> boxes = new ArrayList<>();
        for (class_1297 e : client.field_1687.method_18112()) {
            if (e == client.field_1724 && !includeSelf) continue;
            if (onlyLiving && !(e instanceof class_1309)) continue;
            if (e.method_5858(client.field_1724) > rangeSq) continue;
            boxes.add(e.method_5829());
        }
        if (boxes.isEmpty()) return;

        class_4587 ms = ctx.poseStack();
        class_1921 type = ctx.lines();
        if (ms == null || type == null) return;
        class_243 camPos = com.iceymod.Compat.cameraPos(ctx.camera());
        final float fr = r, fg = g, fb = b, fa = a;
        ms.method_22903();
        ms.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
        ctx.geometry(type, (pose, vc) -> { for (class_238 box : boxes) lineBox(pose, vc, box, fr, fg, fb, fa); });
        ms.method_22909();
    }

    private static void lineBox(class_4587.class_4665 pose, class_4588 vc, class_238 bb, float r, float g, float b, float a) {
        float x1 = (float) bb.field_1323, y1 = (float) bb.field_1322, z1 = (float) bb.field_1321;
        float x2 = (float) bb.field_1320, y2 = (float) bb.field_1325, z2 = (float) bb.field_1324;
        // 4 edges along X
        edge(pose, vc, x1, y1, z1, x2, y1, z1, r, g, b, a); edge(pose, vc, x1, y2, z1, x2, y2, z1, r, g, b, a);
        edge(pose, vc, x1, y1, z2, x2, y1, z2, r, g, b, a); edge(pose, vc, x1, y2, z2, x2, y2, z2, r, g, b, a);
        // 4 edges along Y
        edge(pose, vc, x1, y1, z1, x1, y2, z1, r, g, b, a); edge(pose, vc, x2, y1, z1, x2, y2, z1, r, g, b, a);
        edge(pose, vc, x1, y1, z2, x1, y2, z2, r, g, b, a); edge(pose, vc, x2, y1, z2, x2, y2, z2, r, g, b, a);
        // 4 edges along Z
        edge(pose, vc, x1, y1, z1, x1, y1, z2, r, g, b, a); edge(pose, vc, x2, y1, z1, x2, y1, z2, r, g, b, a);
        edge(pose, vc, x1, y2, z1, x1, y2, z2, r, g, b, a); edge(pose, vc, x2, y2, z1, x2, y2, z2, r, g, b, a);
    }

    private static void edge(class_4587.class_4665 pose, class_4588 vc, float ax, float ay, float az, float bx, float by, float bz,
                             float r, float g, float b, float a) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len == 0f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        vc.method_56824(pose, ax, ay, az).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz);
        vc.method_56824(pose, bx, by, bz).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz);
    }
}
