package com.iceymod.compat;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** ERA: keyboard/mouse polling and the odd entity call whose shape drifts between versions (1.21.x: GLFW). */
public final class Input {
    private Input() {}
    /** The key type for a plain keyboard key. */
    public static final class_3675.class_307 KEYBOARD = class_3675.class_307.field_1668;

    /** Is the key with this InputConstants.KEY_* code held right now? */
    public static boolean keyDown(int code) {
        try {
            long handle = class_310.method_1551().method_22683().method_4490();
            return GLFW.glfwGetKey(handle, code) == GLFW.GLFW_PRESS;
        } catch (Throwable t) { return false; }
    }

    /** Is the mouse button with this InputConstants.MOUSE_BUTTON_* code held right now? */
    public static boolean mouseDown(int button) {
        try {
            long handle = class_310.method_1551().method_22683().method_4490();
            return GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
        } catch (Throwable t) { return false; }
    }

    public static void swingMainHand(class_1657 p) { p.method_6104(class_1268.field_5808); }
}
