package com.iceymod.compat;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;

public final class KeyRegistrar {
    private KeyRegistrar() {}
    public static class_304 register(class_304 k) { return KeyBindingHelper.registerKeyBinding(k); }
}
