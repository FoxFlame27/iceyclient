package com.iceymod.compat;

import net.minecraft.class_1713;
import net.minecraft.class_310;

public final class InventoryCompat {
    private InventoryCompat() {}
    /** Swap the item in {@code slot} of the player's own inventory menu with the off-hand (slot 40). */
    public static void swapToOffhand(class_310 c, int syncId, int slot) {
        c.field_1761.method_2906(syncId, slot, 40, class_1713.field_7791, c.field_1724);
    }
}
