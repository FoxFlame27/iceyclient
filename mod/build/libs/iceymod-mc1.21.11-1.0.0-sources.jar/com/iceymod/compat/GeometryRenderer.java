package com.iceymod.compat;

import net.minecraft.class_4587;
import net.minecraft.class_4588;

/** Emits vertices for one world-space draw (see WorldRenderHook.Ctx#geometry). */
@FunctionalInterface
public interface GeometryRenderer {
    void render(class_4587.class_4665 pose, class_4588 vc);
}
