package com.iceymod.compat;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class Chat {
    private Chat() {}
    /** Show a message to the local player: action bar overlay, or chat. */
    public static void message(class_2561 text, boolean actionBar) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        mc.field_1724.method_7353(text, actionBar);
    }
}
