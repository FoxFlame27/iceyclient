package com.iceymod.compat;

import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_5365;
import net.minecraft.class_638;

/** 1.21.x: small accessors for client state whose home moved between versions. */
public final class MC {
    private MC() {}
    public static class_437 screen(class_310 mc) { return mc.field_1755; }
    public static void setScreen(class_310 mc, class_437 s) { mc.method_1507(s); }
    public static class_4184 camera(class_310 mc) { return mc.field_1773.method_19418(); }
    public static long dayTime(class_1937 level) { return level.method_8532(); }
    public static void forceFastGraphics(class_310 mc) {
        if (mc.field_1690.method_75329().method_41753() != class_5365.field_25427) mc.field_1690.method_75329().method_41748(class_5365.field_25427);
    }
    public static long chunkKey(class_1923 pos) { return pos.method_8324(); }
    public static void onEndLevelTick(Consumer<class_638> c) { ClientTickEvents.END_WORLD_TICK.register(c::accept); }
}
