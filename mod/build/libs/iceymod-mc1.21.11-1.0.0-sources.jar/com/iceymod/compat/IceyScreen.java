package com.iceymod.compat;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** 1.21.x: adapts Screen.render/renderBackground to the era-neutral renderScreen/renderScreenBackground. */
public abstract class IceyScreen extends class_437 {
    protected IceyScreen(class_2561 title) { super(title); }

    @Override
    public final void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
        renderScreen(new Gfx(g), mouseX, mouseY, delta);
    }

    @Override
    public final void method_25420(class_332 g, int mouseX, int mouseY, float delta) {
        renderScreenBackground(new Gfx(g), mouseX, mouseY, delta);
    }

    protected void renderScreen(Gfx g, int mouseX, int mouseY, float delta) { superRender(g, mouseX, mouseY, delta); }
    protected void renderScreenBackground(Gfx g, int mouseX, int mouseY, float delta) { superRenderBackground(g, mouseX, mouseY, delta); }
    protected final void superRender(Gfx g, int mouseX, int mouseY, float delta) { super.method_25394(g.raw(), mouseX, mouseY, delta); }
    protected final void superRenderBackground(Gfx g, int mouseX, int mouseY, float delta) { super.method_25420(g.raw(), mouseX, mouseY, delta); }
}
