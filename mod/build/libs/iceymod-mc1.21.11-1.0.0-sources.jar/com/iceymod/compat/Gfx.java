package com.iceymod.compat;

import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

/** 1.21.x: thin wrapper over GuiGraphics (same method names, so shared code compiles on both eras). */
public final class Gfx {
    private final class_332 g;
    public Gfx(class_332 g) { this.g = g; }
    public class_332 raw() { return g; }

    public void fill(int x1, int y1, int x2, int y2, int color) { g.method_25294(x1, y1, x2, y2, color); }
    public void drawString(class_327 f, String s, int x, int y, int color) { g.method_25303(f, s, x, y, color); }
    public void drawString(class_327 f, String s, int x, int y, int color, boolean shadow) { g.method_51433(f, s, x, y, color, shadow); }
    public void drawString(class_327 f, class_2561 c, int x, int y, int color) { g.method_27535(f, c, x, y, color); }
    public void drawCenteredString(class_327 f, String s, int x, int y, int color) { g.method_25300(f, s, x, y, color); }
    public void drawCenteredString(class_327 f, class_2561 c, int x, int y, int color) { g.method_27534(f, c, x, y, color); }
    public void blit(class_2960 tex, int x, int y, float u, float v, int w, int h, int texW, int texH) {
        g.method_25290(class_10799.field_56883, tex, x, y, u, v, w, h, texW, texH);
    }
    public void renderItem(class_1799 stack, int x, int y) { g.method_51427(stack, x, y); }
    public Matrix3x2fStack pose() { return g.method_51448(); }
    public int guiWidth() { return g.method_51421(); }
    public int guiHeight() { return g.method_51443(); }
    public void enableScissor(int x1, int y1, int x2, int y2) { g.method_44379(x1, y1, x2, y2); }
    public void disableScissor() { g.method_44380(); }
}
