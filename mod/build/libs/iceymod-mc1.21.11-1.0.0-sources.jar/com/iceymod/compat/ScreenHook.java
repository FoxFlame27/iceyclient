package com.iceymod.compat;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_437;

public final class ScreenHook {
    private ScreenHook() {}
    public static void afterRender(class_437 screen, ScreenOverlay overlay) {
        ScreenEvents.afterRender(screen).register((scr, g, mouseX, mouseY, delta) -> overlay.render(new Gfx(g), mouseX, mouseY, delta));
    }
}
