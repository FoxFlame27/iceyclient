package com.iceymod.hud;

import com.iceymod.compat.Gfx;
import com.iceymod.compat.HudHook;
import com.iceymod.network.IceyNetwork;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;

/**
 * Draws a small Icey badge above each remote player's nametag if they're
 * a confirmed Icey Client user. Hand-rolled world→screen projection from
 * the camera's position/yaw/pitch/FOV, drawn as a HUD overlay.
 */
public final class IceyBadgeHud {

    private static final class_2960 BADGE = class_2960.method_60655("iceymod", "icon.png");
    private static final int BADGE_SIZE = 12;
    private static final int BADGE_Y_OFFSET = 28; // px above the nametag

    private IceyBadgeHud() {}

    public static void register() {
        HudHook.register("badges", (g, tickDelta) -> {
            try { renderBadges(g); }
            catch (Throwable t) { /* never crash the HUD */ }
        });
    }

    private static void renderBadges(Gfx g) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1773 == null) return;
        class_4184 cam = com.iceymod.compat.MC.camera(mc);
        if (cam == null) return;

        class_243 camPos = com.iceymod.Compat.cameraPos(cam);
        double yawRad = Math.toRadians(com.iceymod.Compat.cameraYaw(cam));
        double pitchRad = Math.toRadians(com.iceymod.Compat.cameraPitch(cam));
        double cy = Math.cos(yawRad), sy = Math.sin(yawRad);
        double cp = Math.cos(pitchRad), sp = Math.sin(pitchRad);

        int screenW = g.guiWidth();
        int screenH = g.guiHeight();
        double fov = mc.field_1690.method_41808().method_41753();
        double tanHalf = Math.tan(Math.toRadians(fov / 2.0));
        double aspect = (double) screenW / screenH;

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;
            UUID uuid = p.method_5667();
            if (uuid == null || !IceyNetwork.isOnline(uuid)) continue;

            class_243 head = new class_243(p.method_23317(), p.method_23318() + p.method_5751() + 0.6, p.method_23321());
            class_243 rel = head.method_1020(camPos);

            // Inverse camera rotation: yaw (around Y) then pitch (around X);
            // afterwards the camera looks down +Z and visible points have z > 0.
            double rx = rel.field_1352 * cy - rel.field_1350 * sy;
            double rz = rel.field_1352 * sy + rel.field_1350 * cy;
            double ry = rel.field_1351 * cp - rz * sp;
            double rz2 = rel.field_1351 * sp + rz * cp;
            if (rz2 < 0.5) continue;

            double sx = (rx / (rz2 * tanHalf * aspect)) * (screenW / 2.0) + screenW / 2.0;
            double syScreen = -(ry / (rz2 * tanHalf)) * (screenH / 2.0) + screenH / 2.0;
            if (sx < -BADGE_SIZE || sx > screenW + BADGE_SIZE) continue;
            if (syScreen < -BADGE_SIZE || syScreen > screenH + BADGE_SIZE) continue;

            int drawX = (int) (sx - BADGE_SIZE / 2.0);
            int drawY = (int) (syScreen - BADGE_Y_OFFSET);
            g.blit(BADGE, drawX, drawY, 0f, 0f, BADGE_SIZE, BADGE_SIZE, BADGE_SIZE, BADGE_SIZE);
        }
    }
}
