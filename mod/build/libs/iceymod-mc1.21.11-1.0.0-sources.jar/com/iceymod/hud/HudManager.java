package com.iceymod.hud;

import com.iceymod.hud.modules.*;
import com.iceymod.hud.settings.Setting;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import com.iceymod.compat.Gfx;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class HudManager {
    private static final List<HudModule> modules = new ArrayList<>();
    private static Path configPath;
    private static boolean positionsClamped = false;
    private static boolean hudVisible = true;

    public static boolean isHudVisible() { return hudVisible; }
    public static void toggleHudVisibility() { hudVisible = !hudVisible; }

    /**
     * Emergency reset — wipes saved enabled/position state for every
     * module back to its constructor default. Used by /iceyhuds when a
     * user reports "HUDs not showing": force visible, redo position
     * defaults, save. Anything they had customized is lost; that's the
     * price of recovery.
     */
    public static void resetAllToDefaults() {
        hudVisible = true;
        positionsClamped = false;
        // The constructor-default enabled state isn't stored anywhere
        // permanent — we'd have to reconstruct each module to read it.
        // Cheapest: just reset positions (force-recompute defaults) and
        // re-enable every module that's currently disabled. Users who
        // explicitly toggled something off will get it back, but the
        // alternative is everyone-stays-broken so it's the right call.
        for (HudModule m : modules) {
            if (m.getCategory() != HudModule.Category.OPTIMIZATION) m.setEnabled(true);
            m.setX(-9999); // out-of-screen → applyCenterDefaults re-clamps
            m.setY(-9999);
        }
        applyCenterDefaults();
        save();
    }

    public static void init() {
        configPath = FabricLoader.getInstance().getConfigDir().resolve("iceymod.json");

        // Core modules
        modules.add(new FpsModule());
        modules.add(new PingModule());
        modules.add(new CoordsModule());
        modules.add(new CpsModule());
        modules.add(new KeystrokesModule());
        modules.add(new ArmorModule());
        // Info
        modules.add(new HitboxModule());
        modules.add(new ItemGlowModule());
        modules.add(new DirectionModule());
        modules.add(new DayCounterModule());
        modules.add(new ServerModule());
        modules.add(new PotionModule());
        modules.add(new MemoryModule());
        modules.add(new SaturationModule());
        modules.add(new ComboCounterModule());
        modules.add(new TimeModule());
        modules.add(new BiomeModule());
        modules.add(new BlockAboveModule());
        modules.add(new CrosshairModule());
        modules.add(new HotbarTextModule());
        modules.add(new YLevelModule());
        modules.add(new PitchYawModule());
        modules.add(new VelocityModule());
        modules.add(new SessionTimeModule());
        modules.add(new AirModule());
        modules.add(new WorldTimeModule());
        modules.add(new EntityCountModule());
        modules.add(new ArrowCountModule());
        // New HUD info modules
        modules.add(new WeatherModule());
        modules.add(new TpsModule());
        modules.add(new BlocksMinedModule());
        modules.add(new DistanceWalkedModule());
        modules.add(new InventorySlotsModule());
        // New combat modules (mace PvP / crystal PvP / general PvP)
        modules.add(new CrystalTrackerModule());
        modules.add(new TotemPopsModule());
        // PlayerHealthModule + MobHealthModule removed — replaced by
        // the bundled HealthIndicators mod (handled by the launcher).
        modules.add(new MaceDamageModule());
        modules.add(new GappleCountModule());
        modules.add(new EnderPearlCountModule());
        modules.add(new CrystalCpsModule());
        modules.add(new AttackCooldownModule());
        modules.add(new ElytraDurabilityModule());
        modules.add(new TotemCountModule());
        modules.add(new ObsidianCountModule());
        modules.add(new KillStreakModule());
        modules.add(new DeathCounterModule());
        modules.add(new LastDamageModule());
        modules.add(new NearestPlayerModule());
        modules.add(new ItemCooldownModule());
        modules.add(new FallDistanceModule());
        // New useful replacements
        modules.add(new OffhandItemModule());
        modules.add(new ToolBreakWarnModule());
        modules.add(new HostileMobsModule());
        modules.add(new NearestHostileModule());
        modules.add(new BedCoordsModule());
        modules.add(new ChunkModule());
        modules.add(new LookingAtModule());
        modules.add(new MobKillsModule());
        modules.add(new NetherCoordsModule());
        // Quality-of-life features
        modules.add(new ZoomModule());
        modules.add(new PerspectiveModule());
        modules.add(new WaypointsModule());
        modules.add(new StructureLocatorModule());
        modules.add(new BiomeLocatorModule());
        modules.add(new FreelookModule());
        modules.add(new FreecamModule());
        // Small cheats / QoL
        modules.add(new AutoMaceSwapModule());
        modules.add(new AutoRespawnModule());
        modules.add(new NoHurtCamModule());
        modules.add(new FullBrightModule());
        modules.add(new AutoSprintModule());
        modules.add(new NoCameraBobModule());
        modules.add(new NoFovChangeModule());
        modules.add(new AntiAFKModule());
        modules.add(new AutoTotemModule());
        modules.add(new SafeWalkModule());
        // Optimization modules (invisible, enabled by default)
        modules.add(new FpsBoostParticlesModule());
        modules.add(new FpsBoostCloudsModule());
        modules.add(new FpsBoostShadowsModule());
        modules.add(new FpsBoostGraphicsModule());
        modules.add(new NetDnsCacheModule());
        modules.add(new NetIpv4Module());
        modules.add(new NetNoDelayModule());
        modules.add(new NetBufferModule());

        // Snapshot each module's default-enabled state BEFORE load() lets
        // saved config override it. The migration below uses this to
        // distinguish "user explicitly disabled this" vs "previous version's
        // auto-disable-on-render-error force-killed it".
        java.util.Map<String, Boolean> defaultEnabled = new java.util.HashMap<>();
        for (HudModule m : modules) defaultEnabled.put(m.getId(), m.isEnabled());

        load();
        migrateRenderSafe(defaultEnabled);
        applyCenterDefaults();
    }

    /**
     * One-shot: previous versions of HudManager.render auto-disabled any
     * module that threw on a single frame, and persisted that disable to
     * iceymod.json. On a new MC version several modules can throw on
     * their first render call, which left users with a near-empty HUD bar
     * that didn't recover even after the underlying bug was fixed.
     *
     * <p>This pass resets enabled=false → true for any module whose
     * <em>default</em> was enabled and whose saved state is disabled, then
     * marks the migration done so it doesn't keep flipping a user's
     * explicit "off" choices on every launch.
     */
    private static void migrateRenderSafe(java.util.Map<String, Boolean> defaultEnabled) {
        if (configPath == null || !Files.exists(configPath)) return;
        try {
            String json = Files.readString(configPath);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonObject migrations = root.has("migrations") && root.get("migrations").isJsonObject()
                    ? root.getAsJsonObject("migrations") : null;
            if (migrations != null && migrations.has("renderSafe")
                    && migrations.get("renderSafe").getAsBoolean()) return;

            for (HudModule m : modules) {
                if (Boolean.TRUE.equals(defaultEnabled.get(m.getId())) && !m.isEnabled()) {
                    m.setEnabled(true);
                }
            }
            save(); // persists with the migration flag below
        } catch (Exception ignored) {}
    }

    /**
     * Place modules in a clean stack near screen center on first launch (no saved config).
     * Also fixes any saved positions that are off-screen.
     */
    private static void applyCenterDefaults() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) return;
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        if (sw <= 0 || sh <= 0) return;

        boolean configExists = Files.exists(configPath);
        int colWidth = 120;
        int rowHeight = 16;
        int perColumn = Math.max(1, (sh - 40) / rowHeight);
        int startX = sw / 2 - colWidth;
        int startY = sh / 2 - (perColumn * rowHeight) / 2;

        int visibleIdx = 0;
        for (HudModule m : modules) {
            if (m.getCategory() == HudModule.Category.OPTIMIZATION) continue;

            int defaultX;
            int defaultY;
            if (m instanceof StructureLocatorModule) {
                // Locator + waypoint widgets need to be visible by default,
                // not buried mid-screen in the info grid where they overlap
                // whatever else is stacked there. Anchor them top-left in a
                // vertical stack: structures · biomes · waypoints.
                defaultX = 8;
                defaultY = 40;
            } else if (m instanceof BiomeLocatorModule) {
                defaultX = 8;
                defaultY = 120;
            } else if (m instanceof WaypointsModule) {
                defaultX = 8;
                defaultY = 200;
            } else {
                int col = visibleIdx / perColumn;
                int row = visibleIdx % perColumn;
                defaultX = startX + col * colWidth;
                defaultY = startY + row * rowHeight;
                visibleIdx++;
            }

            if (!configExists) {
                m.setX(defaultX);
                m.setY(defaultY);
            } else {
                if (m.getX() < 0 || m.getX() > sw - 20) m.setX(defaultX);
                if (m.getY() < 0 || m.getY() > sh - 10) m.setY(defaultY);
            }
        }
        positionsClamped = true;
    }

    public static List<HudModule> getModules() {
        return modules;
    }

    // Tracks which modules have already logged a render or tick error so
    // we don't spam stdout every frame. We DON'T disable the offending
    // module on a single throw any more — a transient miss shouldn't kill
    // the widget for the rest of the session, and on new MC versions
    // multiple modules can throw on their first render call (which used
    // to disable them all → empty HUD bar).
    private static final java.util.Set<String> renderErrLogged = new java.util.HashSet<>();
    private static final java.util.Set<String> tickErrLogged   = new java.util.HashSet<>();

    public static void render(Gfx context) {
        if (!hudVisible) return;
        class_310 client = class_310.method_1551();
        if (!positionsClamped) applyCenterDefaults();
        for (HudModule module : modules) {
            if (!module.isEnabled()) continue;
            try {
                module.renderScaled(context, client);
            } catch (Throwable t) {
                if (renderErrLogged.add(module.getId())) {
                    System.out.println("[IceyMod] Render error in '" + module.getId() + "': " + t);
                }
            }
        }
    }

    public static void tick() {
        for (HudModule module : modules) {
            if (!module.isEnabled()) continue;
            try {
                module.tick();
            } catch (Throwable t) {
                if (tickErrLogged.add(module.getId())) {
                    System.out.println("[IceyMod] Tick error in '" + module.getId() + "': " + t);
                }
            }
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        JsonObject modulesObj = new JsonObject();
        for (HudModule module : modules) {
            JsonObject m = new JsonObject();
            m.addProperty("enabled", module.isEnabled());
            m.addProperty("x", module.getX());
            m.addProperty("y", module.getY());
            if (!module.getSettings().isEmpty()) {
                JsonObject s = new JsonObject();
                for (Setting<?> setting : module.getSettings()) {
                    s.addProperty(setting.id, setting.serialize());
                }
                m.add("settings", s);
            }
            modulesObj.add(module.getId(), m);
        }
        root.add("modules", modulesObj);

        // Persist migration flags so one-shot fixes (e.g. renderSafe) don't
        // re-run on every launch and stomp on the user's later choices.
        JsonObject migrations = new JsonObject();
        migrations.addProperty("renderSafe", true);
        root.add("migrations", migrations);

        try {
            Files.writeString(configPath, new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (IOException e) { /* silent */ }
    }

    public static void load() {
        if (!Files.exists(configPath)) return;
        try {
            String json = Files.readString(configPath);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonObject modulesObj = root.getAsJsonObject("modules");
            if (modulesObj == null) return;

            for (HudModule module : modules) {
                JsonObject m = modulesObj.getAsJsonObject(module.getId());
                if (m != null) {
                    if (m.has("enabled")) module.setEnabled(m.get("enabled").getAsBoolean());
                    if (m.has("x")) module.setX(m.get("x").getAsInt());
                    if (m.has("y")) module.setY(m.get("y").getAsInt());
                    if (m.has("settings") && m.get("settings").isJsonObject()) {
                        JsonObject s = m.getAsJsonObject("settings");
                        for (Setting<?> setting : module.getSettings()) {
                            if (s.has(setting.id)) {
                                try { setting.deserialize(s.get(setting.id).getAsString()); } catch (Exception ignored) {}
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) { /* silent */ }
    }
}
