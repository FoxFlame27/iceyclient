package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class BedCoordsModule extends HudModule {
    public BedCoordsModule() {
        super("bedcoords", "Bed Coords", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_2338 spawn = client.field_1724.method_43122().isPresent() ? null : null;
        // getSpawnPointPosition available client-side? Use personal spawn.
        // In 1.21+ the spawn point is only server-known; show world spawn as fallback
        if (client.field_1687 == null) return null;
        // ClientWorld.getSpawnPos() was removed in 1.21.11. Use the
        // Compat helper which tries the method, then falls through to
        // (0, 64, 0) so the HUD still renders something.
        class_2338 ws = com.iceymod.Compat.worldSpawnPos(client.field_1687);
        return "\u00A7a\u2302 Spawn: " + ws.method_10263() + ", " + ws.method_10264() + ", " + ws.method_10260();
    }
}
