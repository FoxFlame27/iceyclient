package com.iceymod.mixin;

import com.iceymod.IceyMod;
import net.minecraft.class_10799;
import net.minecraft.class_332;
import net.minecraft.class_8020;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the vanilla "MINECRAFT" logo on the title screen with the
 * Icey Client logo. Uses DrawContext.drawTexture with the standard
 * GUI_TEXTURED render pipeline — the reliable 1.21.8 way.
 */
@Mixin(class_8020.class)
public abstract class LogoDrawerMixin {


    @Inject(method = "renderLogo(Lnet/minecraft/client/gui/GuiGraphics;IFI)V", at = @At("HEAD"), cancellable = true, require = 0, expect = 0)
    private void iceymod$replaceLogo(class_332 context, int screenWidth, float horizontalAlphaMultiplier, int yOffset, CallbackInfo ci) {
        try {
            // Icey Client or Skiflame logo, depending on the launcher's mode.
            int targetW = com.iceymod.Branding.logoTargetWidth(screenWidth);
            int targetH = (int) ((long) targetW * com.iceymod.Branding.logoHeight() / com.iceymod.Branding.logoWidth());
            int x = Math.max(4, screenWidth / 2 - targetW / 2);
            int y = com.iceymod.Branding.isSkiflame()
                    ? Math.max(4, class_8020.field_41809 + yOffset - 20)
                    : Math.max(4, class_8020.field_41809 + yOffset - 55);
            context.method_25290(
                    class_10799.field_56883,
                    com.iceymod.Branding.logo(),
                    x, y,
                    0f, 0f,
                    targetW, targetH,
                    targetW, targetH
            );
            ci.cancel();
        } catch (Throwable ignored) {
            // drawTexture signature changed between versions — let vanilla
            // render the default logo rather than crash the title screen.
        }
    }
}
