package com.iceymod.mixin;

import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Camera position / rotation without depending on accessor names that
 * differ per version (getPosition() vanished in 1.21.11, 26.x has
 * position()). The fields are named the same on every version we ship for.
 */
@Mixin(class_4184.class)
public interface CameraAccessor {
    @Accessor("position") class_243 iceymod$position();
    @Accessor("yRot") float iceymod$yRot();
    @Accessor("xRot") float iceymod$xRot();
}
