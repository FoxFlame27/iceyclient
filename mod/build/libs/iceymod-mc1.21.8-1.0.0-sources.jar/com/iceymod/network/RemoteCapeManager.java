package com.iceymod.network;

import java.io.ByteArrayInputStream;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Per-player cape registry. When the cape mixin asks for another
 * player's cape ResourceLocation:
 *   - cache hit → return it.
 *   - negative-cache hit → return null (don't re-fetch known failures).
 *   - otherwise → schedule a background fetch from the Icey network,
 *     decode the PNG, register it as a texture on the render thread,
 *     and populate the cache.
 *
 * <p>The first render after a player joins is a no-op while the fetch
 * is in flight; the next frame after the texture lands picks it up.
 */
public final class RemoteCapeManager {

    private static final ConcurrentHashMap<UUID, class_2960> capes = new ConcurrentHashMap<>();
    private static final Set<UUID> pending = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> failed = ConcurrentHashMap.newKeySet();

    private RemoteCapeManager() {}

    public static class_2960 getCapeIdentifier(UUID uuid) {
        if (uuid == null) return null;
        class_2960 cached = capes.get(uuid);
        if (cached != null) return cached;
        if (failed.contains(uuid)) return null;
        scheduleFetch(uuid);
        return null;
    }

    private static void scheduleFetch(UUID uuid) {
        if (!pending.add(uuid)) return;
        Thread.ofVirtual().name("icey-cape-fetch-" + uuid).start(() -> {
            try {
                byte[] png = IceyNetwork.fetchCape(uuid);
                if (png == null || png.length == 0) {
                    failed.add(uuid);
                    return;
                }
                class_310 mc = class_310.method_1551();
                if (mc == null) {
                    failed.add(uuid);
                    return;
                }
                mc.execute(() -> {
                    try (ByteArrayInputStream in = new ByteArrayInputStream(png)) {
                        class_1011 img = class_1011.method_4309(in);
                        String slug = uuid.toString().replace("-", "_").toLowerCase();
                        class_2960 texId = class_2960.method_60655("iceymod", "remote_cape_" + slug);
                        class_1043 tex = new class_1043(
                            () -> "iceymod_remote_cape_" + uuid, img);
                        mc.method_1531().method_4616(texId, tex);
                        capes.put(uuid, texId);
                        System.out.println("[IceyMod] RemoteCapeManager: registered cape for " + uuid);
                    } catch (Throwable t) {
                        System.out.println("[IceyMod] RemoteCapeManager: register failed for " + uuid + ": " + t);
                        failed.add(uuid);
                    }
                });
            } catch (Throwable t) {
                failed.add(uuid);
            } finally {
                pending.remove(uuid);
            }
        });
    }
}
