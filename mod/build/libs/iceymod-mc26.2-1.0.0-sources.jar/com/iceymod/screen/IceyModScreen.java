package com.iceymod.screen;

import com.iceymod.IceyMod;
import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.compat.Input;
import com.mojang.blaze3d.platform.InputConstants;

import java.util.ArrayList;
import java.util.List;
import com.iceymod.compat.Gfx;
import com.iceymod.compat.IceyScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * The main Icey Client menu, opened with Y.
 * Paginated grid of module toggles with arrow-key navigation.
 */
public class IceyModScreen extends IceyScreen {

    private static HudModule.Category currentFilter = null; // null = ALL
    private static int page = 0;
    private static int selectedIndex = 0;
    // Persisted across rebuilds during typing so the field doesn't lose
    // text when the screen re-inits on each keystroke.
    private static String searchQuery = "";
    private EditBox searchField;
    // Instance field so settings mode resets every time the menu is reopened.
    private boolean settingsMode = false;

    private int gridCols = 4;
    private int gridRows = 5;
    private int perPage = 20;
    private List<HudModule> filtered = new ArrayList<>();
    private final List<Button> moduleButtons = new ArrayList<>();

    private static final Identifier GEAR_TEXTURE = Identifier.fromNamespaceAndPath(IceyMod.MOD_ID, "textures/gui/gear.png");
    private int gearX, gearY, gearW, gearH;

    public IceyModScreen() {
        super(Component.literal(com.iceymod.Branding.name()));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int sh = this.height;
        moduleButtons.clear();

        // Search bar — between title (y=8) and category filter row (y=44).
        int searchW = 220;
        int searchH = 16;
        searchField = new EditBox(this.font, centerX - searchW / 2, 22,
                searchW, searchH, Component.literal(""));
        searchField.setMaxLength(32);
        searchField.setHint(Component.literal("§7Search modules…"));
        searchField.setValue(searchQuery);
        searchField.setResponder(s -> {
            if (!s.equals(searchQuery)) {
                searchQuery = s;
                page = 0;
                selectedIndex = 0;
                rebuild();
            }
        });
        addRenderableWidget(searchField);
        // If the user is mid-search, the rebuild triggered by typing
        // would otherwise leave focus on nothing — re-grab it.
        if (searchQuery != null && !searchQuery.isEmpty()) {
            setInitialFocus(searchField);
            searchField.setFocused(true);
        }

        // Filter buttons row — pushed below the search bar.
        int filterY = 44;
        int filterBtnW = 64;
        int filterBtnH = 18;
        int filterGap = 4;

        HudModule.Category[] cats = HudModule.Category.values();
        int filterCount = cats.length + 1; // +1 for ALL
        int filterRowW = filterCount * filterBtnW + (filterCount - 1) * filterGap;
        int filterStartX = centerX - filterRowW / 2;

        addRenderableWidget(Button.builder(
                Component.literal(currentFilter == null ? "\u00A7b\u00A7lALL" : "ALL"),
                btn -> { currentFilter = null; page = 0; selectedIndex = 0; rebuild(); }
        ).bounds(filterStartX, filterY, filterBtnW, filterBtnH).build());

        for (int i = 0; i < cats.length; i++) {
            HudModule.Category cat = cats[i];
            int x = filterStartX + (i + 1) * (filterBtnW + filterGap);
            String name = cat.name();
            String label = currentFilter == cat ? "\u00A7b\u00A7l" + name : name;
            addRenderableWidget(Button.builder(
                    Component.literal(label),
                    btn -> { currentFilter = cat; page = 0; selectedIndex = 0; rebuild(); }
            ).bounds(x, filterY, filterBtnW, filterBtnH).build());
        }

        // Filter modules: category gate + free-text name search.
        // ALL excludes OPTIMIZATION so it only appears in its own tab.
        String q = searchQuery == null ? "" : searchQuery.toLowerCase().trim();
        List<HudModule> all = HudManager.getModules();
        filtered = new ArrayList<>();
        for (HudModule m : all) {
            boolean catOk = currentFilter == null
                    ? m.getCategory() != HudModule.Category.OPTIMIZATION
                    : m.getCategory() == currentFilter;
            if (!catOk) continue;
            if (!q.isEmpty() && !m.getName().toLowerCase().contains(q)) continue;
            filtered.add(m);
        }

        // Grid sizing — bigger buttons, paginated so they always fit
        int bottomReserved = 80; // pagination + edit + done
        int gridTop = filterY + filterBtnH + 12;
        int availableH = sh - gridTop - bottomReserved;

        int btnW = 128;
        int btnH = 20;
        int gap = 4;

        gridCols = Math.max(2, Math.min(5, (this.width - 40) / (btnW + gap)));
        // Only as many rows as actually fit above the footer buttons — a
        // forced minimum of 3 rows overlapped the pagination row at large
        // GUI scales.
        gridRows = Math.max(1, availableH / (btnH + gap));
        perPage = gridCols * gridRows;

        int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        if (selectedIndex >= filtered.size()) selectedIndex = Math.max(0, filtered.size() - 1);

        int startIdx = page * perPage;
        int endIdx = Math.min(filtered.size(), startIdx + perPage);

        int gridW = gridCols * btnW + (gridCols - 1) * gap;
        int startX = centerX - gridW / 2;

        for (int i = startIdx; i < endIdx; i++) {
            final HudModule module = filtered.get(i);
            int rel = i - startIdx;
            int col = rel % gridCols;
            int row = rel / gridCols;
            int x = startX + col * (btnW + gap);
            int y = gridTop + row * (btnH + gap);

            final int thisIdx = i;
            Button btn = Button.builder(
                    getModuleText(module, thisIdx == selectedIndex),
                    b -> {
                        selectedIndex = thisIdx;
                        if (settingsMode) {
                            com.iceymod.compat.MC.setScreen(minecraft, new ModuleSettingsScreen(module, this));
                        } else {
                            module.toggle();
                            b.setMessage(getModuleText(module, true));
                        }
                    }
            ).bounds(x, y, btnW, btnH).build();
            addRenderableWidget(btn);
            moduleButtons.add(btn);
        }

        // Gear icon (settings mode toggle) — top-right corner, renders as a texture
        gearW = 28;
        gearH = 28;
        gearX = this.width - gearW - 10;
        gearY = 10;
        Button gear = Button.builder(
                Component.literal(""),
                b -> { settingsMode = !settingsMode; rebuild(); }
        ).bounds(gearX, gearY, gearW, gearH).build();
        addRenderableWidget(gear);

        // Pagination row
        int paginationY = sh - bottomReserved + 4;
        int pagBtnW = 80;
        int pagBtnH = 20;
        int pagGap = 6;

        boolean canPrev = page > 0;
        boolean canNext = page < totalPages - 1;

        Button lessBtn = Button.builder(
                Component.literal(canPrev ? "\u00A7b\u25C0 Less" : "\u00A78\u25C0 Less"),
                btn -> { if (page > 0) { page--; selectedIndex = page * perPage; rebuild(); } }
        ).bounds(centerX - pagBtnW - pagGap - 50, paginationY, pagBtnW, pagBtnH).build();
        lessBtn.active = canPrev;
        addRenderableWidget(lessBtn);

        addRenderableWidget(Button.builder(
                Component.literal("\u00A77" + (page + 1) + "/" + totalPages),
                btn -> {}
        ).bounds(centerX - 40, paginationY, 80, pagBtnH).build());

        Button moreBtn = Button.builder(
                Component.literal(canNext ? "\u00A7bMore \u25B6" : "\u00A78More \u25B6"),
                btn -> { if (page < totalPages - 1) { page++; selectedIndex = page * perPage; rebuild(); } }
        ).bounds(centerX + 50 + pagGap, paginationY, pagBtnW, pagBtnH).build();
        moreBtn.active = canNext;
        addRenderableWidget(moreBtn);

        // Bottom buttons
        int bottomBtnY = sh - 54;
        addRenderableWidget(Button.builder(
                Component.literal("\u2699 Edit HUD Layout"),
                btn -> com.iceymod.compat.MC.setScreen(minecraft, new HudEditScreen(this))
        ).bounds(centerX - 110, bottomBtnY, 108, 22).build());

        // Switch to the glass panel menu (also selectable in the launcher).
        addRenderableWidget(Button.builder(
                Component.literal("Panel Menu"),
                btn -> {
                    HudManager.save();
                    com.iceymod.MenuPrefs.setStyle(com.iceymod.MenuPrefs.STYLE_PANELS);
                    com.iceymod.compat.MC.setScreen(minecraft, new PanelMenuScreen());
                }
        ).bounds(centerX + 2, bottomBtnY, 108, 22).build());

        addRenderableWidget(Button.builder(
                Component.translatable("gui.done"),
                btn -> onClose()
        ).bounds(centerX - 110, bottomBtnY + 26, 220, 22).build());
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    private Component getModuleText(HudModule module, boolean selected) {
        String prefix = selected ? "\u00A7b\u00BB \u00A7r" : "";
        if (settingsMode) {
            // No icons, no on/off suffix — the top-right gear already tells
            // you you're in settings mode. Just the clean module name.
            return Component.literal(prefix + module.getName());
        }
        String state = module.isEnabled() ? "\u00A7aON" : "\u00A7cOFF";
        return Component.literal(prefix + module.getName() + ": " + state);
    }

    // GLFW key polling: 1.21.11 changed Screen.keyPressed's signature to
    // take a KeyInput object, so our (int, int, int) override stops
    // overriding anything at runtime → arrow-key navigation silently
    // dies. We poll inside render() instead — works on both 1.21.8 and
    // 1.21.11 (Input.keyDown hides how each version reads the key state).
    private final java.util.HashMap<Integer, Boolean> prevKeyState = new java.util.HashMap<>();

    private boolean keyEdge(int keyCode) {
        try {
            boolean down = Input.keyDown(keyCode);
            boolean wasDown = prevKeyState.getOrDefault(keyCode, false);
            prevKeyState.put(keyCode, down);
            return down && !wasDown;
        } catch (Throwable t) { return false; }
    }

    private void pollNavigationKeys() {
        if (filtered.isEmpty()) return;
        // Skip nav-key polling when the search field is focused so
        // typing arrow keys / Enter / Space don't double-fire as
        // grid navigation while the user is editing the query.
        if (searchField != null && searchField.isFocused()) return;
        int startIdx = page * perPage;
        int localIdx = selectedIndex - startIdx;

        if (keyEdge(InputConstants.KEY_UP)) {
            int next = selectedIndex - gridCols;
            if (next < 0) next = selectedIndex;
            moveSelection(next);
        }
        if (keyEdge(InputConstants.KEY_DOWN)) {
            int next = selectedIndex + gridCols;
            if (next >= filtered.size()) next = selectedIndex;
            moveSelection(next);
        }
        if (keyEdge(InputConstants.KEY_LEFT)) {
            if (localIdx > 0 && selectedIndex > 0) {
                moveSelection(selectedIndex - 1);
            } else if (page > 0) {
                page--;
                selectedIndex = Math.min(page * perPage + perPage - 1, filtered.size() - 1);
                rebuild();
            }
        }
        if (keyEdge(InputConstants.KEY_RIGHT)) {
            if (selectedIndex < filtered.size() - 1) moveSelection(selectedIndex + 1);
        }
        if (keyEdge(InputConstants.KEY_RETURN) || keyEdge(InputConstants.KEY_SPACE)) {
            if (selectedIndex >= 0 && selectedIndex < filtered.size()) {
                HudModule m = filtered.get(selectedIndex);
                if (settingsMode) {
                    com.iceymod.compat.MC.setScreen(minecraft, new ModuleSettingsScreen(m, this));
                } else {
                    m.toggle();
                    rebuild();
                }
            }
        }
        if (keyEdge(InputConstants.KEY_PAGEDOWN)) {
            int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
            if (page < totalPages - 1) { page++; selectedIndex = page * perPage; rebuild(); }
        }
        if (keyEdge(InputConstants.KEY_PAGEUP)) {
            if (page > 0) { page--; selectedIndex = page * perPage; rebuild(); }
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int totalPages = Math.max(1, (filtered.size() + perPage - 1) / perPage);
        if (verticalAmount < 0 && page < totalPages - 1) {
            page++; selectedIndex = page * perPage; rebuild();
            return true;
        }
        if (verticalAmount > 0 && page > 0) {
            page--; selectedIndex = page * perPage; rebuild();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void moveSelection(int newIdx) {
        if (newIdx < 0 || newIdx >= filtered.size()) return;
        int newPage = newIdx / perPage;
        selectedIndex = newIdx;
        if (newPage != page) {
            page = newPage;
            rebuild();
        } else {
            // just refresh labels
            int startIdx = page * perPage;
            for (int i = 0; i < moduleButtons.size(); i++) {
                HudModule m = filtered.get(startIdx + i);
                moduleButtons.get(i).setMessage(getModuleText(m, startIdx + i == selectedIndex));
            }
        }
    }

    @Override
    protected void renderScreenBackground(Gfx context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xC0101010);
    }

    @Override
    protected void renderScreen(Gfx context, int mouseX, int mouseY, float delta) {
        try { pollNavigationKeys(); } catch (Throwable ignored) {}
        superRender(context, mouseX, mouseY, delta);

        context.drawCenteredString(this.font,
                com.iceymod.Branding.colorCode() + com.iceymod.Branding.name() + " \u00A77" + HudManager.getModules().size() + " modules",
                this.width / 2, 10, 0xFFFFFFFF);

        // Gear icon texture on top of the invisible button
        context.blit(
                GEAR_TEXTURE,
                gearX, gearY,
                0f, 0f,
                gearW, gearH,
                gearW, gearH
        );
        // Clear ON/OFF label directly below the gear
        String state = settingsMode ? "\u00A7aON" : "\u00A77OFF";
        context.drawCenteredString(this.font, state,
                gearX + gearW / 2, gearY + gearH + 3, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        HudManager.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
