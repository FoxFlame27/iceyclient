package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public class EnderPearlCountModule extends HudModule {
    public EnderPearlCountModule() {
        super("pearls", "Pearls", 5, 175);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int count = 0;
        var inv = client.field_1724.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(class_1802.field_8634)) count += s.method_7947();
        }
        return "\u00A7b\u25C9 " + count + " pearls";
    }
}
