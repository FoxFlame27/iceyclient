package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class OffhandItemModule extends HudModule {
    public OffhandItemModule() {
        super("offhand", "Off-Hand Item", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_1799 s = client.field_1724.method_6079();
        if (s.method_7960()) return "\u00A78Off-hand: empty";
        return "\u00A7b\u25C4 " + s.method_7964().getString() + " x" + s.method_7947();
    }
}
