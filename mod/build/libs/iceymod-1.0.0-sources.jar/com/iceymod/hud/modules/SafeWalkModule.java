package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;

/**
 * Auto-sneaks when you're about to walk off a ledge 3+ blocks high so
 * you don't accidentally yeet yourself off in bridge/pvp situations.
 */
public class SafeWalkModule extends HudModule {
    public final com.iceymod.hud.settings.IntSetting minDrop = addSetting(
            new com.iceymod.hud.settings.IntSetting("minDrop", "Min Drop Blocks", 3, 2, 10));

    public SafeWalkModule() {
        super("safewalk", "Safe Walk", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (!client.field_1724.method_24828()) return;

        int px = (int) Math.floor(client.field_1724.method_23317());
        int py = (int) Math.floor(client.field_1724.method_23318());
        int pz = (int) Math.floor(client.field_1724.method_23321());

        // Check 4 cardinal directions for a nearby drop
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        boolean nearEdge = false;
        for (int[] d : dirs) {
            int dx = px + d[0];
            int dz = pz + d[1];
            int drop = 0;
            for (int y = py - 1; y >= py - 4; y--) {
                class_2680 st = client.field_1687.method_8320(new class_2338(dx, y, dz));
                if (st.method_26215()) drop++;
                else break;
            }
            if (drop >= minDrop.get()) { nearEdge = true; break; }
        }

        if (nearEdge) {
            client.field_1690.field_1832.method_23481(true);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
