package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class ChunkModule extends HudModule {
    public ChunkModule() {
        super("chunk", "Chunk", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int cx = (int) client.field_1724.method_23317() >> 4;
        int cz = (int) client.field_1724.method_23321() >> 4;
        int localX = ((int) client.field_1724.method_23317() % 16 + 16) % 16;
        int localZ = ((int) client.field_1724.method_23321() % 16 + 16) % 16;
        return "\u00A7e\u25A3 Chunk [" + cx + ", " + cz + "] (" + localX + ", " + localZ + ")";
    }
}
