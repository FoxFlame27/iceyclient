package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class InventorySlotsModule extends HudModule {
    public InventorySlotsModule() {
        super("invslots", "Inventory Slots", 5, 520);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        var inv = client.field_1724.method_31548();
        int free = 0;
        int main = 36;
        for (int i = 0; i < main; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7960()) free++;
        }
        String color = free > 20 ? "\u00A7a" : free > 5 ? "\u00A7e" : "\u00A7c";
        return color + "\uD83D\uDCE6 " + free + "/" + main + " free";
    }
}
