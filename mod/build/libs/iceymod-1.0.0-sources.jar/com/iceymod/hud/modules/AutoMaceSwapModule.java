package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

/**
 * Auto-swaps to your mace when you start falling, so you never miss a
 * smash because you forgot to switch weapons. Only swaps if you have a
 * mace somewhere in the hotbar and aren't already holding it.
 */
public class AutoMaceSwapModule extends HudModule {
    private int previousSlot = -1;
    private boolean wasAirborne = false;

    public AutoMaceSwapModule() {
        super("automaceswap", "Auto Mace Swap", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        boolean airborne = !client.field_1724.method_24828() && client.field_1724.field_6017 > 1.0f;

        if (airborne && !wasAirborne) {
            // Started falling — look for a mace to swap to
            if (!client.field_1724.method_6047().method_31574(class_1802.field_49814)) {
                var inv = client.field_1724.method_31548();
                int currentSlot = client.field_1724.method_31548().method_67532();
                for (int i = 0; i < 9; i++) {
                    class_1799 s = inv.method_5438(i);
                    if (s.method_31574(class_1802.field_49814)) {
                        previousSlot = currentSlot;
                        inv.method_61496(i);
                        break;
                    }
                }
            }
        } else if (!airborne && wasAirborne && previousSlot >= 0 && previousSlot < 9) {
            // Landed — restore previous slot
            client.field_1724.method_31548().method_61496(previousSlot);
            previousSlot = -1;
        }

        wasAirborne = airborne;
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
