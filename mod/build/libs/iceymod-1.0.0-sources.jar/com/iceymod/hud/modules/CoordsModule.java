package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class CoordsModule extends HudModule {
    public CoordsModule() {
        super("coords", "Coords", 5, 39);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        return String.format("%.1f / %.1f / %.1f",
                client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
    }
}
