package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ArmorModule extends HudModule {
    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    // Per-slot sizing
    private static final int SLOT_SIZE = 20;
    private static final int ITEM_SIZE = 16;
    private static final int BAR_WIDTH = 16;
    private static final int SLOT_GAP = 2;

    public final com.iceymod.hud.settings.IntSetting barHeight = addSetting(
            new com.iceymod.hud.settings.IntSetting("barHeight", "Bar Height", 2, 1, 4));
    public final com.iceymod.hud.settings.BoolSetting showHeldItem = addSetting(
            new com.iceymod.hud.settings.BoolSetting("showHeld", "Show Held Item", true));

    public ArmorModule() {
        super("armor", "Armor", 5, 150);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        return null;
    }

    @Override
    public void render(class_332 context, class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        int bx = getX();
        int by = getY();
        this.width = ITEM_SIZE;

        int drawn = 0;
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960()) {
                drawSlot(context, stack, bx, by + drawn * (SLOT_SIZE + SLOT_GAP));
                drawn++;
            }
        }

        // Held item too
        if (showHeldItem.get()) {
            class_1799 held = client.field_1724.method_6047();
            if (!held.method_7960()) {
                drawSlot(context, held, bx, by + drawn * (SLOT_SIZE + SLOT_GAP));
                drawn++;
            }
        }

        this.height = Math.max(drawn * (SLOT_SIZE + SLOT_GAP) - SLOT_GAP, SLOT_SIZE);
    }

    private void drawSlot(class_332 context, class_1799 stack, int x, int y) {
        // Item icon
        context.method_51427(stack, x, y);

        // Durability bar directly under the item
        if (stack.method_7963()) {
            int max = stack.method_7936();
            int dmg = stack.method_7919();
            int remaining = max - dmg;
            float ratio = (float) remaining / max;
            int color = getDurabilityColor(ratio);

            int barY = y + ITEM_SIZE + 1;
            int bh = barHeight.get();
            context.method_25294(x, barY, x + BAR_WIDTH, barY + bh, 0xFF222222);
            int fillW = Math.max(1, (int) (BAR_WIDTH * ratio));
            context.method_25294(x, barY, x + fillW, barY + bh, color);
        }
    }

    /**
     * Color gradient:
     * 100-75% → green
     * 75-50%  → yellow
     * 50-25%  → orange
     * 25-0%   → red
     */
    private int getDurabilityColor(float ratio) {
        if (ratio > 0.75f) return 0xFF4ADE80;       // green
        else if (ratio > 0.50f) return 0xFFFBBF24;  // yellow
        else if (ratio > 0.25f) return 0xFFFB923C;  // orange
        else return 0xFFF87171;                      // red
    }
}
