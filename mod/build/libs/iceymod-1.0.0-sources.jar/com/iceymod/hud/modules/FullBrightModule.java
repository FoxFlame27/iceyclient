package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import com.iceymod.mixin.SimpleOptionAccessor;
import net.minecraft.class_310;
import net.minecraft.class_7172;

/**
 * Forces gamma high enough to see in caves without torches. Uses a
 * SimpleOption accessor to bypass the gamma validator's 0-1 cap.
 */
public class FullBrightModule extends HudModule {
    public final com.iceymod.hud.settings.DoubleSetting brightness = addSetting(
            new com.iceymod.hud.settings.DoubleSetting("brightness", "Brightness", 15.0, 1.0, 20.0, 1.0));
    private Double savedGamma = null;

    public FullBrightModule() {
        super("fullbright", "Full Bright", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void setEnabled(boolean enabled) {
        if (!enabled && savedGamma != null) {
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1690 != null) {
                try {
                    ((SimpleOptionAccessor) (Object) client.field_1690.method_42473()).iceymod$setRawValue(savedGamma);
                } catch (Throwable ignored) {}
            }
            savedGamma = null;
        }
        super.setEnabled(enabled);
    }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        class_7172<Double> gamma = client.field_1690.method_42473();
        if (savedGamma == null) savedGamma = gamma.method_41753();
        double target = brightness.get();
        if (!Double.valueOf(target).equals(gamma.method_41753())) {
            try {
                ((SimpleOptionAccessor) (Object) gamma).iceymod$setRawValue(target);
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
