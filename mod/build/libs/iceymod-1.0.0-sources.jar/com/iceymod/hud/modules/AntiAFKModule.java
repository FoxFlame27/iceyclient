package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

/**
 * Rotates the player slightly every 2 minutes so the server doesn't flag
 * you as AFK and kick you.
 */
public class AntiAFKModule extends HudModule {
    public final com.iceymod.hud.settings.IntSetting intervalMinutes = addSetting(
            new com.iceymod.hud.settings.IntSetting("intervalMin", "Interval (min)", 2, 1, 10));
    public final com.iceymod.hud.settings.BoolSetting swingHand = addSetting(
            new com.iceymod.hud.settings.BoolSetting("swing", "Swing Hand", true));
    private long lastActionAt = 0;

    public AntiAFKModule() {
        super("antiafk", "Anti-AFK", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        long now = System.currentTimeMillis();
        if (lastActionAt == 0) { lastActionAt = now; return; }
        long intervalMs = intervalMinutes.get() * 60_000L;
        if (now - lastActionAt < intervalMs) return;

        client.field_1724.method_36456(client.field_1724.method_36454() + 1.0f);
        if (swingHand.get()) client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        lastActionAt = now;
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
