package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

/**
 * Auto-swaps a Totem of Undying into your off-hand if you have one in
 * your main inventory and nothing useful is there already.
 */
public class AutoTotemModule extends HudModule {
    public final com.iceymod.hud.settings.IntSetting minHealth = addSetting(
            new com.iceymod.hud.settings.IntSetting("minHealth", "Swap Below HP", 20, 1, 20));
    public final com.iceymod.hud.settings.IntSetting delayMs = addSetting(
            new com.iceymod.hud.settings.IntSetting("delayMs", "Swap Delay (ms)", 400, 100, 2000, 100));
    private long lastSwapAt = 0;

    public AutoTotemModule() {
        super("autototem", "Auto Totem", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1761 == null) return;
        if (client.field_1755 != null) return;

        long now = System.currentTimeMillis();
        if (now - lastSwapAt < delayMs.get()) return;
        if (client.field_1724.method_6032() > minHealth.get()) return;

        class_1799 off = client.field_1724.method_6079();
        if (off.method_31574(class_1802.field_8288)) return;
        if (off.method_31574(class_1802.field_8255)) return; // don't steal shield slot

        var inv = client.field_1724.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) {
                int syncId = client.field_1724.field_7498.field_7763;
                // Slot 40 is the off-hand in the player screen handler
                int sourceSlot = i < 9 ? 36 + i : i;
                try {
                    client.field_1761.method_2906(syncId, sourceSlot, 40, class_1713.field_7791, client.field_1724);
                    lastSwapAt = now;
                } catch (Throwable ignored) {}
                return;
            }
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
