package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public class TotemCountModule extends HudModule {
    public TotemCountModule() {
        super("totems", "Totems", 5, 235);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int count = 0;
        var inv = client.field_1724.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(class_1802.field_8288)) count += s.method_7947();
        }
        String color = count >= 3 ? "\u00A7a" : count >= 1 ? "\u00A7e" : "\u00A7c";
        return color + "\u2620 " + count + " totems";
    }
}
