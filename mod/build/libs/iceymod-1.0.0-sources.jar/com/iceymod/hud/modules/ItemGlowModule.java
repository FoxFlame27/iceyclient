package com.iceymod.hud.modules;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.settings.BoolSetting;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Forces a vanilla glow outline on dropped items the user cares about,
 * so a mace dropped from an Ominous Vault under a pile of gold or a
 * totem of undying after a raid stands out instantly. The actual
 * "isGlowing → true" override is done in
 * {@link com.iceymod.mixin.EntityIsGlowingMixin} which calls
 * {@link #shouldGlow(class_1799)} below.
 */
public class ItemGlowModule extends HudModule {
    public final BoolSetting mace        = addSetting(new BoolSetting("mace",        "Mace",                true));
    public final BoolSetting totem       = addSetting(new BoolSetting("totem",       "Totem of Undying",    true));
    public final BoolSetting netherite   = addSetting(new BoolSetting("netherite",   "Netherite Items",     true));
    public final BoolSetting netheriteBlocks = addSetting(new BoolSetting("netheriteBlocks", "Netherite Block / Ancient Debris", true));
    public final BoolSetting elytra      = addSetting(new BoolSetting("elytra",      "Elytra",              true));
    public final BoolSetting beacon      = addSetting(new BoolSetting("beacon",      "Beacon",              true));
    public final BoolSetting netherStar  = addSetting(new BoolSetting("netherStar",  "Nether Star",         true));
    public final BoolSetting dragonEgg   = addSetting(new BoolSetting("dragonEgg",   "Dragon Egg",          true));
    public final BoolSetting heartOfSea  = addSetting(new BoolSetting("heartOfSea",  "Heart of the Sea",    true));
    public final BoolSetting trident     = addSetting(new BoolSetting("trident",     "Trident",             true));
    public final BoolSetting shulkerShell= addSetting(new BoolSetting("shulkerShell","Shulker Shell",       true));
    public final BoolSetting enchantedBook = addSetting(new BoolSetting("enchantedBook", "Enchanted Book",  false));

    public ItemGlowModule() {
        super("itemglow", "Item Glow", 0, 0);
        setEnabled(true);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(class_332 context, class_310 client) {}

    /**
     * Called from EntityIsGlowingMixin to decide whether a given dropped
     * ItemEntity should appear glowing client-side.
     */
    public static boolean shouldGlow(class_1542 entity) {
        if (entity == null) return false;
        ItemGlowModule mod = find();
        if (mod == null || !mod.isEnabled()) return false;
        return mod.shouldGlow(entity.method_6983());
    }

    public boolean shouldGlow(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (mace.get() && stack.method_31574(class_1802.field_49814)) return true;
        if (totem.get() && stack.method_31574(class_1802.field_8288)) return true;
        if (netherite.get() && (
                stack.method_31574(class_1802.field_22020)
             || stack.method_31574(class_1802.field_22021)
             || stack.method_31574(class_1802.field_22022)
             || stack.method_31574(class_1802.field_22025)
             || stack.method_31574(class_1802.field_22024)
             || stack.method_31574(class_1802.field_22023)
             || stack.method_31574(class_1802.field_22026)
             || stack.method_31574(class_1802.field_22027)
             || stack.method_31574(class_1802.field_22028)
             || stack.method_31574(class_1802.field_22029)
             || stack.method_31574(class_1802.field_22030))) return true;
        if (netheriteBlocks.get() && (
                stack.method_31574(class_1802.field_22018)
             || stack.method_31574(class_1802.field_22019))) return true;
        if (elytra.get() && stack.method_31574(class_1802.field_8833)) return true;
        if (beacon.get() && stack.method_31574(class_1802.field_8668)) return true;
        if (netherStar.get() && stack.method_31574(class_1802.field_8137)) return true;
        if (dragonEgg.get() && stack.method_31574(class_1802.field_8840)) return true;
        if (heartOfSea.get() && stack.method_31574(class_1802.field_8207)) return true;
        if (trident.get() && stack.method_31574(class_1802.field_8547)) return true;
        if (shulkerShell.get() && stack.method_31574(class_1802.field_8815)) return true;
        if (enchantedBook.get() && stack.method_31574(class_1802.field_8598)) return true;
        return false;
    }

    private static ItemGlowModule find() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof ItemGlowModule ig) return ig;
        }
        return null;
    }
}
