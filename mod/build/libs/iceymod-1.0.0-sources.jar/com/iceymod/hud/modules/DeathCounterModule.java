package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public class DeathCounterModule extends HudModule {
    private static int deaths = 0;
    private static boolean wasDead = false;
    private static boolean registered = false;

    public DeathCounterModule() {
        super("deaths", "Deaths", 5, 280);
        setEnabled(false);
        registerTracker();
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            boolean dead = client.field_1724.method_29504() || client.field_1724.method_6032() <= 0;
            if (dead && !wasDead) deaths++;
            wasDead = dead;
        });
    }

    @Override
    public String getText(class_310 client) {
        return "\u00A7c\u2620 " + deaths + " deaths";
    }
}
