package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class AttackCooldownModule extends HudModule {
    public AttackCooldownModule() {
        super("cooldown", "Attack Cooldown", 5, 205);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        float p = client.field_1724.method_7261(0f);
        int pct = Math.round(p * 100f);
        String color = pct >= 100 ? "\u00A7a" : pct >= 50 ? "\u00A7e" : "\u00A7c";
        return color + "\u2694 " + pct + "%";
    }
}
