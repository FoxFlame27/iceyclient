package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class PitchYawModule extends HudModule {
    public PitchYawModule() {
        super("pitchyaw", "Pitch/Yaw", 5, 470);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        float yaw = client.field_1724.method_36454();
        float pitch = client.field_1724.method_36455();
        return String.format("\u00A7bY:%.0f\u00B0 \u00A7aP:%.0f\u00B0", yaw, pitch);
    }
}
