package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class BiomeModule extends HudModule {
    public BiomeModule() {
        super("biome", "Biome", 5, 275);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        try {
            var biome = client.field_1687.method_23753(client.field_1724.method_24515());
            var key = biome.method_40230().orElse(null);
            if (key == null) return "Unknown";
            String path = key.method_29177().method_12832();
            // Capitalize and replace underscores
            String[] words = path.split("_");
            StringBuilder sb = new StringBuilder();
            for (String w : words) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
            }
            return sb.toString();
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
