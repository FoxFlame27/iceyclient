package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class WeatherModule extends HudModule {
    public WeatherModule() {
        super("weather", "Weather", 5, 460);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1687 == null) return null;
        if (client.field_1687.method_8546()) return "\u00A7e\u26C8 Thunder";
        if (client.field_1687.method_8419()) return "\u00A7b\u2614 Rain";
        return "\u00A7a\u2600 Clear";
    }
}
