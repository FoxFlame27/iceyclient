package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

/**
 * Shows total arrow count in inventory (like Lunar's arrow counter).
 */
public class ArrowCountModule extends HudModule {
    public ArrowCountModule() {
        super("arrows", "Arrows", 5, 215);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int count = 0;
        var inventory = client.field_1724.method_31548();
        int size = inventory.method_5439();
        for (int i = 0; i < size; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_31574(class_1802.field_8107) || stack.method_31574(class_1802.field_8236) || stack.method_31574(class_1802.field_8087)) {
                count += stack.method_7947();
            }
        }
        if (count == 0) return "\u00A78No arrows";
        return "\u00A7e\u27B3 " + count;
    }
}
