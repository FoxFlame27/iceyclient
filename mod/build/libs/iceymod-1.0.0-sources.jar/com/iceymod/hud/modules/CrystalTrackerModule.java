package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_310;

public class CrystalTrackerModule extends HudModule {
    public CrystalTrackerModule() {
        super("crystaltracker", "Crystals", 5, 100);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        int count = 0;
        double range = 8.0;
        for (class_1297 e : client.field_1687.method_18112()) {
            if (e instanceof class_1511 && e.method_5739(client.field_1724) <= range) count++;
        }
        String color = count >= 3 ? "\u00A7c" : count >= 1 ? "\u00A7e" : "\u00A78";
        return color + "\u2756 " + count + " Crystals";
    }
}
