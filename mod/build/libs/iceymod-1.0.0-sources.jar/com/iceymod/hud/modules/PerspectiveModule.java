package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_5498;

/**
 * Freelook-style perspective cycling. Press the keybind (R) to cycle
 * through 1st person -> 3rd person back -> 3rd person front.
 */
public class PerspectiveModule extends HudModule {

    public PerspectiveModule() {
        super("perspective", "Perspective", 0, 0);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    public void cyclePerspective() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        class_5498 current = client.field_1690.method_31044();
        class_5498 next;
        if (current == class_5498.field_26664) next = class_5498.field_26665;
        else if (current == class_5498.field_26665) next = class_5498.field_26666;
        else next = class_5498.field_26664;
        client.field_1690.method_31043(next);
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
