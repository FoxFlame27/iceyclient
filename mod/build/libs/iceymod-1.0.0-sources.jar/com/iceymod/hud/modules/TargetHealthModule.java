package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public class TargetHealthModule extends HudModule {
    public TargetHealthModule() {
        super("targethealth", "Target Health", 5, 130);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_239 r = client.field_1765;
        if (!(r instanceof class_3966)) return "\u00A78No target";
        class_1297 e = ((class_3966) r).method_17782();
        if (!(e instanceof class_1309)) return "\u00A78No target";
        class_1309 le = (class_1309) e;
        float hp = le.method_6032();
        float max = le.method_6063();
        String color = hp > max * 0.66f ? "\u00A7a" : hp > max * 0.33f ? "\u00A7e" : "\u00A7c";
        return color + "\u2764 " + String.format("%.1f", hp) + "/" + String.format("%.0f", max);
    }
}
