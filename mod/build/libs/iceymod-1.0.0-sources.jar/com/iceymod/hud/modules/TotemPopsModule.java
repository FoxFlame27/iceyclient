package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import java.util.HashMap;
import java.util.Map;

public class TotemPopsModule extends HudModule {
    private static int pops = 0;
    private static final Map<Integer, Float> lastHealth = new HashMap<>();
    private static boolean registered = false;

    public TotemPopsModule() {
        super("totempops", "Totem Pops", 5, 115);
        setEnabled(false);
        registerTracker();
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || client.field_1724 == null) return;
            for (class_1297 e : client.field_1687.method_18112()) {
                if (!(e instanceof class_1657) || e == client.field_1724) continue;
                class_1309 le = (class_1309) e;
                Float prev = lastHealth.get(e.method_5628());
                if (prev != null && prev <= 0.5f && le.method_6032() > 5f) pops++;
                lastHealth.put(e.method_5628(), le.method_6032());
            }
        });
    }

    public static void reset() { pops = 0; lastHealth.clear(); }

    @Override
    public String getText(class_310 client) {
        return "\u00A7d\u2726 " + pops + " Pops";
    }
}
