package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import java.util.Collection;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;

/**
 * Shows active potion effects with remaining duration.
 */
public class PotionModule extends HudModule {
    public PotionModule() {
        super("potions", "Potions", 5, 124);
        setEnabled(false);
    }


    @Override
    public String getText(class_310 client) {
        return null; // custom rendering
    }

    @Override
    public void render(class_332 context, class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;

        Collection<class_1293> effects = client.field_1724.method_6026();
        if (effects.isEmpty()) {
            this.width = client.field_1772.method_1727("No effects") + 10;
            this.height = 14;
            context.method_25294(getX(), getY(), getX() + width, getY() + height, 0x90000000);
            context.method_25294(getX(), getY(), getX() + 2, getY() + height, 0xFF5BC8F5);
            context.method_25303(client.field_1772, "No effects", getX() + 6, getY() + 3, 0xFF888888);
            return;
        }

        int bx = getX();
        int by = getY();
        int maxWidth = 0;
        int row = 0;

        for (class_1293 effect : effects) {
            class_6880<class_1291> effectType = effect.method_5579();
            String name = effectType.comp_349().method_5560().getString();
            int amp = effect.method_5578();
            String ampStr = amp > 0 ? " " + toRoman(amp + 1) : "";
            String duration = formatDuration(effect.method_5584());

            // Green for beneficial, red for harmful
            int color;
            try {
                color = effectType.comp_349().method_5573() ? 0xFF4ADE80 : 0xFFF87171;
            } catch (Exception e) {
                color = 0xFFCCCCCC;
            }

            String line = name + ampStr + " \u00A77" + duration;
            int lineW = client.field_1772.method_1727(line) + 10;
            if (lineW > maxWidth) maxWidth = lineW;

            int lineY = by + row * 14;
            context.method_25294(bx, lineY, bx + lineW, lineY + 13, 0x90000000);
            context.method_25294(bx, lineY, bx + 2, lineY + 13, color);
            context.method_25303(client.field_1772, line, bx + 6, lineY + 3, color);
            row++;
        }

        this.width = maxWidth;
        this.height = Math.max(row * 14, 14);
    }

    private String formatDuration(int ticks) {
        if (ticks < 0) return "\u221E";
        int secs = ticks / 20;
        int min = secs / 60;
        int sec = secs % 60;
        return String.format("%d:%02d", min, sec);
    }

    private String toRoman(int n) {
        String[] romans = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        if (n > 0 && n < romans.length) return romans[n];
        return String.valueOf(n);
    }
}
