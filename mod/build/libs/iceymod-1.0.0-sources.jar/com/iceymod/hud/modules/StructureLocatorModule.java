package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import com.iceymod.hud.settings.BoolSetting;
import com.iceymod.hud.settings.IntSetting;
import com.iceymod.structure.StructureTracker;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * HUD widget that lists nearby detected structures (trial chambers,
 * strongholds, player bases) with distance + direction arrow. The actual
 * detection lives in {@link StructureTracker}; this module just owns the
 * toggles and renders what the tracker found.
 */
public class StructureLocatorModule extends HudModule {
    public final BoolSetting trialChambers    = addSetting(new BoolSetting("trialChambers",    "Trial Chambers",   true));
    public final BoolSetting strongholds      = addSetting(new BoolSetting("strongholds",      "Strongholds",      true));
    public final BoolSetting playerBases      = addSetting(new BoolSetting("playerBases",      "Player Bases",     true));
    public final BoolSetting netherFortresses = addSetting(new BoolSetting("netherFortresses", "Nether Fortresses",true));
    public final BoolSetting bastions         = addSetting(new BoolSetting("bastions",         "Bastion Remnants", true));
    public final BoolSetting endCities        = addSetting(new BoolSetting("endCities",        "End Cities",       true));
    public final BoolSetting endGateways      = addSetting(new BoolSetting("endGateways",      "End Gateways",     true));
    public final BoolSetting oceanMonuments   = addSetting(new BoolSetting("oceanMonuments",   "Ocean Monuments",  true));
    public final BoolSetting ancientCities    = addSetting(new BoolSetting("ancientCities",    "Ancient Cities",   true));
    public final BoolSetting ruinedPortals    = addSetting(new BoolSetting("ruinedPortals",    "Ruined Portals",   false));
    public final BoolSetting desertPyramids   = addSetting(new BoolSetting("desertPyramids",   "Desert Pyramids",  true));
    public final BoolSetting villages         = addSetting(new BoolSetting("villages",         "Villages",         false));
    public final BoolSetting autoWaypoint     = addSetting(new BoolSetting("autoWaypoint",     "Auto-Waypoint on Discovery", true));
    public final IntSetting maxShown          = addSetting(new IntSetting("maxShown",          "Max Shown", 4, 1, 10));

    public StructureLocatorModule() {
        super("structurelocator", "Structure Locator", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(class_332 context, class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;

        List<StructureTracker.Found> all = StructureTracker.getSortedByDistance();
        if (all.isEmpty()) {
            // Minimal "scanning…" row so the user can tell the module is on and working
            String empty = "§7Scanning chunks…";
            int tw = client.field_1772.method_1727(empty);
            this.width = tw + 10;
            this.height = 14;
            context.method_25294(getX(), getY(), getX() + this.width, getY() + this.height, 0x90000000);
            context.method_25294(getX(), getY(), getX() + 2, getY() + this.height, 0xFF5BC8F5);
            context.method_25303(client.field_1772, empty, getX() + 6, getY() + 3, 0xFFFFFFFF);
            return;
        }

        int limit = Math.min(all.size(), maxShown.get());
        int lineH = 14;
        int gap = 2;
        int rowH = lineH + gap;

        String[] texts = new String[limit];
        int maxWidth = 0;
        int[] colors = new int[limit];

        float yaw = client.field_1724.method_36454();
        for (int i = 0; i < limit; i++) {
            StructureTracker.Found f = all.get(i);
            double dx = f.pos.method_10263() - client.field_1724.method_23317();
            double dy = f.pos.method_10264() - client.field_1724.method_23318();
            double dz = f.pos.method_10260() - client.field_1724.method_23321();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            double angle = Math.toDegrees(Math.atan2(-dx, dz));
            double rel = ((angle - yaw) % 360 + 540) % 360 - 180;
            String arrow;
            if      (rel > -22.5  && rel <=  22.5)  arrow = "↑";
            else if (rel >  22.5  && rel <=  67.5)  arrow = "↗";
            else if (rel >  67.5  && rel <= 112.5)  arrow = "→";
            else if (rel > 112.5  && rel <= 157.5)  arrow = "↘";
            else if (rel > 157.5  || rel <= -157.5) arrow = "↓";
            else if (rel > -157.5 && rel <= -112.5) arrow = "↙";
            else if (rel > -112.5 && rel <=  -67.5) arrow = "←";
            else                                    arrow = "↖";

            texts[i] = arrow + " " + f.type.label + " " + (int) dist + "m";
            colors[i] = f.type.color;
            int tw = client.field_1772.method_1727(texts[i]);
            if (tw > maxWidth) maxWidth = tw;
        }
        this.width = maxWidth + 10;

        int x = getX(), y = getY();
        for (int i = 0; i < limit; i++) {
            int lineY = y + i * rowH;
            context.method_25294(x, lineY, x + this.width, lineY + lineH, 0x90000000);
            context.method_25294(x, lineY, x + 2, lineY + lineH, colors[i]);
            context.method_25303(client.field_1772, texts[i], x + 6, lineY + 3, 0xFFFFFFFF);
        }
        this.height = limit * rowH - gap;
    }
}
