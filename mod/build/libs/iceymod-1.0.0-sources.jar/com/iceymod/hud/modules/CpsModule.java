package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;

public class CpsModule extends HudModule {
    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public CpsModule() {
        super("cps", "CPS", 5, 56);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        long now = System.currentTimeMillis();

        // Detect new left clicks (attack)
        boolean leftDown = client.field_1690.field_1886.method_1434();
        if (leftDown && !wasLeftPressed) leftClicks.add(now);
        wasLeftPressed = leftDown;

        // Detect new right clicks (use)
        boolean rightDown = client.field_1690.field_1904.method_1434();
        if (rightDown && !wasRightPressed) rightClicks.add(now);
        wasRightPressed = rightDown;

        // Remove clicks older than 1 second
        leftClicks.removeIf(t -> now - t > 1000);
        rightClicks.removeIf(t -> now - t > 1000);
    }

    @Override
    public String getText(class_310 client) {
        return leftClicks.size() + " | " + rightClicks.size() + " CPS";
    }
}
