package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1937;
import net.minecraft.class_310;

public class NetherCoordsModule extends HudModule {
    public NetherCoordsModule() {
        super("nethercoords", "Nether Coords", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        double x = client.field_1724.method_23317();
        double z = client.field_1724.method_23321();
        boolean inNether = client.field_1687.method_27983() == class_1937.field_25180;
        if (inNether) {
            return "\u00A7a\u2302 OW: " + (int)(x * 8) + ", " + (int)(z * 8);
        }
        return "\u00A7c\u2302 Nether: " + (int)(x / 8) + ", " + (int)(z / 8);
    }
}
