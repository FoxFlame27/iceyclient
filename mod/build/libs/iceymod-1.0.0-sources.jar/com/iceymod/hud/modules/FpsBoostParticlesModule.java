package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_4066;

/**
 * Invisible FPS booster: forces particles to MINIMAL while enabled.
 */
public class FpsBoostParticlesModule extends HudModule {
    private class_4066 previous = null;

    public FpsBoostParticlesModule() {
        super("fpsboost_particles", "FPS: Minimal Particles", 0, 0);
    }

    @Override
    public Category getCategory() { return Category.OPTIMIZATION; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        class_4066 cur = client.field_1690.method_42475().method_41753();
        if (cur != class_4066.field_18199) {
            if (previous == null) previous = cur;
            client.field_1690.method_42475().method_41748(class_4066.field_18199);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
