package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class NearestPlayerModule extends HudModule {
    public NearestPlayerModule() {
        super("nearestplayer", "Nearest Player", 5, 415);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        double min = Double.MAX_VALUE;
        class_1657 nearest = null;
        for (class_1297 e : client.field_1687.method_18112()) {
            if (!(e instanceof class_1657) || e == client.field_1724) continue;
            double d = e.method_5739(client.field_1724);
            if (d < min) { min = d; nearest = (class_1657) e; }
        }
        if (nearest == null) return "\u00A78No players";
        String color = min < 8 ? "\u00A7c" : min < 20 ? "\u00A7e" : "\u00A7a";
        return color + nearest.method_5477().getString() + " " + String.format("%.1f", min) + "m";
    }
}
