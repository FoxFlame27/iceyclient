package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class AirModule extends HudModule {
    public AirModule() {
        super("air", "Air", 5, 530);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int air = client.field_1724.method_5669();
        int max = client.field_1724.method_5748();
        if (air >= max) return null; // hide when full air (on land)
        int pct = (int) (((float) air / max) * 100);
        String color = pct < 25 ? "\u00A7c" : pct < 50 ? "\u00A7e" : "\u00A7b";
        return color + "Air: " + pct + "%";
    }
}
