package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class LookingAtModule extends HudModule {
    public LookingAtModule() {
        super("lookat", "Looking At", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        class_239 hit = client.field_1765;
        if (hit == null) return "\u00A78Nothing";
        if (hit instanceof class_3966 ehr) {
            class_1297 e = ehr.method_17782();
            String name = e.method_5477().getString();
            if (e instanceof class_1309 le) {
                return "\u00A7b\u25BA " + name + " \u00A77" + String.format("%.1f", le.method_6032()) + "HP";
            }
            return "\u00A7b\u25BA " + name;
        }
        if (hit instanceof class_3965 bhr) {
            class_2338 pos = bhr.method_17777();
            class_2680 state = client.field_1687.method_8320(pos);
            String name = state.method_26204().method_9518().getString();
            return "\u00A7e\u25BA " + name;
        }
        return "\u00A78Nothing";
    }
}
