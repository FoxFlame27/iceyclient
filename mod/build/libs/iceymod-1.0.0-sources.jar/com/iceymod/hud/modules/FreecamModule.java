package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import com.iceymod.hud.settings.DoubleSetting;
import net.minecraft.class_310;
import net.minecraft.class_5498;

/**
 * Spectator-style freecam: detached camera that flies around with WASD
 * while the player stays in place. The camera position + rotation are
 * fully independent of the player.
 *
 * - Activation: toggle via the freecam keybind (default F4).
 * - Movement:   WASD (relative to camera yaw), Space = up, Shift = down,
 *               Sprint key (Ctrl) = ~3x speed.
 * - Look:       mouse rotates the freecam (rerouted in EntityLookMixin).
 * - Player:     KeyboardInputMixin zeroes movementForward/Sideways +
 *               jumping/sneaking while freecam is active so vanilla input
 *               doesn't make the player walk away under you.
 *
 * The actual position + rotation overrides happen in CameraMixin, which
 * already wraps everything in try/catch so a 1.21.11 API drift won't
 * crash render.
 */
public class FreecamModule extends HudModule {

    private static boolean active = false;
    private static double posX, posY, posZ;
    private static float yaw, pitch;
    private static class_5498 savedPerspective = null;

    // Block-per-tick base; multiplied by 20 internally to derive blocks/sec.
    public final DoubleSetting moveSpeed = addSetting(
            new DoubleSetting("moveSpeed", "Move Speed", 0.5, 0.05, 5.0, 0.05));
    public final DoubleSetting sprintMul = addSetting(
            new DoubleSetting("sprintMul", "Sprint Multiplier", 3.0, 1.0, 10.0, 0.5));

    // Anchor module instance so the static frame loop can read settings.
    private static FreecamModule INSTANCE;
    private static long lastFrameNanos = 0L;

    public FreecamModule() {
        super("freecam", "Freecam", 0, 0);
        setEnabled(true);
        INSTANCE = this;
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    public static boolean isActive() { return active; }
    // Renamed to avoid clashing with HudModule.getX()/getY() (instance methods).
    public static double camX() { return posX; }
    public static double camY() { return posY; }
    public static double camZ() { return posZ; }
    public static float camYaw() { return yaw; }
    public static float camPitch() { return pitch; }

    /** Toggle on/off. Called from the keybind. */
    public void toggle(class_310 client) {
        if (active) stop(client);
        else        start(client);
    }

    public void start(class_310 client) {
        if (active || client == null || client.field_1724 == null) return;
        if (!isEnabled()) return;
        active = true;
        lastFrameNanos = 0L; // Reset delta-time so the first frame doesn't jump.
        var eye = client.field_1724.method_33571();
        posX = eye.field_1352;
        posY = eye.field_1351;
        posZ = eye.field_1350;
        yaw = client.field_1724.method_36454();
        pitch = client.field_1724.method_36455();

        if (client.field_1690 != null) {
            savedPerspective = client.field_1690.method_31044();
            if (savedPerspective == class_5498.field_26664) {
                client.field_1690.method_31043(class_5498.field_26665);
            } else {
                savedPerspective = null;
            }
        }
        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                    net.minecraft.class_2561.method_43470("§b[Icey] §aFreecam ON §7— WASD to fly, key again to exit"),
                    true);
        }
    }

    public void stop(class_310 client) {
        if (!active) return;
        active = false;
        if (savedPerspective != null && client != null && client.field_1690 != null) {
            client.field_1690.method_31043(savedPerspective);
        }
        savedPerspective = null;
        if (client != null && client.field_1724 != null) {
            client.field_1724.method_7353(
                    net.minecraft.class_2561.method_43470("§b[Icey] §7Freecam off"), true);
        }
    }

    /** Disabling the module turns freecam off immediately. */
    @Override
    public void setEnabled(boolean enabled) {
        if (!enabled && active) stop(class_310.method_1551());
        super.setEnabled(enabled);
    }

    /** Mouse-look while in freecam. Routed from EntityLookMixin. */
    public static void applyDelta(double cursorDeltaX, double cursorDeltaY) {
        yaw   = (yaw + (float) cursorDeltaX * 0.15f) % 360f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) cursorDeltaY * 0.15f));
    }

    /**
     * Per-FRAME movement. Called from CameraMixin before each frame's
     * setPos so motion stays smooth at render rate (60+ fps) instead of
     * stepping at the 20 Hz tick rate. Also clamps the camera within
     * the player's chunk-load radius — the server only sends chunks
     * around the player, so flying outside that range gives you a
     * blank/stale view.
     */
    public static void updatePerFrame() {
        if (!active || INSTANCE == null) return;
        class_310 c = class_310.method_1551();
        if (c == null || c.field_1690 == null || c.field_1724 == null) return;

        long now = System.nanoTime();
        double dt;
        if (lastFrameNanos == 0L) {
            dt = 0.0;
        } else {
            dt = (now - lastFrameNanos) / 1_000_000_000.0;
            // Cap so a hitch / pause doesn't teleport the camera.
            if (dt > 0.1) dt = 0.1;
        }
        lastFrameNanos = now;

        // Don't read movement keys when a non-chat screen is open —
        // typing in inventory shouldn't fly the camera.
        boolean inputActive = c.field_1755 == null
                || c.field_1755 instanceof net.minecraft.class_408;

        if (inputActive && dt > 0.0) {
            boolean fwd    = c.field_1690.field_1894.method_1434();
            boolean back   = c.field_1690.field_1881.method_1434();
            boolean left   = c.field_1690.field_1913.method_1434();
            boolean right  = c.field_1690.field_1849.method_1434();
            boolean up     = c.field_1690.field_1903.method_1434();
            boolean down   = c.field_1690.field_1832.method_1434();
            boolean sprint = c.field_1690.field_1867.method_1434();

            // moveSpeed setting is "blocks per tick"; 20 ticks/sec → blocks/sec.
            double speed = INSTANCE.moveSpeed.get() * 20.0;
            if (sprint) speed *= INSTANCE.sprintMul.get();

            double dx = 0, dy = 0, dz = 0;
            float yawRad = (float) Math.toRadians(yaw);
            float sinY = (float) Math.sin(yawRad);
            float cosY = (float) Math.cos(yawRad);

            if (fwd)   { dx -= sinY; dz += cosY; }
            if (back)  { dx += sinY; dz -= cosY; }
            if (left)  { dx -= cosY; dz -= sinY; }
            if (right) { dx += cosY; dz += sinY; }
            if (up)    { dy += 1.0; }
            if (down)  { dy -= 1.0; }

            double mag = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (mag > 0.001) {
                double step = speed * dt;
                posX += (dx / mag) * step;
                posY += (dy / mag) * step;
                posZ += (dz / mag) * step;
            }
        }

        // Clamp distance to the player so the camera stays inside chunks
        // the server has actually sent. View distance × 16 = block radius;
        // shave 32 so we don't sit at the very edge where chunks pop in/out.
        try {
            int viewChunks = c.field_1690.method_42503().method_41753();
            double maxDist = Math.max(64.0, viewChunks * 16.0 - 32.0);
            double px = c.field_1724.method_23317(), py = c.field_1724.method_23320(), pz = c.field_1724.method_23321();
            double rx = posX - px, ry = posY - py, rz = posZ - pz;
            double distSq = rx * rx + ry * ry + rz * rz;
            if (distSq > maxDist * maxDist) {
                double dist = Math.sqrt(distSq);
                double scale = maxDist / dist;
                posX = px + rx * scale;
                posY = py + ry * scale;
                posZ = pz + rz * scale;
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void tick() {
        // Movement now runs per frame in updatePerFrame() — see CameraMixin.
        // Keep this empty so 20 Hz tick doesn't double-apply movement.
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
