package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class FpsModule extends HudModule {
    public FpsModule() {
        super("fps", "FPS", 5, 5);
    }

    @Override
    public String getText(class_310 client) {
        return client.method_47599() + " FPS";
    }
}
