package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

/**
 * Disables view bobbing for cleaner aim.
 */
public class NoCameraBobModule extends HudModule {
    public NoCameraBobModule() {
        super("nobob", "No View Bob", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        if (client.field_1690.method_42448().method_41753()) {
            client.field_1690.method_42448().method_41748(false);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
