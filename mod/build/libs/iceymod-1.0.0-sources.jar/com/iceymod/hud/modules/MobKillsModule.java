package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MobKillsModule extends HudModule {
    private static int kills = 0;
    private static final Map<Integer, Float> trackedHealth = new HashMap<>();
    private static final Set<Integer> counted = new HashSet<>();
    private static boolean registered = false;

    public MobKillsModule() {
        super("mobkills", "Mob Kills", 0, 0);
        setEnabled(false);
        registerTracker();
    }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (entity instanceof class_1309) {
                trackedHealth.put(entity.method_5628(), ((class_1309) entity).method_6032());
            }
            return class_1269.field_5811;
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null) return;
            for (Map.Entry<Integer, Float> e : trackedHealth.entrySet()) {
                class_1297 ent = client.field_1687.method_8469(e.getKey());
                if ((ent == null || !ent.method_5805()) && !counted.contains(e.getKey())) {
                    counted.add(e.getKey());
                    kills++;
                }
            }
        });
    }

    @Override
    public String getText(class_310 client) {
        return "\u00A7a\u2694 " + kills + " kills";
    }
}
