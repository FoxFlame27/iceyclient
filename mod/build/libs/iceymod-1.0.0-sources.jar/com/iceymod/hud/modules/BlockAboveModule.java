package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;

/**
 * Shows the block the player is standing on (Lunar Client style).
 */
public class BlockAboveModule extends HudModule {
    public BlockAboveModule() {
        super("blockunder", "Block Below", 5, 350);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        class_2338 below = client.field_1724.method_24515().method_10074();
        var state = client.field_1687.method_8320(below);
        if (state.method_27852(class_2246.field_10124)) return "Air";
        return state.method_26204().method_9518().getString();
    }
}
