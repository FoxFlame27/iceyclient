package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_640;

public class PingModule extends HudModule {
    public PingModule() {
        super("ping", "Ping", 5, 22);
    }

    @Override
    public String getText(class_310 client) {
        if (client.method_1562() == null || client.field_1724 == null) return null;
        class_640 entry = client.method_1562().method_2871(client.field_1724.method_5667());
        if (entry == null) return null;
        int latency = entry.method_2959();
        // Color code based on ping
        String color;
        if (latency < 50) color = "\u00A7a";       // green
        else if (latency < 100) color = "\u00A7e";  // yellow
        else if (latency < 200) color = "\u00A76";  // gold
        else color = "\u00A7c";                      // red
        return color + latency + " ms";
    }
}
