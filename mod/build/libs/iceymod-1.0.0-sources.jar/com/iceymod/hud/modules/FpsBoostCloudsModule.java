package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_4063;

/**
 * Invisible FPS booster: disables cloud rendering while enabled.
 */
public class FpsBoostCloudsModule extends HudModule {
    public FpsBoostCloudsModule() {
        super("fpsboost_clouds", "FPS: Disable Clouds", 0, 0);
    }

    @Override
    public Category getCategory() { return Category.OPTIMIZATION; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        if (client.field_1690.method_42528().method_41753() != class_4063.field_18162) {
            client.field_1690.method_42528().method_41748(class_4063.field_18162);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
