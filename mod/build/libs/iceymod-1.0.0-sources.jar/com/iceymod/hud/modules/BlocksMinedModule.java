package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_310;

public class BlocksMinedModule extends HudModule {
    private static int mined = 0;
    private static boolean registered = false;

    public BlocksMinedModule() {
        super("blocksmined", "Blocks Mined", 5, 490);
        setEnabled(false);
        registerTracker();
    }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && player == client.field_1724) mined++;
        });
    }

    @Override
    public String getText(class_310 client) {
        return "\u00A76\u26CF " + mined + " mined";
    }
}
