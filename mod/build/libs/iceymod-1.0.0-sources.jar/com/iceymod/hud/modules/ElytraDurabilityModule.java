package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public class ElytraDurabilityModule extends HudModule {
    public ElytraDurabilityModule() {
        super("elytra", "Elytra", 5, 220);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_1799 chest = client.field_1724.method_6118(class_1304.field_6174);
        if (!chest.method_31574(class_1802.field_8833)) return "\u00A78No elytra";
        int max = chest.method_7936();
        int dmg = chest.method_7919();
        int remain = max - dmg;
        int pct = Math.round((remain / (float) max) * 100f);
        String color = pct >= 50 ? "\u00A7a" : pct >= 20 ? "\u00A7e" : "\u00A7c";
        return color + "\u25B3 " + remain + "/" + max + " (" + pct + "%)";
    }
}
