package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_310;

public class HostileMobsModule extends HudModule {
    public HostileMobsModule() {
        super("hostilecount", "Hostile Mobs", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        int count = 0;
        double range = 16.0;
        for (class_1297 e : client.field_1687.method_18112()) {
            if (e instanceof class_1588 && e.method_5739(client.field_1724) <= range) count++;
        }
        String color = count >= 5 ? "\u00A7c" : count >= 1 ? "\u00A7e" : "\u00A7a";
        return color + "\u2620 " + count + " hostile";
    }
}
