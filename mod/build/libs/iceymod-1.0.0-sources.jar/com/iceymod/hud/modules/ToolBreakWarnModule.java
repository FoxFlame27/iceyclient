package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class ToolBreakWarnModule extends HudModule {
    public ToolBreakWarnModule() {
        super("toolwarn", "Tool Break Warn", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_1799 s = client.field_1724.method_6047();
        if (s.method_7960() || !s.method_7963()) return null;
        int max = s.method_7936();
        int remain = max - s.method_7919();
        float pct = remain / (float) max;
        if (pct > 0.15f) return null;
        boolean flash = (System.currentTimeMillis() / 400) % 2 == 0;
        String color = flash ? "\u00A7c" : "\u00A76";
        return color + "\u26A0 TOOL BREAKING! " + remain + " left";
    }
}
