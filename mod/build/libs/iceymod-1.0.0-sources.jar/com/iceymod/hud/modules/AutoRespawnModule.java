package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_418;

/**
 * Auto-clicks the respawn button when you die. Saves the extra click in
 * PvP so you can get back in the fight faster.
 */
public class AutoRespawnModule extends HudModule {
    public AutoRespawnModule() {
        super("autorespawn", "Auto Respawn", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof class_418 && client.field_1724 != null) {
            client.field_1724.method_7331();
            client.method_1507(null);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
