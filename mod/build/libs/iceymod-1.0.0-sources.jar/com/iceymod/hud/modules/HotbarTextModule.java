package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

/**
 * Shows the current held item name + count.
 */
public class HotbarTextModule extends HudModule {
    public HotbarTextModule() {
        super("hotbartext", "Held Item", 5, 410);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_1799 stack = client.field_1724.method_6047();
        if (stack.method_7960()) return null;
        String name = stack.method_7964().getString();
        int count = stack.method_7947();
        return "\u00A7b" + name + (count > 1 ? " \u00A77x" + count : "");
    }
}
