package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public class DistanceWalkedModule extends HudModule {
    private static double total = 0;
    private static double lastX = Double.NaN, lastY = Double.NaN, lastZ = Double.NaN;
    private static boolean registered = false;

    public DistanceWalkedModule() {
        super("distwalked", "Distance", 5, 505);
        setEnabled(false);
        registerTracker();
    }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            double x = client.field_1724.method_23317(), y = client.field_1724.method_23318(), z = client.field_1724.method_23321();
            if (!Double.isNaN(lastX)) {
                double dx = x - lastX, dy = y - lastY, dz = z - lastZ;
                double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d < 20) total += d;
            }
            lastX = x; lastY = y; lastZ = z;
        });
    }

    @Override
    public String getText(class_310 client) {
        if (total >= 1000) return "\u00A7b\u2192 " + String.format("%.2f km", total / 1000);
        return "\u00A7b\u2192 " + String.format("%.0f m", total);
    }
}
