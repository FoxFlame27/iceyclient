package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

/**
 * Shows food saturation level (hidden stat).
 */
public class SaturationModule extends HudModule {
    public SaturationModule() {
        super("saturation", "Saturation", 5, 230);
        setEnabled(false);
    }


    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        float sat = client.field_1724.method_7344().method_7589();
        int food = client.field_1724.method_7344().method_7586();
        String color;
        if (sat > 10) color = "\u00A7a";
        else if (sat > 5) color = "\u00A7e";
        else color = "\u00A7c";
        return color + String.format("%.1f", sat) + " \u00A77sat \u00A78| \u00A76" + food + " \u00A77food";
    }
}
