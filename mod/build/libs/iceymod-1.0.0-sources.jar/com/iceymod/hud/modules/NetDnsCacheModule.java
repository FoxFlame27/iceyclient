package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import java.net.InetAddress;
import java.security.Security;
import net.minecraft.class_310;

/**
 * Invisible ping/network optimization: shortens DNS cache TTL so stale
 * routes get re-resolved, and pre-warms the current server's hostname.
 */
public class NetDnsCacheModule extends HudModule {
    private boolean applied = false;
    private long lastResolveAt = 0;

    public NetDnsCacheModule() {
        super("net_dnscache", "Net: DNS Cache Tuning", 0, 0);
    }

    @Override
    public Category getCategory() { return Category.OPTIMIZATION; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        if (!applied) {
            try {
                Security.setProperty("networkaddress.cache.ttl", "60");
                Security.setProperty("networkaddress.cache.negative.ttl", "5");
                System.setProperty("sun.net.inetaddr.ttl", "60");
                System.setProperty("sun.net.inetaddr.negative.ttl", "5");
            } catch (Throwable ignored) {}
            applied = true;
        }

        long now = System.currentTimeMillis();
        if (now - lastResolveAt < 30_000) return;
        class_310 client = class_310.method_1551();
        if (client == null || client.method_1558() == null) return;
        String addr = client.method_1558().field_3761;
        if (addr == null) return;
        String host = addr.contains(":") ? addr.substring(0, addr.indexOf(':')) : addr;
        try {
            InetAddress.getAllByName(host);
        } catch (Throwable ignored) {}
        lastResolveAt = now;
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
