package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class VelocityModule extends HudModule {
    public VelocityModule() {
        super("velocity", "Velocity", 5, 485);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_243 v = client.field_1724.method_18798();
        double horizontal = Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350);
        return String.format("\u00A7bH:%.2f \u00A7aV:%.2f", horizontal, v.field_1351);
    }
}
