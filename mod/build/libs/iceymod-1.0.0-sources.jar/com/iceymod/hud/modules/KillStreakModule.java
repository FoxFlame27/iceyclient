package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class KillStreakModule extends HudModule {
    private static int streak = 0;
    private static final Map<Integer, Float> lastHit = new HashMap<>();
    private static final Set<Integer> deadTracked = new HashSet<>();
    private static boolean registered = false;

    public KillStreakModule() {
        super("killstreak", "Kill Streak", 5, 265);
        setEnabled(false);
        registerTracker();
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    private static void registerTracker() {
        if (registered) return;
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) return;
            if (client.field_1724.method_29504()) { streak = 0; deadTracked.clear(); lastHit.clear(); return; }
            class_1297 target = client.field_1692;
            if (target instanceof class_1309 le) {
                lastHit.put(le.method_5628(), le.method_6032());
            }
            for (Map.Entry<Integer, Float> e : lastHit.entrySet()) {
                class_1297 ent = client.field_1687.method_8469(e.getKey());
                if ((ent == null || !ent.method_5805()) && !deadTracked.contains(e.getKey())) {
                    deadTracked.add(e.getKey());
                    streak++;
                }
            }
        });
    }

    @Override
    public String getText(class_310 client) {
        String color = streak >= 10 ? "\u00A7c" : streak >= 5 ? "\u00A76" : streak >= 1 ? "\u00A7a" : "\u00A78";
        return color + "\u2694 " + streak + " streak";
    }
}
