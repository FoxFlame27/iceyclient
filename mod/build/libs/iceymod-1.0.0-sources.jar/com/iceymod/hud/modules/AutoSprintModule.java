package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

/**
 * Always sprints when moving forward. Works by holding the sprint key
 * virtually, which is what the movement code checks.
 */
public class AutoSprintModule extends HudModule {
    public AutoSprintModule() {
        super("autosprint", "Auto Sprint", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void setEnabled(boolean enabled) {
        if (!enabled) {
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1690 != null) {
                client.field_1690.field_1867.method_23481(false);
            }
        }
        super.setEnabled(enabled);
    }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690 == null) return;
        boolean canSprint = client.field_1690.field_1894.method_1434()
                && !client.field_1724.method_5715()
                && !client.field_1724.method_5799()
                && client.field_1724.method_7344().method_7586() > 6;
        client.field_1690.field_1867.method_23481(canSprint);
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
