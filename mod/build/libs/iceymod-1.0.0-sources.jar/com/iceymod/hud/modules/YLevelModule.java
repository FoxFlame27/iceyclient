package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;

public class YLevelModule extends HudModule {
    public YLevelModule() {
        super("ylevel", "Y Level", 5, 425);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        int y = (int) client.field_1724.method_23318();
        String color;
        if (y < 0) color = "\u00A7c";      // red for deep
        else if (y < 40) color = "\u00A7e"; // yellow for mid
        else color = "\u00A7a";              // green for surface
        return color + "Y: " + y;
    }
}
