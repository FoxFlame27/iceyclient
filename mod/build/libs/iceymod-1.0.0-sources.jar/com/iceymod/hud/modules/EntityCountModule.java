package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_310;

/**
 * Shows total loaded entity count in the world.
 */
public class EntityCountModule extends HudModule {
    public EntityCountModule() {
        super("entitycount", "Entity Count", 5, 560);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1687 == null) return null;
        int count = 0;
        try {
            for (class_1297 e : client.field_1687.method_18112()) {
                count++;
            }
        } catch (Exception ex) {
            return null;
        }
        return "\u00A7b" + count + " entities";
    }
}
