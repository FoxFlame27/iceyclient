package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_310;

public class NearestHostileModule extends HudModule {
    public NearestHostileModule() {
        super("nearesthostile", "Nearest Hostile", 0, 0);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        double min = Double.MAX_VALUE;
        class_1588 nearest = null;
        for (class_1297 e : client.field_1687.method_18112()) {
            if (!(e instanceof class_1588)) continue;
            double d = e.method_5739(client.field_1724);
            if (d < min) { min = d; nearest = (class_1588) e; }
        }
        if (nearest == null) return "\u00A7a\u2714 No hostiles";
        String color = min < 6 ? "\u00A7c" : min < 16 ? "\u00A7e" : "\u00A7a";
        return color + "\u2620 " + nearest.method_5477().getString() + " " + String.format("%.1fm", min);
    }
}
