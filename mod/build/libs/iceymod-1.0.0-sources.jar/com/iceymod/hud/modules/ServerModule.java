package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_642;

/**
 * Shows the current server IP / singleplayer status.
 */
public class ServerModule extends HudModule {
    public ServerModule() {
        super("server", "Server", 5, 90);
        setEnabled(false);
    }

    @Override
    public String getText(class_310 client) {
        if (client.method_1558() != null) {
            class_642 server = client.method_1558();
            return "\u00A7b" + server.field_3761;
        }
        if (client.method_1542()) {
            return "\u00A7aSingleplayer";
        }
        return null;
    }
}
