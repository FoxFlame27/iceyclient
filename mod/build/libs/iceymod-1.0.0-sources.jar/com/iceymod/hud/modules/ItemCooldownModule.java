package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class ItemCooldownModule extends HudModule {
    public ItemCooldownModule() {
        super("itemcd", "Item Cooldown", 0, 0);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public String getText(class_310 client) {
        if (client.field_1724 == null) return null;
        class_1799 s = client.field_1724.method_6047();
        if (s.method_7960()) return null;
        float cd = client.field_1724.method_7357().method_7905(s, 0f);
        if (cd <= 0) return null;
        int pct = Math.round(cd * 100f);
        return "\u00A7e\u231B " + pct + "% CD";
    }
}
