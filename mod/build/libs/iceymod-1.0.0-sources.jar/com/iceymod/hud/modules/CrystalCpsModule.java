package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public class CrystalCpsModule extends HudModule {
    private final List<Long> places = new ArrayList<>();
    private boolean wasRightPressed = false;

    public CrystalCpsModule() {
        super("crystalcps", "Crystal CPS", 5, 190);
        setEnabled(false);
    }

    @Override
    public Category getCategory() { return Category.COMBAT; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        long now = System.currentTimeMillis();
        class_1799 held = client.field_1724.method_6047();
        boolean rightDown = client.field_1690.field_1904.method_1434();
        if (rightDown && !wasRightPressed && held.method_31574(class_1802.field_8301)) {
            places.add(now);
        }
        wasRightPressed = rightDown;
        places.removeIf(t -> now - t > 1000);
    }

    @Override
    public String getText(class_310 client) {
        return "\u00A7d\u2726 " + places.size() + " cCPS";
    }
}
