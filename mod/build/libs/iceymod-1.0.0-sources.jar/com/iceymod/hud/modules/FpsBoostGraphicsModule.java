package com.iceymod.hud.modules;

import com.iceymod.hud.HudModule;
import net.minecraft.class_310;
import net.minecraft.class_5365;

/**
 * Invisible FPS booster: forces Fast graphics mode while enabled.
 */
public class FpsBoostGraphicsModule extends HudModule {
    public FpsBoostGraphicsModule() {
        super("fpsboost_graphics", "FPS: Fast Graphics", 0, 0);
    }

    @Override
    public Category getCategory() { return Category.OPTIMIZATION; }

    @Override
    protected boolean shouldShowStyleSettings() { return false; }

    @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 == null) return;
        if (client.field_1690.method_42534().method_41753() != class_5365.field_25427) {
            client.field_1690.method_42534().method_41748(class_5365.field_25427);
        }
    }

    @Override
    public String getText(class_310 client) { return null; }

    @Override
    public void render(net.minecraft.class_332 context, class_310 client) {}
}
