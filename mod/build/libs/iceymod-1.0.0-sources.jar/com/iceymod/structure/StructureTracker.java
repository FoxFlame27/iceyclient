package com.iceymod.structure;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.StructureLocatorModule;
import com.iceymod.hud.modules.WaypointManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1606;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2580;
import net.minecraft.class_2586;
import net.minecraft.class_2611;
import net.minecraft.class_2627;
import net.minecraft.class_2640;
import net.minecraft.class_2643;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3721;
import net.minecraft.class_638;
import net.minecraft.class_8961;
import net.minecraft.class_9199;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Detects structures in loaded chunks by scanning block entities — trial
 * spawners and vaults only exist inside trial chambers, end portals only
 * inside strongholds, so each hit is a reliable sighting. Results are
 * deduped by distance (80-block clustering) so one chamber maps to one
 * entry, not fifty.
 *
 * Hooked into {@link ClientChunkEvents#CHUNK_LOAD}, so every new chunk is
 * scanned exactly once. When the world changes, the found-list resets.
 */
public final class StructureTracker {

    public enum StructureType {
        TRIAL_CHAMBER   ("Trial Chamber",   0xFFFF8800),
        STRONGHOLD      ("Stronghold",      0xFFBB66FF),
        PLAYER_BASE     ("Player Base",     0xFF55FF55),
        NETHER_FORTRESS ("Nether Fortress", 0xFF8B1A1A),
        BASTION         ("Bastion Remnant", 0xFFC78A3E),
        END_CITY        ("End City",        0xFFE2CEF2),
        END_GATEWAY     ("End Gateway",     0xFF9966FF),
        OCEAN_MONUMENT  ("Ocean Monument",  0xFF50C7E8),
        ANCIENT_CITY    ("Ancient City",    0xFF33FFAA),
        RUINED_PORTAL   ("Ruined Portal",   0xFFAA00FF),
        DESERT_PYRAMID  ("Desert Pyramid",  0xFFE8D17A),
        VILLAGE         ("Village",         0xFFCCAA77);

        public final String label;
        public final int color;
        StructureType(String label, int color) { this.label = label; this.color = color; }
    }

    public static final class Found {
        public final StructureType type;
        public final class_2338 pos;
        public final String dimension;
        public Found(StructureType type, class_2338 pos, String dimension) {
            this.type = type;
            this.pos = pos;
            this.dimension = dimension;
        }
    }

    // Everything is per-dimension so a Nether trip doesn't wipe your
    // Overworld findings and vice versa.
    private static final List<Found> found = new ArrayList<>();
    private static final Map<String, Set<Long>> scannedChunksByDim = new HashMap<>();
    private static String currentWorldKey = "";

    // Structures closer than this (in blocks) are considered the same
    // structure (50 m as the default; End uses 40 m since cities/ships
    // are smaller and more numerous).
    private static final double CLUSTER_DISTANCE = 50.0;

    private StructureTracker() {}

    private static int tickCounter = 0;
    private static double lastPlayerX = Double.NaN, lastPlayerY = Double.NaN, lastPlayerZ = Double.NaN;

    public static void register() {
        // Primary detection path: react to chunks as they load.
        try {
            ClientChunkEvents.CHUNK_LOAD.register(StructureTracker::onChunkLoad);
        } catch (Throwable t) {
            System.out.println("[IceyMod] ClientChunkEvents.CHUNK_LOAD unavailable — structure locator will rely on periodic tick rescan: " + t.getMessage());
        }
        // Fallback path: periodic tick rescan. Chunks already scanned are
        // deduped via scannedChunksByDim, so this is a near-no-op for
        // already-seen chunks. The End scans 4× as often as overworld so
        // newly-loaded outer-end chunks register the moment they arrive.
        try {
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                tickCounter++;
                int threshold = currentWorldKey.contains("the_end") ? 5 : 20;
                if (tickCounter < threshold) return;
                tickCounter = 0;
                StructureLocatorModule mod = getModule();
                if (mod == null || !mod.isEnabled()) return;
                rescanNearby();
                detectEndTeleport(client);
                detectShulkers(client);
            });
        } catch (Throwable t) {
            System.out.println("[IceyMod] ClientTickEvents unavailable — periodic structure rescan disabled: " + t.getMessage());
        }
    }

    /**
     * Shulkers only spawn naturally inside End Cities. If we see one in
     * the loaded entity list, that's a 100% reliable End-City marker —
     * even on chunks where the block-sample scan didn't catch any
     * purpur. Cheap iteration: typical chunk has &lt;50 entities, and
     * we only do this once per second.
     */
    private static void detectShulkers(net.minecraft.class_310 client) {
        try {
            if (client == null || client.field_1687 == null) return;
            String dim = client.field_1687.method_27983().method_29177().toString();
            if (!dim.contains("the_end")) return;
            StructureLocatorModule mod = getModule();
            if (mod == null || !mod.endCities.get()) return;
            for (class_1297 e : client.field_1687.method_18112()) {
                if (e instanceof class_1606) {
                    addIfNew(StructureType.END_CITY, e.method_24515(), dim, mod.autoWaypoint.get());
                }
            }
        } catch (Throwable ignored) {}
    }

    /**
     * Drop an "End Anchor" waypoint when the player teleports a long way
     * inside the End — i.e. through an end gateway. Lets the user return
     * to outer-end islands they've visited without re-rolling RNG.
     */
    private static void detectEndTeleport(net.minecraft.class_310 client) {
        try {
            if (client == null || client.field_1724 == null || client.field_1687 == null) return;
            String dim = client.field_1687.method_27983().method_29177().toString();
            double x = client.field_1724.method_23317(), y = client.field_1724.method_23318(), z = client.field_1724.method_23321();
            if (dim.contains("the_end") && !Double.isNaN(lastPlayerX)) {
                double dx = x - lastPlayerX, dy = y - lastPlayerY, dz = z - lastPlayerZ;
                double distSq = dx * dx + dy * dy + dz * dz;
                if (distSq > 300 * 300) {
                    WaypointManager.addWaypoint("End Anchor", (int) x, (int) y, (int) z);
                    if (client.field_1724 != null) {
                        client.field_1724.method_7353(
                                net.minecraft.class_2561.method_43470("§b[IceyClient] §aEnd Anchor waypointed §8(" +
                                        (int) x + ", " + (int) y + ", " + (int) z + ")"),
                                false);
                    }
                }
            }
            lastPlayerX = x; lastPlayerY = y; lastPlayerZ = z;
        } catch (Throwable ignored) {}
    }

    public static List<Found> getFound() {
        synchronized (found) {
            return new ArrayList<>(found);
        }
    }

    /** Clears findings + scan state for the current dimension only. */
    public static void clear() {
        synchronized (found) {
            found.removeIf(f -> f.dimension.equals(currentWorldKey));
            Set<Long> dimSet = scannedChunksByDim.get(currentWorldKey);
            if (dimSet != null) dimSet.clear();
        }
    }

    /** Clears findings + scan state across every dimension. */
    public static void clearAll() {
        synchronized (found) {
            found.clear();
            scannedChunksByDim.clear();
        }
    }

    public static void remove(Found f) {
        if (f == null) return;
        synchronized (found) {
            found.remove(f);
        }
    }

    /**
     * Scan every chunk currently loaded around the player. Called when the
     * module is toggled on, so a player already standing in a trial chamber
     * doesn't have to walk out and back in to see the chamber show up.
     */
    public static void rescanNearby() {
        try {
            class_310 c = class_310.method_1551();
            if (c == null || c.field_1687 == null || c.field_1724 == null) return;
            resetIfWorldChanged();

            int cx = c.field_1724.method_31477() >> 4;
            int cz = c.field_1724.method_31479() >> 4;
            // Go beyond the client's view distance: servers sometimes
            // lazy-send extra chunks (simulation distance + neighbor
            // pre-load) that wouldn't be in our render set. Loop a bit
            // wider and let getWorldChunk null-skip the unloaded ones —
            // null check is O(1) so the extra iterations are free.
            int viewRadius = c.field_1690.method_42503().method_41753();
            int radius = viewRadius + 4;

            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2818 chunk = c.field_1687.method_2935().method_21730(cx + dx, cz + dz);
                    if (chunk == null) continue;
                    onChunkLoad(c.field_1687, chunk);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void resetIfWorldChanged() {
        class_310 c = class_310.method_1551();
        if (c == null || c.field_1687 == null) return;
        String key = c.field_1687.method_27983().method_29177().toString();
        if (!key.equals(currentWorldKey)) {
            currentWorldKey = key;
            // Don't clear — findings + scanned-chunks persist per dimension.
        }
    }

    private static StructureLocatorModule getModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof StructureLocatorModule sm) return sm;
        }
        return null;
    }

    private static void onChunkLoad(class_638 world, class_2818 chunk) {
        try {
            StructureLocatorModule mod = getModule();
            if (mod == null || !mod.isEnabled()) return;

            resetIfWorldChanged();
            String dim = world.method_27983().method_29177().toString();

            long key = chunk.method_12004().method_8324();
            synchronized (found) {
                Set<Long> dimSet = scannedChunksByDim.computeIfAbsent(dim, k -> new HashSet<>());
                if (!dimSet.add(key)) return;
            }

            boolean autoWp = mod.autoWaypoint.get();
            boolean isNether = dim.contains("nether");
            boolean isEnd    = dim.contains("the_end");
            boolean isOver   = !isNether && !isEnd;

            // --- Block-entity based detections (cheap — no block iteration) ---
            boolean trackTrial = mod.trialChambers.get();
            boolean trackStronghold = mod.strongholds.get();
            boolean trackBase = mod.playerBases.get();
            boolean trackVillage = mod.villages.get();
            boolean trackGateway = mod.endGateways.get();

            for (class_2586 be : chunk.method_12214().values()) {
                StructureType type = null;
                if (trackTrial && (be instanceof class_8961 || be instanceof class_9199)) {
                    type = StructureType.TRIAL_CHAMBER;
                } else if (trackStronghold && be instanceof class_2640) {
                    type = StructureType.STRONGHOLD;
                } else if (trackBase && (be instanceof class_2611
                        || be instanceof class_2627
                        || be instanceof class_2580)) {
                    type = StructureType.PLAYER_BASE;
                } else if (trackVillage && be instanceof class_3721) {
                    type = StructureType.VILLAGE;
                } else if (trackGateway && be instanceof class_2643) {
                    type = StructureType.END_GATEWAY;
                }
                if (type != null) addIfNew(type, be.method_11016(), dim, autoWp);
            }

            // --- Block-sample detections (unique signature blocks) ---
            // minHits gates how many sample matches we require before
            // calling it a structure — a single match is usually a
            // player-placed block, multiple in one chunk = real struct.
            if (isNether && mod.netherFortresses.get()) {
                class_2338 hit = scanChunkForBlock(chunk, s -> s.method_27852(class_2246.field_10364), 20, 100, 4, 3);
                if (hit != null) addIfNew(StructureType.NETHER_FORTRESS, hit, dim, autoWp);
            }
            if (isNether && mod.bastions.get()) {
                class_2338 hit = scanChunkForBlock(chunk,
                        s -> s.method_27852(class_2246.field_23261) || s.method_27852(class_2246.field_23880),
                        20, 120, 4, 2);
                if (hit != null) addIfNew(StructureType.BASTION, hit, dim, autoWp);
            }
            if (isEnd && mod.endCities.get()) {
                // Biome-gated max sensitivity:
                //   - END_HIGHLANDS / END_MIDLANDS = the only biomes
                //     where end cities can spawn. Scan EVERY block
                //     (step=1) over full Y (0-128), trigger on a single
                //     hit. Catches even one purpur block sticking out
                //     of an island fragment. About 8× the scan work of
                //     before but still well under 100us per chunk.
                //   - Anywhere else = skip entirely. Cities can't spawn
                //     so no need to waste cycles or risk false hits.
                int chunkCenterX = chunk.method_12004().method_8326() + 8;
                int chunkCenterZ = chunk.method_12004().method_8328() + 8;
                boolean rightBiome = false;
                try {
                    var biome = world.method_23753(new class_2338(chunkCenterX, 64, chunkCenterZ));
                    rightBiome = biome.method_40225(class_1972.field_9442)
                              || biome.method_40225(class_1972.field_9447);
                } catch (Throwable ignored) {}
                if (rightBiome) {
                    class_2338 hit = scanChunkForBlock(chunk,
                            s -> s.method_27852(class_2246.field_10505)
                              || s.method_27852(class_2246.field_10286)
                              || s.method_27852(class_2246.field_9992)
                              || s.method_27852(class_2246.field_10175)
                              || s.method_27852(class_2246.field_10462),
                            0, 128, 1, 1);
                    if (hit != null) addIfNew(StructureType.END_CITY, hit, dim, autoWp);
                }
            }
            if (isOver && mod.oceanMonuments.get()) {
                class_2338 hit = scanChunkForBlock(chunk, s -> s.method_27852(class_2246.field_10006), 39, 60, 4, 3);
                if (hit != null) addIfNew(StructureType.OCEAN_MONUMENT, hit, dim, autoWp);
            }
            if (isOver && mod.ancientCities.get()) {
                // reinforced_deepslate is genuinely unique — a single hit is enough
                class_2338 hit = scanChunkForBlock(chunk, s -> s.method_27852(class_2246.field_38420), -55, -25, 4, 1);
                if (hit != null) addIfNew(StructureType.ANCIENT_CITY, hit, dim, autoWp);
            }
            if (mod.ruinedPortals.get()) {
                int yMin = isNether ? 10 : 30;
                int yMax = isNether ? 100 : 120;
                class_2338 hit = scanChunkForBlock(chunk, s -> s.method_27852(class_2246.field_22423), yMin, yMax, 4, 2);
                if (hit != null) addIfNew(StructureType.RUINED_PORTAL, hit, dim, autoWp);
            }
            if (isOver && mod.desertPyramids.get()) {
                class_2338 hit = scanChunkForBlock(chunk, s -> s.method_27852(class_2246.field_10292), 60, 85, 4, 2);
                if (hit != null) addIfNew(StructureType.DESERT_PYRAMID, hit, dim, autoWp);
            }
        } catch (Throwable t) {
            // Never crash the chunk pipeline — just drop the scan for this chunk.
        }
    }

    private static void addIfNew(StructureType type, class_2338 pos, String dimension, boolean autoWaypoint) {
        // Tighter clustering in the End so a city + its end ship don't
        // collapse into a single entry — they're typically 50-80 blocks
        // apart, and we want both as separate waypoints.
        double clusterDist = dimension.contains("the_end") ? 40.0 : CLUSTER_DISTANCE;
        double clusterSq = clusterDist * clusterDist;

        boolean wasNew = false;
        synchronized (found) {
            for (Found f : found) {
                if (f.type != type) continue;
                if (!f.dimension.equals(dimension)) continue;
                double dx = f.pos.method_10263() - pos.method_10263();
                double dy = f.pos.method_10264() - pos.method_10264();
                double dz = f.pos.method_10260() - pos.method_10260();
                if (dx * dx + dy * dy + dz * dz < clusterSq) return;
            }
            found.add(new Found(type, pos, dimension));
            wasNew = true;
        }
        if (wasNew) {
            // Action-bar ping so the user actually NOTICES a new find,
            // even if their HUD widget is off-screen or the entry sorts
            // far down the list.
            try {
                net.minecraft.class_310 c = net.minecraft.class_310.method_1551();
                if (c != null && c.field_1724 != null) {
                    // Real chat message (overlay=false) so it's persistent
                    // in the chat log, not just a fading action-bar line.
                    c.field_1724.method_7353(net.minecraft.class_2561.method_43470(
                            "§b[IceyClient] §a" + type.label + " found! §8(" +
                                    pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + ")"), false);
                }
            } catch (Throwable ignored) {}
            if (autoWaypoint) {
                try {
                    // Dedup at 100 m — a Trial Chamber detected from
                    // multiple BEs in the same area should produce one
                    // waypoint, not many.
                    WaypointManager.addWaypointIfNew(type.label,
                            pos.method_10263(), pos.method_10264(), pos.method_10260(), type.color, 100.0);
                } catch (Throwable ignored) {}
            }
        }
    }

    /**
     * Sorted-by-distance view for the HUD, filtered to the current
     * dimension so Nether entries don't pollute an Overworld list.
     */
    public static List<Found> getSortedByDistance() {
        class_310 c = class_310.method_1551();
        if (c == null || c.field_1724 == null || c.field_1687 == null) return Collections.emptyList();
        String dim = c.field_1687.method_27983().method_29177().toString();
        double px = c.field_1724.method_23317(), py = c.field_1724.method_23318(), pz = c.field_1724.method_23321();
        List<Found> all = getFound();
        List<Found> copy = new ArrayList<>(all.size());
        for (Found f : all) {
            if (f.dimension.equals(dim)) copy.add(f);
        }
        copy.sort((a, b) -> {
            double da = distSq(a.pos, px, py, pz);
            double db = distSq(b.pos, px, py, pz);
            return Double.compare(da, db);
        });
        return copy;
    }

    private static double distSq(class_2338 p, double x, double y, double z) {
        double dx = p.method_10263() - x, dy = p.method_10264() - y, dz = p.method_10260() - z;
        return dx * dx + dy * dy + dz * dz;
    }

    /**
     * Coarse-grid sample of a chunk for a specific signature block. Returns
     * the first matching BlockPos, or null. Equivalent to
     * scanChunkForBlock(chunk, match, yMin, yMax, step, 1).
     */
    private static class_2338 scanChunkForBlock(class_2818 chunk,
                                              java.util.function.Predicate<class_2680> match,
                                              int yMin, int yMax, int step) {
        return scanChunkForBlock(chunk, match, yMin, yMax, step, 1);
    }

    /**
     * Returns first matching BlockPos only if at least {@code minHits}
     * sample positions in the chunk match the predicate. Used for
     * structures whose signature block can also be player-placed
     * (purpur, crying_obsidian, etc.) — a single hit is probably a
     * player build, but several hits in one chunk reliably mean a
     * naturally-generated structure.
     */
    private static class_2338 scanChunkForBlock(class_2818 chunk,
                                              java.util.function.Predicate<class_2680> match,
                                              int yMin, int yMax, int step,
                                              int minHits) {
        try {
            int baseX = chunk.method_12004().method_8326();
            int baseZ = chunk.method_12004().method_8328();
            class_2338.class_2339 pos = new class_2338.class_2339();
            int hits = 0;
            class_2338 firstHit = null;
            for (int y = yMin; y <= yMax; y += step) {
                for (int dx = 0; dx < 16; dx += step) {
                    for (int dz = 0; dz < 16; dz += step) {
                        pos.method_10103(baseX + dx, y, baseZ + dz);
                        class_2680 state = chunk.method_8320(pos);
                        if (match.test(state)) {
                            hits++;
                            if (firstHit == null) firstHit = new class_2338(baseX + dx, y, baseZ + dz);
                            if (hits >= minHits) return firstHit;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }
}
