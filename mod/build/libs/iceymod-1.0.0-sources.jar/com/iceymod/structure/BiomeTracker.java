package com.iceymod.structure;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.BiomeLocatorModule;
import com.iceymod.hud.modules.WaypointManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Same shape as {@link StructureTracker} but for biomes. Each chunk
 * load samples the biome at chunk center; if it matches one of the
 * user-enabled biome types, it's recorded as a Found entry. Big
 * 256-block clustering since biomes cover huge contiguous regions —
 * one entry per blob, not per chunk.
 */
public final class BiomeTracker {

    public enum BiomeType {
        CHERRY_GROVE     ("Cherry Grove",      0xFFFF9DC4, class_1972.field_42720),
        MUSHROOM_FIELDS  ("Mushroom Fields",   0xFFC07DCC, class_1972.field_9462),
        ICE_SPIKES       ("Ice Spikes",        0xFFB4DCFF, class_1972.field_9453),
        SUNFLOWER_PLAINS ("Sunflower Plains",  0xFFFFE45A, class_1972.field_9455),
        BAMBOO_JUNGLE    ("Bamboo Jungle",     0xFF77BC3D, class_1972.field_9440),
        ERODED_BADLANDS  ("Eroded Badlands",   0xFFBF6A29, class_1972.field_9443),
        DEEP_DARK        ("Deep Dark",         0xFF22BBAA, class_1972.field_37543),
        PALE_GARDEN      ("Pale Garden",       0xFFD2D2C5, class_1972.field_55052),
        DEEP_FROZEN_OCEAN("Deep Frozen Ocean", 0xFF7BBDF5, class_1972.field_9418),
        BADLANDS         ("Badlands",          0xFFD9905C, class_1972.field_9415),
        JUNGLE           ("Jungle",            0xFF49B349, class_1972.field_9417),
        SAVANNA          ("Savanna",           0xFFBDB25F, class_1972.field_9449);

        public final String label;
        public final int color;
        public final class_5321<class_1959> key;
        BiomeType(String label, int color, class_5321<class_1959> key) {
            this.label = label; this.color = color; this.key = key;
        }
    }

    public static final class Found {
        public final BiomeType type;
        public final class_2338 pos;
        public final String dimension;
        public Found(BiomeType type, class_2338 pos, String dimension) {
            this.type = type; this.pos = pos; this.dimension = dimension;
        }
    }

    private static final List<Found> found = new ArrayList<>();
    private static final Map<String, Set<Long>> scannedChunksByDim = new HashMap<>();
    private static String currentWorldKey = "";

    // Biomes are big — one cherry-grove blob can span dozens of chunks.
    // Cluster aggressively so each blob gets one entry, not 50.
    private static final double CLUSTER_DISTANCE = 256.0;
    private static int tickCounter = 0;

    private BiomeTracker() {}

    public static void register() {
        try {
            ClientChunkEvents.CHUNK_LOAD.register(BiomeTracker::onChunkLoad);
        } catch (Throwable t) {
            System.out.println("[IceyMod] BiomeTracker chunk-load unavailable: " + t.getMessage());
        }
        try {
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                tickCounter++;
                if (tickCounter < 20) return;
                tickCounter = 0;
                BiomeLocatorModule mod = getModule();
                if (mod == null || !mod.isEnabled()) return;
                rescanNearby();
            });
        } catch (Throwable t) {
            System.out.println("[IceyMod] BiomeTracker tick unavailable: " + t.getMessage());
        }
    }

    public static List<Found> getFound() {
        synchronized (found) { return new ArrayList<>(found); }
    }

    public static void clear() {
        synchronized (found) {
            found.removeIf(f -> f.dimension.equals(currentWorldKey));
            Set<Long> dimSet = scannedChunksByDim.get(currentWorldKey);
            if (dimSet != null) dimSet.clear();
        }
    }

    public static void remove(Found f) {
        if (f == null) return;
        synchronized (found) { found.remove(f); }
    }

    public static void rescanNearby() {
        try {
            class_310 c = class_310.method_1551();
            if (c == null || c.field_1687 == null || c.field_1724 == null) return;
            resetIfWorldChanged();
            int cx = c.field_1724.method_31477() >> 4;
            int cz = c.field_1724.method_31479() >> 4;
            int radius = c.field_1690.method_42503().method_41753() + 4;
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2818 chunk = c.field_1687.method_2935().method_21730(cx + dx, cz + dz);
                    if (chunk == null) continue;
                    onChunkLoad(c.field_1687, chunk);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static BiomeLocatorModule getModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof BiomeLocatorModule bm) return bm;
        }
        return null;
    }

    private static void resetIfWorldChanged() {
        class_310 c = class_310.method_1551();
        if (c == null || c.field_1687 == null) return;
        String key = c.field_1687.method_27983().method_29177().toString();
        if (!key.equals(currentWorldKey)) {
            currentWorldKey = key;
            // keep findings across dim switches, same as StructureTracker
        }
    }

    private static void onChunkLoad(class_638 world, class_2818 chunk) {
        try {
            BiomeLocatorModule mod = getModule();
            if (mod == null || !mod.isEnabled()) return;
            resetIfWorldChanged();
            String dim = world.method_27983().method_29177().toString();
            long key = chunk.method_12004().method_8324();
            synchronized (found) {
                Set<Long> dimSet = scannedChunksByDim.computeIfAbsent(dim, k -> new HashSet<>());
                if (!dimSet.add(key)) return;
            }

            int bx = chunk.method_12004().method_8326() + 8;
            int bz = chunk.method_12004().method_8328() + 8;
            class_2338 sample = new class_2338(bx, 64, bz);
            var biomeEntry = world.method_23753(sample);

            for (BiomeType type : BiomeType.values()) {
                if (!mod.isTypeEnabled(type)) continue;
                if (biomeEntry.method_40225(type.key)) {
                    addIfNew(type, sample, dim, mod.autoWaypoint.get());
                    break;
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void addIfNew(BiomeType type, class_2338 pos, String dimension, boolean autoWaypoint) {
        boolean wasNew = false;
        synchronized (found) {
            for (Found f : found) {
                if (f.type != type) continue;
                if (!f.dimension.equals(dimension)) continue;
                double dx = f.pos.method_10263() - pos.method_10263();
                double dz = f.pos.method_10260() - pos.method_10260();
                if (dx * dx + dz * dz < CLUSTER_DISTANCE * CLUSTER_DISTANCE) return;
            }
            found.add(new Found(type, pos, dimension));
            wasNew = true;
        }
        if (wasNew) {
            try {
                class_310 c = class_310.method_1551();
                if (c != null && c.field_1724 != null) {
                    c.field_1724.method_7353(net.minecraft.class_2561.method_43470(
                            "§b[IceyClient] §a" + type.label + " biome found! §8(" +
                                    pos.method_10263() + ", ~, " + pos.method_10260() + ")"), false);
                }
            } catch (Throwable ignored) {}
            if (autoWaypoint) {
                try {
                    // Same dedup logic as structures, larger radius
                    // since biomes can stretch hundreds of blocks.
                    WaypointManager.addWaypointIfNew(type.label,
                            pos.method_10263(), 64, pos.method_10260(), type.color, 256.0);
                } catch (Throwable ignored) {}
            }
        }
    }

    public static List<Found> getSortedByDistance() {
        class_310 c = class_310.method_1551();
        if (c == null || c.field_1724 == null || c.field_1687 == null) return Collections.emptyList();
        String dim = c.field_1687.method_27983().method_29177().toString();
        double px = c.field_1724.method_23317(), pz = c.field_1724.method_23321();
        List<Found> all = getFound();
        List<Found> copy = new ArrayList<>(all.size());
        for (Found f : all) if (f.dimension.equals(dim)) copy.add(f);
        copy.sort((a, b) -> {
            double da = (a.pos.method_10263() - px) * (a.pos.method_10263() - px) + (a.pos.method_10260() - pz) * (a.pos.method_10260() - pz);
            double db = (b.pos.method_10263() - px) * (b.pos.method_10263() - px) + (b.pos.method_10260() - pz) * (b.pos.method_10260() - pz);
            return Double.compare(da, db);
        });
        return copy;
    }
}
