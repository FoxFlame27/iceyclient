package com.iceymod.render;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.MinimapModule;
import com.iceymod.hud.modules.WaypointManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1163;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3620;
import net.minecraft.class_638;
import org.joml.Matrix3x2fStack;

/**
 * Xaero-style minimap renderer. Keeps a NativeImage backing texture,
 * rescans a radius of blocks around the player on a throttle, and draws
 * it as a HUD widget with biome-tinted colors, height shading, player
 * arrow, and waypoint dots.
 *
 * Sampling strategy: for each pixel in the texture, reverse-project to a
 * world (x,z) column, look up the WORLD_SURFACE top block, then pick a
 * color using biome-aware tinting for grass/leaves/water (so forests
 * look forest-green, swamps look muddy, oceans match the biome shade).
 */
public class MinimapRenderer {
    private static final int TEX_SIZE = 128;
    private static final class_2960 TEXTURE_ID = class_2960.method_60655("iceymod", "minimap");

    private static class_1011 image;
    private static class_1043 texture;
    private static boolean initAttempted = false;

    private static long lastUpdateTick = Long.MIN_VALUE;
    private static int lastCenterX = Integer.MIN_VALUE;
    private static int lastCenterZ = Integer.MIN_VALUE;
    private static int lastRadius = -1;
    private static String lastWorldKey = "";

    public static void register() {
        try {
            HudRenderCallback.EVENT.register(MinimapRenderer::onHudRender);
        } catch (Throwable t) {
            System.out.println("[IceyMod] HudRenderCallback unavailable — minimap disabled: " + t.getMessage());
        }
    }

    private static MinimapModule getModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof MinimapModule mm) return mm;
        }
        return null;
    }

    private static void ensureTexture() {
        if (initAttempted) return;
        initAttempted = true;
        try {
            image = new class_1011(TEX_SIZE, TEX_SIZE, false);
            for (int i = 0; i < TEX_SIZE; i++) {
                for (int j = 0; j < TEX_SIZE; j++) {
                    image.method_61941(i, j, 0xFF101018);
                }
            }
            texture = new class_1043(() -> "iceymod-minimap", image);
            class_310.method_1551().method_1531().method_4616(TEXTURE_ID, texture);
        } catch (Throwable t) {
            System.out.println("[IceyMod] Minimap texture init failed: " + t.getMessage());
            image = null;
            texture = null;
        }
    }

    private static void onHudRender(class_332 ctx, net.minecraft.class_9779 tickCounter) {
        MinimapModule mod = getModule();
        if (mod == null || !mod.isEnabled()) return;
        if (!HudManager.isHudVisible()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (client.field_1755 != null && !(client.field_1755 instanceof net.minecraft.class_408)) return;

        try {
            ensureTexture();
            if (image == null || texture == null) return;
            updatePixels(client, mod);
            drawWidget(ctx, client, mod);
        } catch (Throwable ignored) {
            // Never crash the HUD
        }
    }

    private static void updatePixels(class_310 client, MinimapModule mod) {
        class_638 world = client.field_1687;
        int px = (int) Math.floor(client.field_1724.method_23317());
        int pz = (int) Math.floor(client.field_1724.method_23321());
        int radius = mod.radius.get();
        long now = world.method_8510();
        String worldKey = world.method_27983().method_29177().toString();

        boolean worldChanged = !worldKey.equals(lastWorldKey);
        boolean radiusChanged = radius != lastRadius;
        boolean moved = Math.abs(px - lastCenterX) >= 1 || Math.abs(pz - lastCenterZ) >= 1;
        boolean timedOut = now - lastUpdateTick >= 20;

        if (!worldChanged && !radiusChanged && !moved && !timedOut) return;

        lastCenterX = px;
        lastCenterZ = pz;
        lastRadius = radius;
        lastWorldKey = worldKey;
        lastUpdateTick = now;

        boolean biomeTint = mod.biomeTint.get();
        boolean heightShade = mod.heightShade.get();

        class_2338.class_2339 pos = new class_2338.class_2339();
        class_2338.class_2339 neighbor = new class_2338.class_2339();

        // blocksPerPixel < 1 means each pixel covers less than a block (zoom in)
        float blocksPerPixel = (radius * 2f) / TEX_SIZE;

        for (int pyPix = 0; pyPix < TEX_SIZE; pyPix++) {
            for (int pxPix = 0; pxPix < TEX_SIZE; pxPix++) {
                int bx = px + (int) Math.floor((pxPix - TEX_SIZE / 2f) * blocksPerPixel);
                int bz = pz + (int) Math.floor((pyPix - TEX_SIZE / 2f) * blocksPerPixel);
                int color = sampleColumn(world, bx, bz, pos, neighbor, biomeTint, heightShade);
                image.method_61941(pxPix, pyPix, color);
            }
        }
        try {
            texture.method_4524();
        } catch (Throwable ignored) {}
    }

    private static int sampleColumn(class_638 world, int x, int z,
                                    class_2338.class_2339 pos, class_2338.class_2339 neighbor,
                                    boolean biomeTint, boolean heightShade) {
        try {
            int topY;
            try {
                topY = world.method_8624(class_2902.class_2903.field_13202, x, z);
            } catch (Throwable t) {
                return 0xFF101018;
            }
            if (topY <= world.method_31607() + 1) return 0xFF101018;

            pos.method_10103(x, topY - 1, z);
            class_2680 state = world.method_8320(pos);
            if (state.method_26215()) {
                pos.method_10103(x, topY - 2, z);
                state = world.method_8320(pos);
            }

            int rgb;
            if (biomeTint && (state.method_27852(class_2246.field_10219)
                    || state.method_27852(class_2246.field_10479)
                    || state.method_27852(class_2246.field_10214)
                    || state.method_27852(class_2246.field_10112)
                    || state.method_27852(class_2246.field_10313)
                    || state.method_27852(class_2246.field_10424))) {
                rgb = class_1163.method_4962(world, pos) | 0xFF000000;
            } else if (biomeTint && state.method_26164(class_3481.field_15503)) {
                rgb = class_1163.method_4966(world, pos) | 0xFF000000;
            } else if (biomeTint && state.method_27852(class_2246.field_10382)) {
                rgb = class_1163.method_4961(world, pos) | 0xFF000000;
            } else {
                class_3610 fluid = state.method_26227();
                if (biomeTint && !fluid.method_15769() && fluid.method_15767(class_3486.field_15517)) {
                    rgb = class_1163.method_4961(world, pos) | 0xFF000000;
                } else {
                    class_3620 mc = state.method_26205(world, pos);
                    int mcRgb = mc.field_16011;
                    if (mcRgb == 0) mcRgb = 0x3F76E4; // sane default for air-ish columns
                    rgb = mcRgb | 0xFF000000;
                }
            }

            if (heightShade) {
                int westY;
                int northY;
                try {
                    westY = world.method_8624(class_2902.class_2903.field_13202, x - 1, z);
                    northY = world.method_8624(class_2902.class_2903.field_13202, x, z - 1);
                } catch (Throwable t) {
                    return rgb;
                }
                int shade = 0;
                if (topY > westY) shade += 14;
                else if (topY < westY) shade -= 14;
                if (topY > northY) shade += 8;
                else if (topY < northY) shade -= 8;
                rgb = applyShade(rgb, shade);
            }

            return rgb;
        } catch (Throwable t) {
            return 0xFF101018;
        }
    }

    private static int applyShade(int argb, int shade) {
        int a = (argb >>> 24) & 0xFF;
        int r = clamp(((argb >>> 16) & 0xFF) + shade);
        int g = clamp(((argb >>> 8) & 0xFF) + shade);
        int b = clamp((argb & 0xFF) + shade);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    private static void drawWidget(class_332 ctx, class_310 client, MinimapModule mod) {
        int size = mod.size.get();
        int x = mod.getX();
        int y = mod.getY();

        // Clamp into screen so freshly-added modules aren't off-screen
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        if (x + size > sw) x = sw - size - 4;
        if (y + size > sh) y = sh - size - 4;
        if (x < 0) x = 4;
        if (y < 0) y = 4;

        // Outer frame
        ctx.method_25294(x - 2, y - 2, x + size + 2, y + size + 2, 0xFF000000);
        ctx.method_25294(x - 1, y - 1, x + size + 1, y + size + 1, 0xFF5BC8F5);
        ctx.method_25294(x, y, x + size, y + size, 0xFF0A0A12);

        // The texture
        try {
            ctx.method_25290(
                    class_10799.field_56883,
                    TEXTURE_ID,
                    x, y,
                    0f, 0f,
                    size, size,
                    TEX_SIZE, TEX_SIZE
            );
        } catch (Throwable ignored) {}

        int cx = x + size / 2;
        int cy = y + size / 2;
        float pixelsPerBlock = (float) size / (mod.radius.get() * 2f);

        // Waypoint dots
        if (mod.waypoints.get()) {
            for (WaypointManager.Waypoint wp : WaypointManager.getWaypoints()) {
                float dx = ((float) wp.x - (float) client.field_1724.method_23317()) * pixelsPerBlock;
                float dz = ((float) wp.z - (float) client.field_1724.method_23321()) * pixelsPerBlock;
                int wpx = Math.round(cx + dx);
                int wpz = Math.round(cy + dz);

                if (wpx >= x + 1 && wpx <= x + size - 2 && wpz >= y + 1 && wpz <= y + size - 2) {
                    ctx.method_25294(wpx - 2, wpz - 2, wpx + 3, wpz + 3, 0xFF000000);
                    ctx.method_25294(wpx - 1, wpz - 1, wpx + 2, wpz + 2, wp.color);
                } else {
                    // Edge-clamp indicator: project to nearest border
                    float clampedX = Math.max(x + 3, Math.min(x + size - 4, wpx));
                    float clampedY = Math.max(y + 3, Math.min(y + size - 4, wpz));
                    int bx = Math.round(clampedX);
                    int bz = Math.round(clampedY);
                    ctx.method_25294(bx - 1, bz - 1, bx + 2, bz + 2, wp.color);
                }
            }
        }

        // Player arrow (center, rotated with yaw)
        drawPlayerArrow(ctx, cx, cy, client.field_1724.method_36454());

        // North "N" tag
        if (mod.northTag.get()) {
            ctx.method_25294(cx - 4, y + 1, cx + 5, y + 10, 0xB0000000);
            ctx.method_25300(client.field_1772, "§fN", cx + 1, y + 2, 0xFFFFFFFF);
        }

        // Coords underneath
        if (mod.coords.get()) {
            int ix = (int) Math.floor(client.field_1724.method_23317());
            int iy = (int) Math.floor(client.field_1724.method_23318());
            int iz = (int) Math.floor(client.field_1724.method_23321());
            String txt = "§f" + ix + " §7/ §f" + iy + " §7/ §f" + iz;
            int tw = client.field_1772.method_1727(txt);
            int textY = y + size + 2;
            ctx.method_25294(cx - tw / 2 - 2, textY - 1, cx + tw / 2 + 2, textY + 9, 0xB0000000);
            ctx.method_25300(client.field_1772, txt, cx, textY, 0xFFFFFFFF);
        }
    }

    private static void drawPlayerArrow(class_332 ctx, int cx, int cy, float yaw) {
        // Map yaw onto the 2D minimap: +X east, +Z south (=> +Y screen).
        // Player facing vector: fx = -sin(yaw), fz = cos(yaw).
        Matrix3x2fStack ms = ctx.method_51448();
        ms.pushMatrix();
        ms.translate((float) cx, (float) cy);
        ms.rotate((float) Math.toRadians(yaw + 180.0));
        // A triangle pointing "up" in local space. After the rotation
        // above, local -Y is forward in player space.
        ctx.method_25294(-1, -4, 1, 1, 0xFFFFFFFF);           // shaft
        ctx.method_25294(-2, -3, 2, -2, 0xFFFFFFFF);          // tip row
        ctx.method_25294(-3, -2, 3, -1, 0xFFFFFFFF);          // wing row
        ctx.method_25294(-1, 1, 1, 3, 0xFFFF3A3A);            // red tail so you can tell front from back
        // Outline
        ctx.method_25294(-1, -5, 1, -4, 0xFF000000);
        ctx.method_25294(-4, -2, -3, -1, 0xFF000000);
        ctx.method_25294(3, -2, 4, -1, 0xFF000000);
        ms.popMatrix();
    }
}
