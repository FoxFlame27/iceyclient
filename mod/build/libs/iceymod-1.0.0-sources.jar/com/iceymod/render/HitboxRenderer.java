package com.iceymod.render;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.HitboxModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9974;

/**
 * Wireframe bounding boxes around every loaded entity, colored by the
 * HitboxModule's color setting. Registered at AFTER_ENTITIES so entities
 * are already in the frame and the lines sit cleanly on top.
 */
public class HitboxRenderer {

    public static void register() {
        // Same VulkanMod-stub guard as WaypointBeamRenderer.
        try {
            WorldRenderEvents.AFTER_ENTITIES.register(HitboxRenderer::onRender);
        } catch (Throwable t) {
            System.out.println("[IceyMod] WorldRenderEvents unavailable — hitbox renderer disabled: " + t.getMessage());
        }
    }

    private static HitboxModule findModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof HitboxModule hm) return hm;
        }
        return null;
    }

    private static void onRender(WorldRenderContext ctx) {
        HitboxModule mod = findModule();
        if (mod == null || !mod.isEnabled()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        int argb = mod.color.get();
        float a = ((argb >>> 24) & 0xFF) / 255f;
        float r = ((argb >>> 16) & 0xFF) / 255f;
        float g = ((argb >>> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        if (a <= 0f) a = 1f;

        int rangeBlocks = mod.range.get();
        int rangeSq = rangeBlocks * rangeBlocks;
        boolean includeSelf = mod.showSelf.get();
        boolean onlyLiving = mod.onlyLiving.get();

        class_4184 cam = ctx.camera();
        class_243 camPos = cam.method_19326();
        class_4587 ms = ctx.matrixStack();
        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        class_4588 lines;
        try {
            lines = consumers.getBuffer(class_1921.method_23594());
        } catch (Throwable t) {
            return;
        }

        ms.method_22903();
        ms.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
        try {
            for (class_1297 e : client.field_1687.method_18112()) {
                if (e == client.field_1724 && !includeSelf) continue;
                if (onlyLiving && !(e instanceof class_1309)) continue;
                if (e.method_5858(client.field_1724) > rangeSq) continue;
                class_238 box = e.method_5829();
                class_9974.method_62295(ms, lines, box, r, g, b, a);
            }
        } catch (Throwable ignored) {
            // If the entity iterator or drawBox signature changes in a future
            // version, fail silently rather than crash the frame.
        }
        ms.method_22909();
    }
}
