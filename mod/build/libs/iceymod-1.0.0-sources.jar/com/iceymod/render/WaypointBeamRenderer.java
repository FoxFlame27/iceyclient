package com.iceymod.render;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.modules.WaypointsModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_822;
import java.util.List;

/**
 * Renders each waypoint as a beacon-style vertical beam and a billboarded
 * "name • 42m" tag that floats above it so you can spot both the location
 * and the distance from anywhere.
 */
public class WaypointBeamRenderer {

    public static void register() {
        try {
            WorldRenderEvents.AFTER_TRANSLUCENT.register(WaypointBeamRenderer::onRender);
        } catch (Throwable t) {
            System.out.println("[IceyMod] WorldRenderEvents unavailable (VulkanMod / stub?) — waypoint beams disabled: " + t.getMessage());
        }
    }

    private static boolean beamsEnabled() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof WaypointsModule) return m.isEnabled();
        }
        return false;
    }

    private static void onRender(WorldRenderContext ctx) {
        if (!beamsEnabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        List<WaypointManager.Waypoint> wps = WaypointManager.getWaypoints();
        if (wps.isEmpty()) return;

        class_4184 cam = ctx.camera();
        class_243 camPos = cam.method_19326();
        class_4587 ms = ctx.matrixStack();
        long worldTime = client.field_1687.method_8510();
        float tickDelta = ctx.tickCounter().method_60637(false);

        class_243 playerPos = client.field_1724.method_19538();
        class_4597 vcp = ctx.consumers();
        class_327 textRenderer = client.field_1772;

        for (WaypointManager.Waypoint wp : wps) {
            // --- Beacon beam ---
            ms.method_22903();
            ms.method_22904(wp.x + 0.5 - camPos.field_1352, -64 - camPos.field_1351, wp.z + 0.5 - camPos.field_1350);
            try {
                class_822.method_3545(
                        ms,
                        vcp,
                        class_822.field_4338,
                        tickDelta,
                        1.0f,
                        worldTime,
                        0,
                        class_822.field_32822,
                        wp.color,
                        0.2f,
                        0.25f
                );
            } catch (Throwable ignored) {
                // Renderer API changed? Don't crash the frame.
            }
            ms.method_22909();

            // --- Floating name + distance tag ---
            try {
                double dx = (wp.x + 0.5) - playerPos.field_1352;
                double dy = wp.y - playerPos.field_1351;
                double dz = (wp.z + 0.5) - playerPos.field_1350;
                int distance = (int) Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz));
                String label = wp.name + " §7• §f" + distance + "m";

                // Anchor the tag high in the air above the beam so terrain / blocks
                // can't eat it. Matches the beam's x/z and a Y well above most builds.
                double tagX = wp.x + 0.5;
                double tagY = Math.max(playerPos.field_1351 + 20.0, wp.y + 3.0);
                double tagZ = wp.z + 0.5;

                ms.method_22903();
                ms.method_22904(tagX - camPos.field_1352, tagY - camPos.field_1351, tagZ - camPos.field_1350);
                // Billboard: rotate to face the camera
                ms.method_22907(cam.method_23767());
                // Text is huge by default; shrink and flip Y so it reads right-side up
                float scale = 0.03f;
                ms.method_22905(-scale, -scale, scale);

                org.joml.Matrix4f mtx = ms.method_23760().method_23761();
                int w = textRenderer.method_1727(label);
                int bgColor = 0x66000000;     // translucent black
                int textColor = 0xFFFFFFFF;   // white (the name keeps its own color via §)

                // Prefix the waypoint's own color onto the name so it matches the beam
                String colored = toChatColor(wp.color) + wp.name + " §7• §f" + distance + "m";
                int cw = textRenderer.method_1727(colored);

                textRenderer.method_27522(
                        class_2561.method_43470(colored),
                        -cw / 2f,
                        0f,
                        textColor,
                        false,
                        mtx,
                        vcp,
                        class_327.class_6415.field_33994,
                        bgColor,
                        0x00F000F0 // full-bright light value
                );
                ms.method_22909();
            } catch (Throwable ignored) {
                // Any text-render API wobble shouldn't crash the frame.
            }
        }
    }

    /**
     * Map an ARGB color roughly to the nearest MC chat-color code so the
     * waypoint name in the floating tag matches the beam color visually.
     */
    private static String toChatColor(int argb) {
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;
        if (r < 40 && g < 40 && b < 40) return "§0";            // black
        if (r > 220 && g > 220 && b > 220) return "§f";          // white
        if (Math.abs(r - g) < 30 && Math.abs(g - b) < 30) return "§7"; // gray
        if (r > 200 && g > 160 && b < 120) return "§6";          // orange
        if (r > 200 && g > 200 && b < 140) return "§e";          // yellow
        if (r > 200 && g < 150 && b < 150) return "§c";          // red
        if (r < 150 && g > 180 && b < 150) return "§a";          // green
        if (r < 150 && g > 150 && b > 200) return "§b";          // aqua
        if (r > 150 && g < 180 && b > 180) return "§d";          // pink
        return "§f";
    }
}
