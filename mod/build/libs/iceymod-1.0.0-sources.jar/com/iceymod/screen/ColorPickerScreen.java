package com.iceymod.screen;

import com.iceymod.hud.settings.ColorSetting;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * RGB color picker. Sliders for R/G/B, a hex text field, a big preview
 * swatch, plus a quick palette row with the ColorSetting.PALETTE colors.
 * Apply writes the ARGB value back to the setting.
 */
public class ColorPickerScreen extends class_437 {

    private final ColorSetting setting;
    private final class_437 parent;
    private final int originalValue;
    /** Callback for the standalone-color path (waypoints). null when bound to a setting. */
    private final java.util.function.IntConsumer onApply;
    private final String displayLabel;

    private int r, g, b;
    private int alpha = 0xFF;

    private RgbSlider rSlider, gSlider, bSlider;
    private class_342 hexField;

    public ColorPickerScreen(ColorSetting setting, class_437 parent) {
        super(class_2561.method_43470("Color"));
        this.setting = setting;
        this.parent = parent;
        this.onApply = null;
        this.displayLabel = setting.label;
        this.originalValue = setting.get();
        unpack(originalValue);
    }

    /**
     * Standalone color picker not tied to a ColorSetting — used when
     * picking a waypoint color, where the value lives in WaypointManager
     * instead of a Setting.
     */
    public ColorPickerScreen(int initialColor, String label,
                             java.util.function.IntConsumer onApply, class_437 parent) {
        super(class_2561.method_43470(label));
        this.setting = null;
        this.parent = parent;
        this.onApply = onApply;
        this.displayLabel = label;
        this.originalValue = initialColor;
        unpack(initialColor);
    }

    private void unpack(int argb) {
        alpha = (argb >>> 24) & 0xFF;
        if (alpha == 0) alpha = 0xFF; // never let fully transparent slip through
        r = (argb >>> 16) & 0xFF;
        g = (argb >>> 8) & 0xFF;
        b = argb & 0xFF;
    }

    private int pack() { return (alpha << 24) | (r << 16) | (g << 8) | b; }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int col = Math.min(320, this.field_22789 - 80);
        int x = cx - col / 2;
        int y = 80;
        int sh = 20;
        int gap = 8;

        rSlider = new RgbSlider(x, y, col, sh, "R", r, v -> { r = v; syncHex(); });
        method_37063(rSlider);
        y += sh + gap;

        gSlider = new RgbSlider(x, y, col, sh, "G", g, v -> { g = v; syncHex(); });
        method_37063(gSlider);
        y += sh + gap;

        bSlider = new RgbSlider(x, y, col, sh, "B", b, v -> { b = v; syncHex(); });
        method_37063(bSlider);
        y += sh + gap * 2;

        // Hex input
        hexField = new class_342(this.field_22793, x, y, col, sh, class_2561.method_43470("Hex"));
        hexField.method_1880(8);
        hexField.method_1852(String.format("%02X%02X%02X", r, g, b));
        hexField.method_1863(this::onHexChanged);
        method_37063(hexField);
        y += sh + gap * 2;

        // Palette quick-pick row — vanilla ButtonWidgets so it fits the rest
        int palCount = ColorSetting.PALETTE.length;
        int palBtnW = Math.max(24, col / palCount - 2);
        for (int i = 0; i < palCount; i++) {
            final int packedPalette = ColorSetting.PALETTE[i];
            class_4185 pb = class_4185.method_46430(
                class_2561.method_43470("■"), // filled square glyph, colored via label
                btn -> { unpack(packedPalette); syncSliders(); syncHex(); }
            ).method_46434(x + i * (palBtnW + 2), y, palBtnW, sh).method_46431();
            method_37063(pb);
        }
        y += sh + gap * 2;

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Save"),
            btn -> {
                int packed = pack();
                if (setting != null) setting.set(packed);
                if (onApply != null) onApply.accept(packed);
                field_22787.method_1507(parent);
            }
        ).method_46434(x, y, col, sh).method_46431());
        y += sh + gap;

        class_4185 resetBtn = class_4185.method_46430(
            class_2561.method_43470("Reset to Default"),
            btn -> {
                int def = setting != null ? setting.getDefault() : originalValue;
                unpack(def); syncSliders(); syncHex();
            }
        ).method_46434(x, y, col, sh).method_46431();
        // Hide the "Reset to Default" button on the standalone path —
        // there's no meaningful "default" for a waypoint color.
        if (setting != null) method_37063(resetBtn);
        if (setting != null) y += sh + gap;

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Cancel"),
            btn -> {
                if (setting != null) setting.set(originalValue);
                field_22787.method_1507(parent);
            }
        ).method_46434(x, y, col, sh).method_46431());
    }

    private void syncSliders() {
        if (rSlider != null) rSlider.setValueQuiet(r);
        if (gSlider != null) gSlider.setValueQuiet(g);
        if (bSlider != null) bSlider.setValueQuiet(b);
    }

    private void syncHex() {
        if (hexField == null) return;
        String current = String.format("%02X%02X%02X", r, g, b);
        if (!current.equals(hexField.method_1882())) hexField.method_1852(current);
    }

    private void onHexChanged(String text) {
        if (text == null) return;
        String t = text.trim();
        if (t.startsWith("#")) t = t.substring(1);
        if (t.length() == 3) { // shorthand #abc -> #aabbcc
            StringBuilder sb = new StringBuilder();
            for (char c : t.toCharArray()) sb.append(c).append(c);
            t = sb.toString();
        }
        if (t.length() != 6) return;
        try {
            int parsed = Integer.parseInt(t, 16);
            int nr = (parsed >> 16) & 0xFF;
            int ng = (parsed >> 8) & 0xFF;
            int nb = parsed & 0xFF;
            if (nr == r && ng == g && nb == b) return;
            r = nr; g = ng; b = nb;
            syncSliders();
        } catch (NumberFormatException ignored) {}
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xD0070B14);
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Title
        ctx.method_27534(this.field_22793,
            class_2561.method_43470("§b§l" + displayLabel),
            this.field_22789 / 2, 22, 0xFFFFFFFF);
        ctx.method_27534(this.field_22793,
            class_2561.method_43470("§7Drag sliders or type a hex value"),
            this.field_22789 / 2, 38, 0xFFAAAAAA);

        // Big preview swatch under the header
        int swW = Math.min(320, this.field_22789 - 80);
        int swX = this.field_22789 / 2 - swW / 2;
        int swY = 52;
        int swH = 22;
        int color = pack();
        ctx.method_25294(swX - 1, swY - 1, swX + swW + 1, swY + swH + 1, 0xFF000000);
        ctx.method_25294(swX, swY, swX + swW, swY + swH, color);
        // Hex label on the swatch (contrasting)
        String hex = String.format("#%02X%02X%02X", r, g, b);
        int textColor = isLight(color) ? 0xFF000000 : 0xFFFFFFFF;
        ctx.method_27534(this.field_22793, class_2561.method_43470(hex),
            this.field_22789 / 2, swY + 7, textColor);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private static boolean isLight(int argb) {
        int rr = (argb >>> 16) & 0xFF;
        int gg = (argb >>> 8) & 0xFF;
        int bb = argb & 0xFF;
        // perceptual luminance
        return (0.299 * rr + 0.587 * gg + 0.114 * bb) > 160;
    }

    @Override
    public boolean method_25421() { return false; }

    // ── R/G/B slider widget ──────────────────────────────────
    interface ChannelCallback { void accept(int newVal); }

    static class RgbSlider extends class_357 {
        private final String channel;
        private final ChannelCallback onChange;

        RgbSlider(int x, int y, int w, int h, String channel, int initialByte, ChannelCallback onChange) {
            super(x, y, w, h, class_2561.method_43470(""), initialByte / 255.0);
            this.channel = channel;
            this.onChange = onChange;
            this.method_25346();
        }

        void setValueQuiet(int byteVal) {
            this.field_22753 = Math.max(0, Math.min(255, byteVal)) / 255.0;
            this.method_25346();
        }

        @Override
        protected void method_25346() {
            int v = (int) Math.round(this.field_22753 * 255.0);
            this.method_25355(class_2561.method_43470(channel + ": " + v));
        }

        @Override
        protected void method_25344() {
            int v = (int) Math.round(this.field_22753 * 255.0);
            if (onChange != null) onChange.accept(v);
        }
    }
}
