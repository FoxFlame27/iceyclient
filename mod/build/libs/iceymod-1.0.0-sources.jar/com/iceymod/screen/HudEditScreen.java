package com.iceymod.screen;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * HUD module-position editor.
 *
 * History note: this screen previously overrode {@code mouseClicked /
 * mouseDragged / mouseReleased} on Screen. In 1.21.11 those methods
 * were re-signatured to take a {@code Click} object instead of
 * {@code (double, double, int)}. Loom remaps method descriptors at
 * jar build time, so on 1.21.11 the @Override methods stop overriding
 * anything — they sit there as dead private methods, and dragging the
 * HUD silently no-ops.
 *
 * Fix: poll mouse state inside {@link #method_25394(class_332, int, int, float)}
 * (whose signature didn't change) and run a small click/drag/release
 * state machine ourselves. Works identically on 1.21.8 and 1.21.11.
 */
public class HudEditScreen extends class_437 {
    private final class_437 parent;
    private HudModule dragging = null;
    private int dragOffsetX, dragOffsetY;
    private boolean prevLeftDown = false;

    public HudEditScreen(class_437 parent) {
        super(class_2561.method_43470("Edit HUD"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.done"),
                btn -> method_25419()
        ).method_46434(this.field_22789 / 2 - 50, this.field_22790 - 28, 100, 20).method_46431());
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Skip vanilla blur (1.21.11 double-blur crash) - we draw our own overlay in render().
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Polled drag state machine — works regardless of version-specific
        // mouseClicked / mouseDragged / mouseReleased signature changes.
        try {
            updateDrag(mouseX, mouseY);
        } catch (Throwable ignored) {}

        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x80000000);

        context.method_25300(field_22793,
                "§b§lDrag modules to reposition", this.field_22789 / 2, 8, 0xFFFFFFFF);
        context.method_25300(field_22793,
                "§7Click and drag any module below", this.field_22789 / 2, 20, 0xFFFFFFFF);

        for (HudModule module : HudManager.getModules()) {
            if (!module.isEnabled()) continue;

            try { module.render(context, field_22787); } catch (Throwable ignored) {}

            int x = module.getX() - 2;
            int y = module.getY() - 2;
            int w = module.getWidth() + 4;
            int h = module.getHeight() + 4;

            boolean isHovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
            boolean isDragged = module == dragging;
            int borderColor = isDragged ? 0xFF5BC8F5 : isHovered ? 0xAAFFFFFF : 0x60FFFFFF;

            context.method_25294(x, y, x + w, y + 1, borderColor);
            context.method_25294(x, y + h - 1, x + w, y + h, borderColor);
            context.method_25294(x, y, x + 1, y + h, borderColor);
            context.method_25294(x + w - 1, y, x + w, y + h, borderColor);

            int labelColor = isDragged ? 0xFF5BC8F5 : 0xFFAAAAAA;
            context.method_25303(field_22793, module.getName(), x + 2, y - 11, labelColor);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    /**
     * Mouse drag state machine, polled each frame from render(). Reads
     * the left mouse button via raw GLFW (works on every MC version)
     * and the cursor via the mouseX/mouseY render args.
     */
    private void updateDrag(int mouseX, int mouseY) {
        class_310 c = class_310.method_1551();
        if (c == null || c.method_22683() == null) return;
        long handle = c.method_22683().method_4490();
        boolean leftDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        // Just-pressed → look for a module under cursor and begin drag.
        if (leftDown && !prevLeftDown && dragging == null) {
            // Only skip clicks landing on the actual Done button rect
            // (centered at bottom, 100x20). The previous "anywhere in
            // the bottom 32 px" skip blocked dragging modules positioned
            // near the bottom of the screen — including the default
            // Waypoints position on tall windows.
            int doneX = this.field_22789 / 2 - 50;
            int doneY = this.field_22790 - 28;
            boolean onDoneButton =
                    mouseX >= doneX && mouseX <= doneX + 100
                 && mouseY >= doneY && mouseY <= doneY + 20;
            if (!onDoneButton) {
                var modules = HudManager.getModules();
                for (int i = modules.size() - 1; i >= 0; i--) {
                    HudModule module = modules.get(i);
                    if (!module.isEnabled()) continue;
                    int x = module.getX() - 2;
                    int y = module.getY() - 2;
                    int w = module.getWidth() + 4;
                    int h = module.getHeight() + 4;
                    if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                        dragging = module;
                        dragOffsetX = mouseX - module.getX();
                        dragOffsetY = mouseY - module.getY();
                        break;
                    }
                }
            }
        }

        // Held → keep dragging.
        if (leftDown && dragging != null) {
            int newX = mouseX - dragOffsetX;
            int newY = mouseY - dragOffsetY;
            newX = Math.max(0, Math.min(newX, this.field_22789 - dragging.getWidth()));
            newY = Math.max(0, Math.min(newY, this.field_22790 - dragging.getHeight()));
            dragging.setX(newX);
            dragging.setY(newY);
        }

        // Just-released → drop.
        if (!leftDown && prevLeftDown) {
            dragging = null;
        }

        prevLeftDown = leftDown;
    }

    @Override
    public void method_25419() {
        HudManager.save();
        field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
