package com.iceymod.screen;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.BiomeLocatorModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.settings.BoolSetting;
import com.iceymod.structure.BiomeTracker;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Same UX as StructureMenuScreen, but for biomes. MAIN ▸ Find/Pause ·
 * Select Biomes · Waypoint · Delete · Clear All.
 */
public class BiomeMenuScreen extends class_437 {

    private enum State { MAIN, TYPES, WAYPOINT_LIST, DELETE_LIST }
    private State state = State.MAIN;

    public BiomeMenuScreen() {
        super(class_2561.method_43470("Biome Locator"));
    }

    private BiomeLocatorModule findModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof BiomeLocatorModule bm) return bm;
        }
        return null;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int btnW = 240;
        int btnH = 22;
        int gap = 6;

        switch (state) {
            case MAIN -> buildMain(cx, btnW, btnH, gap);
            case TYPES -> buildTypes(cx, btnW, btnH, gap);
            case WAYPOINT_LIST -> buildList(cx, btnW, btnH, gap, "§b✎ ", idx -> {
                List<BiomeTracker.Found> all = BiomeTracker.getSortedByDistance();
                if (idx >= 0 && idx < all.size()) {
                    BiomeTracker.Found f = all.get(idx);
                    WaypointManager.addWaypoint(f.type.label, f.pos.method_10263(), 64, f.pos.method_10260());
                }
                state = State.MAIN;
                rebuild();
            });
            case DELETE_LIST -> buildList(cx, btnW, btnH, gap, "§c✖ ", idx -> {
                List<BiomeTracker.Found> all = BiomeTracker.getSortedByDistance();
                if (idx >= 0 && idx < all.size()) BiomeTracker.remove(all.get(idx));
                if (BiomeTracker.getFound().isEmpty()) state = State.MAIN;
                rebuild();
            });
        }
    }

    private void buildMain(int cx, int btnW, int btnH, int gap) {
        BiomeLocatorModule mod = findModule();
        boolean scanning = mod != null && mod.isEnabled();
        int count = BiomeTracker.getFound().size();
        int y = this.field_22790 / 2 - 80;

        method_37063(class_4185.method_46430(
                class_2561.method_43470(scanning ? "§e⏸ Pause Finding" : "§a+ Find Biomes"),
                b -> {
                    if (mod != null) {
                        mod.setEnabled(!mod.isEnabled());
                        if (mod.isEnabled()) BiomeTracker.rescanNearby();
                    }
                    rebuild();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("§d☑ Select Biomes"),
                b -> { state = State.TYPES; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        class_4185 wpBtn = class_4185.method_46430(
                class_2561.method_43470("§b✎ Waypoint a Biome"),
                b -> { state = State.WAYPOINT_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        wpBtn.field_22763 = count > 0;
        method_37063(wpBtn);
        y += btnH + gap;

        class_4185 delBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Delete a Biome"),
                b -> { state = State.DELETE_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        delBtn.field_22763 = count > 0;
        method_37063(delBtn);
        y += btnH + gap;

        class_4185 clearBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Clear All"),
                b -> { BiomeTracker.clear(); BiomeTracker.rescanNearby(); this.method_25419(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        clearBtn.field_22763 = count > 0;
        method_37063(clearBtn);
        y += btnH + gap * 2;

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.cancel"),
                b -> this.method_25419()
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
    }

    private void buildTypes(int cx, int btnW, int btnH, int gap) {
        BiomeLocatorModule mod = findModule();
        if (mod == null) {
            state = State.MAIN; rebuild(); return;
        }
        BiomeTracker.BiomeType[] types = BiomeTracker.BiomeType.values();
        int colW = (btnW - gap) / 2;
        int rowsPerCol = (types.length + 1) / 2;
        int gridH = rowsPerCol * (btnH + gap);
        int y0 = this.field_22790 / 2 - gridH / 2 - 10;

        for (int i = 0; i < types.length; i++) {
            final BiomeTracker.BiomeType t = types[i];
            BoolSetting s = mod.getTypeSetting(t);
            if (s == null) continue;
            int col = i % 2;
            int row = i / 2;
            int bx = cx - btnW / 2 + col * (colW + gap);
            int by = y0 + row * (btnH + gap);
            String label = (s.get() ? "§a☑ " : "§7☐ ") + t.label;
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    b -> { s.set(!s.get()); BiomeTracker.rescanNearby(); rebuild(); }
            ).method_46434(bx, by, colW, btnH).method_46431());
        }

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Back"),
                b -> { state = State.MAIN; rebuild(); }
        ).method_46434(cx - btnW / 2, y0 + gridH + gap * 2, btnW, btnH).method_46431());
    }

    private void buildList(int cx, int btnW, int btnH, int gap, String prefix, java.util.function.IntConsumer onPick) {
        List<BiomeTracker.Found> all = BiomeTracker.getSortedByDistance();
        class_310 c = class_310.method_1551();
        int y = this.field_22790 / 2 - (all.size() * (btnH + gap)) / 2 - 20;
        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            BiomeTracker.Found f = all.get(i);
            int dist = 0;
            if (c != null && c.field_1724 != null) {
                double dx = f.pos.method_10263() - c.field_1724.method_23317();
                double dz = f.pos.method_10260() - c.field_1724.method_23321();
                dist = (int) Math.sqrt(dx * dx + dz * dz);
            }
            String label = prefix + "§r" + f.type.label + " §7(" + f.pos.method_10263() + ", " + f.pos.method_10260() + ") §8• §f" + dist + "m";
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    b -> onPick.accept(idx)
            ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
            y += btnH + gap;
        }
        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Back"),
                b -> { state = State.MAIN; rebuild(); }
        ).method_46434(cx - btnW / 2, y + gap, btnW, btnH).method_46431());
    }

    private void rebuild() { this.method_37067(); this.method_25426(); }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0101010);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        BiomeLocatorModule mod = findModule();
        boolean scanning = mod != null && mod.isEnabled();
        int count = BiomeTracker.getFound().size();
        String title = switch (state) {
            case MAIN -> "§a§lBiome Locator";
            case TYPES -> "§a§lSelect Biomes";
            case WAYPOINT_LIST -> "§a§lWaypoint a Biome";
            case DELETE_LIST -> "§a§lDelete a Biome";
        };
        context.method_25300(this.field_22793, title, this.field_22789 / 2, this.field_22790 / 2 - 110, 0xFFFFFFFF);
        String subtitle = "§7" + count + " found §8• §7scan: " + (scanning ? "§aon" : "§coff");
        context.method_25300(this.field_22793, subtitle, this.field_22789 / 2, this.field_22790 / 2 - 96, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25421() { return false; }
}
