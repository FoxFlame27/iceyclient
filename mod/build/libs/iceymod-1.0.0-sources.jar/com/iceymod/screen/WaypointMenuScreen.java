package com.iceymod.screen;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.modules.WaypointsModule;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Waypoint keybind menu. States:
 *   - MAIN: Set here / Rename / Edit coords / Delete / Delete all
 *   - *_LIST: pick a waypoint for the given action
 *   - RENAME_INPUT / EDIT_INPUT: input field(s) for the chosen waypoint
 */
public class WaypointMenuScreen extends class_437 {

    private enum State { MAIN, DELETE_LIST, RENAME_LIST, RENAME_INPUT, EDIT_LIST, EDIT_INPUT, COLOR_LIST }
    private State state = State.MAIN;
    private int actionIndex = -1;
    private class_342 nameInput;
    private class_342 xInput, yInput, zInput;

    public WaypointMenuScreen() {
        super(class_2561.method_43470("Waypoints"));
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int btnW = 220;
        int btnH = 22;
        int gap = 6;

        switch (state) {
            case MAIN -> buildMainMenu(cx, btnW, btnH, gap);
            case DELETE_LIST -> buildList(cx, btnW, btnH, gap, "§c✖ ", idx -> {
                WaypointManager.removeWaypoint(idx);
                if (WaypointManager.getWaypoints().isEmpty()) state = State.MAIN;
                rebuild();
            });
            case RENAME_LIST -> buildList(cx, btnW, btnH, gap, "§e✎ ", idx -> {
                actionIndex = idx;
                state = State.RENAME_INPUT;
                rebuild();
            });
            case EDIT_LIST -> buildList(cx, btnW, btnH, gap, "§b✎ ", idx -> {
                actionIndex = idx;
                state = State.EDIT_INPUT;
                rebuild();
            });
            case COLOR_LIST -> buildList(cx, btnW, btnH, gap, "§d🎨 ", idx -> {
                var list = WaypointManager.getWaypoints();
                if (idx < 0 || idx >= list.size()) return;
                WaypointManager.Waypoint wp = list.get(idx);
                final int targetIdx = idx;
                if (this.field_22787 != null) {
                    this.field_22787.method_1507(new ColorPickerScreen(
                            wp.color, "Waypoint Color: " + wp.name,
                            color -> WaypointManager.updateWaypointColor(targetIdx, color),
                            this));
                }
            });
            case RENAME_INPUT -> buildRenameInput(cx, btnW, btnH, gap);
            case EDIT_INPUT -> buildEditInput(cx, btnW, btnH, gap);
        }
    }

    private void buildMainMenu(int cx, int btnW, int btnH, int gap) {
        int y = this.field_22790 / 2 - 76;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("§a+ Set Waypoint Here"),
                b -> {
                    HudModule wp = findWaypointsModule();
                    if (wp instanceof WaypointsModule) {
                        wp.setEnabled(true);
                        ((WaypointsModule) wp).addCurrentPosition();
                    }
                    this.method_25419();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        class_4185 renBtn = class_4185.method_46430(
                class_2561.method_43470("§e✎ Rename Waypoint"),
                b -> { state = State.RENAME_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        renBtn.field_22763 = !WaypointManager.getWaypoints().isEmpty();
        method_37063(renBtn);
        y += btnH + gap;

        class_4185 editBtn = class_4185.method_46430(
                class_2561.method_43470("§b✎ Edit Coordinates"),
                b -> { state = State.EDIT_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        editBtn.field_22763 = !WaypointManager.getWaypoints().isEmpty();
        method_37063(editBtn);
        y += btnH + gap;

        class_4185 colorBtn = class_4185.method_46430(
                class_2561.method_43470("§d🎨 Recolor Waypoint"),
                b -> { state = State.COLOR_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        colorBtn.field_22763 = !WaypointManager.getWaypoints().isEmpty();
        method_37063(colorBtn);
        y += btnH + gap;

        class_4185 delBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Delete Waypoint"),
                b -> { state = State.DELETE_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        delBtn.field_22763 = !WaypointManager.getWaypoints().isEmpty();
        method_37063(delBtn);
        y += btnH + gap;

        class_4185 clearBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Delete All"),
                b -> {
                    int n = WaypointManager.getWaypoints().size();
                    for (int i = n - 1; i >= 0; i--) WaypointManager.removeWaypoint(i);
                    this.method_25419();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        clearBtn.field_22763 = !WaypointManager.getWaypoints().isEmpty();
        method_37063(clearBtn);
        y += btnH + gap * 2;

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.cancel"),
                b -> this.method_25419()
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
    }

    private void buildList(int cx, int btnW, int btnH, int gap, String prefix, java.util.function.IntConsumer onPick) {
        List<WaypointManager.Waypoint> wps = WaypointManager.getWaypoints();
        int y = this.field_22790 / 2 - (wps.size() * (btnH + gap)) / 2 - 20;

        for (int i = 0; i < wps.size(); i++) {
            final int idx = i;
            WaypointManager.Waypoint wp = wps.get(i);
            String label = prefix + "§r" + wp.name + " §7(" + wp.x + ", " + wp.y + ", " + wp.z + ")";
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    b -> onPick.accept(idx)
            ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
            y += btnH + gap;
        }

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Back"),
                b -> { state = State.MAIN; rebuild(); }
        ).method_46434(cx - btnW / 2, y + gap, btnW, btnH).method_46431());
    }

    private void buildRenameInput(int cx, int btnW, int btnH, int gap) {
        if (actionIndex < 0 || actionIndex >= WaypointManager.getWaypoints().size()) {
            state = State.MAIN;
            rebuild();
            return;
        }
        WaypointManager.Waypoint wp = WaypointManager.getWaypoints().get(actionIndex);
        int y = this.field_22790 / 2 - 20;

        nameInput = new class_342(this.field_22793, cx - btnW / 2, y, btnW, btnH, class_2561.method_43470(""));
        nameInput.method_1880(32);
        nameInput.method_1852(wp.name);
        nameInput.method_25365(true);
        method_37063(nameInput);
        method_48265(nameInput);

        y += btnH + gap;
        method_37063(class_4185.method_46430(
                class_2561.method_43470("§aSave"),
                b -> commitRename()
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Cancel"),
                b -> {
                    actionIndex = -1;
                    state = State.RENAME_LIST;
                    rebuild();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
    }

    private void buildEditInput(int cx, int btnW, int btnH, int gap) {
        if (actionIndex < 0 || actionIndex >= WaypointManager.getWaypoints().size()) {
            state = State.MAIN;
            rebuild();
            return;
        }
        WaypointManager.Waypoint wp = WaypointManager.getWaypoints().get(actionIndex);
        int y = this.field_22790 / 2 - 40;
        int fieldW = btnW / 3 - 4;

        // Three side-by-side X Y Z fields
        int fx = cx - btnW / 2;
        xInput = new class_342(this.field_22793, fx, y, fieldW, btnH, class_2561.method_43470(""));
        xInput.method_1852(String.valueOf(wp.x));
        xInput.method_1880(8);
        method_37063(xInput);

        yInput = new class_342(this.field_22793, fx + fieldW + 6, y, fieldW, btnH, class_2561.method_43470(""));
        yInput.method_1852(String.valueOf(wp.y));
        yInput.method_1880(8);
        method_37063(yInput);

        zInput = new class_342(this.field_22793, fx + (fieldW + 6) * 2, y, fieldW, btnH, class_2561.method_43470(""));
        zInput.method_1852(String.valueOf(wp.z));
        zInput.method_1880(8);
        method_37063(zInput);

        method_48265(xInput);

        y += btnH + gap;
        method_37063(class_4185.method_46430(
                class_2561.method_43470("§eUse My Current Position"),
                b -> {
                    class_310 c = class_310.method_1551();
                    if (c != null && c.field_1724 != null) {
                        xInput.method_1852(String.valueOf((int) c.field_1724.method_23317()));
                        yInput.method_1852(String.valueOf((int) c.field_1724.method_23318()));
                        zInput.method_1852(String.valueOf((int) c.field_1724.method_23321()));
                    }
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("§aSave"),
                b -> commitEdit()
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Cancel"),
                b -> {
                    actionIndex = -1;
                    state = State.EDIT_LIST;
                    rebuild();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
    }

    private void commitRename() {
        WaypointManager.renameWaypoint(actionIndex, nameInput.method_1882());
        actionIndex = -1;
        state = State.MAIN;
        rebuild();
    }

    private void commitEdit() {
        try {
            int x = Integer.parseInt(xInput.method_1882().trim());
            int y = Integer.parseInt(yInput.method_1882().trim());
            int z = Integer.parseInt(zInput.method_1882().trim());
            WaypointManager.updateWaypointCoords(actionIndex, x, y, z);
            actionIndex = -1;
            state = State.MAIN;
            rebuild();
        } catch (NumberFormatException e) {
            // Leave the input visible so the user can fix it.
        }
    }

    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    private HudModule findWaypointsModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m.getId().equals("waypoints")) return m;
        }
        return null;
    }

    // 1.21.11 changed Screen.keyPressed's signature so our (int,int,int)
    // override stops firing. Poll Enter via raw GLFW in render() with
    // edge detection — works on both 1.21.8 and 1.21.11.
    private boolean prevEnterDown = false;

    private void pollEnter() {
        try {
            long handle = field_22787.method_22683().method_4490();
            boolean down = org.lwjgl.glfw.GLFW.glfwGetKey(handle, org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            if (down && !prevEnterDown) {
                if (state == State.RENAME_INPUT && nameInput != null) { commitRename(); }
                else if (state == State.EDIT_INPUT && xInput != null) { commitEdit(); }
            }
            prevEnterDown = down;
        } catch (Throwable ignored) {}
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0101010);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        pollEnter();
        super.method_25394(context, mouseX, mouseY, delta);
        String title = switch (state) {
            case MAIN -> "§b§lWaypoints";
            case DELETE_LIST -> "§b§lDelete Waypoint";
            case RENAME_LIST -> "§b§lRename Waypoint";
            case EDIT_LIST -> "§b§lEdit Coordinates";
            case RENAME_INPUT -> "§b§lNew Name";
            case EDIT_INPUT -> "§b§lEdit Coordinates";
            case COLOR_LIST -> "§d§lRecolor Waypoint";
        };
        context.method_25300(this.field_22793, title, this.field_22789 / 2, this.field_22790 / 2 - 110, 0xFFFFFFFF);
        if (state != State.RENAME_INPUT && state != State.EDIT_INPUT) {
            String subtitle = "§7" + WaypointManager.getWaypoints().size() + " saved";
            context.method_25300(this.field_22793, subtitle, this.field_22789 / 2, this.field_22790 / 2 - 96, 0xFFAAAAAA);
        }
    }

    @Override
    public boolean method_25421() { return false; }
}
