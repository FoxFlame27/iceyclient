package com.iceymod.screen;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.StructureLocatorModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.settings.BoolSetting;
import com.iceymod.structure.StructureTracker;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Structure Locator menu — same state-machine shape as WaypointMenuScreen
 * so the UX matches.
 *
 *   MAIN  ▸ Start/Pause · Waypoint it · Delete · Clear all · Close
 *   WAYPOINT_LIST ▸ pick → sends to WaypointManager
 *   DELETE_LIST   ▸ pick → remove from tracker
 */
public class StructureMenuScreen extends class_437 {

    private enum State { MAIN, WAYPOINT_LIST, DELETE_LIST, TYPES }
    private State state = State.MAIN;

    public StructureMenuScreen() {
        super(class_2561.method_43470("Structure Locator"));
    }

    private StructureLocatorModule findModule() {
        for (HudModule m : HudManager.getModules()) {
            if (m instanceof StructureLocatorModule sm) return sm;
        }
        return null;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int btnW = 240;
        int btnH = 22;
        int gap = 6;

        switch (state) {
            case MAIN -> buildMain(cx, btnW, btnH, gap);
            case TYPES -> buildTypes(cx, btnW, btnH, gap);
            case WAYPOINT_LIST -> buildList(cx, btnW, btnH, gap, "§b✎ ", idx -> {
                List<StructureTracker.Found> all = StructureTracker.getSortedByDistance();
                if (idx >= 0 && idx < all.size()) {
                    StructureTracker.Found f = all.get(idx);
                    WaypointManager.addWaypoint(f.type.label, f.pos.method_10263(), f.pos.method_10264(), f.pos.method_10260());
                }
                state = State.MAIN;
                rebuild();
            });
            case DELETE_LIST -> buildList(cx, btnW, btnH, gap, "§c✖ ", idx -> {
                List<StructureTracker.Found> all = StructureTracker.getSortedByDistance();
                if (idx >= 0 && idx < all.size()) {
                    StructureTracker.Found f = all.get(idx);
                    StructureTracker.remove(f);
                }
                if (StructureTracker.getFound().isEmpty()) state = State.MAIN;
                rebuild();
            });
        }
    }

    private void buildMain(int cx, int btnW, int btnH, int gap) {
        StructureLocatorModule mod = findModule();
        boolean scanning = mod != null && mod.isEnabled();
        int count = StructureTracker.getFound().size();
        int y = this.field_22790 / 2 - 80;

        String scanLabel = scanning ? "§e⏸ Pause Finding" : "§a+ Find New Structures";
        method_37063(class_4185.method_46430(
                class_2561.method_43470(scanLabel),
                b -> {
                    if (mod != null) {
                        boolean turningOn = !mod.isEnabled();
                        mod.setEnabled(turningOn);
                        if (turningOn) StructureTracker.rescanNearby();
                    }
                    rebuild();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("§d☑ Select Structures"),
                b -> { state = State.TYPES; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += btnH + gap;


        class_4185 wpBtn = class_4185.method_46430(
                class_2561.method_43470("§b✎ Waypoint a Structure"),
                b -> { state = State.WAYPOINT_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        wpBtn.field_22763 = count > 0;
        method_37063(wpBtn);
        y += btnH + gap;

        class_4185 delBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Delete a Structure"),
                b -> { state = State.DELETE_LIST; rebuild(); }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        delBtn.field_22763 = count > 0;
        method_37063(delBtn);
        y += btnH + gap;

        class_4185 clearBtn = class_4185.method_46430(
                class_2561.method_43470("§c✖ Clear All"),
                b -> {
                    StructureTracker.clear();
                    // Re-sweep currently-loaded chunks so anything still in
                    // range shows back up — otherwise the HUD gets stuck on
                    // "Scanning chunks…" until the player walks to new chunks.
                    StructureTracker.rescanNearby();
                    this.method_25419();
                }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431();
        clearBtn.field_22763 = count > 0;
        method_37063(clearBtn);
        y += btnH + gap * 2;

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.cancel"),
                b -> this.method_25419()
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
    }

    /**
     * Two-column grid of toggle buttons, one per structure type. Pressing
     * a button flips the corresponding BoolSetting and re-renders. New
     * findings start respecting the toggle on the next chunk scan.
     */
    private void buildTypes(int cx, int btnW, int btnH, int gap) {
        StructureLocatorModule mod = findModule();
        if (mod == null) {
            state = State.MAIN;
            rebuild();
            return;
        }

        record Row(String label, BoolSetting setting) {}
        Row[] rows = new Row[] {
                new Row("Trial Chambers",   mod.trialChambers),
                new Row("Strongholds",      mod.strongholds),
                new Row("Player Bases",     mod.playerBases),
                new Row("Nether Fortresses",mod.netherFortresses),
                new Row("Bastion Remnants", mod.bastions),
                new Row("End Cities",       mod.endCities),
                new Row("End Gateways",     mod.endGateways),
                new Row("Ocean Monuments",  mod.oceanMonuments),
                new Row("Ancient Cities",   mod.ancientCities),
                new Row("Ruined Portals",   mod.ruinedPortals),
                new Row("Desert Pyramids",  mod.desertPyramids),
                new Row("Villages",         mod.villages)
        };

        int colW = (btnW - gap) / 2;
        int rowsPerCol = (rows.length + 1) / 2;
        int gridH = rowsPerCol * (btnH + gap);
        int y0 = this.field_22790 / 2 - gridH / 2 - 10;

        for (int i = 0; i < rows.length; i++) {
            final Row r = rows[i];
            int col = i % 2;
            int row = i / 2;
            int bx = cx - btnW / 2 + col * (colW + gap);
            int by = y0 + row * (btnH + gap);
            String label = (r.setting().get() ? "§a☑ " : "§7☐ ") + r.label();
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    b -> {
                        r.setting().set(!r.setting().get());
                        StructureTracker.rescanNearby();
                        rebuild();
                    }
            ).method_46434(bx, by, colW, btnH).method_46431());
        }

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Back"),
                b -> { state = State.MAIN; rebuild(); }
        ).method_46434(cx - btnW / 2, y0 + gridH + gap * 2, btnW, btnH).method_46431());
    }

    private void buildList(int cx, int btnW, int btnH, int gap, String prefix, java.util.function.IntConsumer onPick) {
        List<StructureTracker.Found> all = StructureTracker.getSortedByDistance();
        class_310 c = class_310.method_1551();
        int y = this.field_22790 / 2 - (all.size() * (btnH + gap)) / 2 - 20;

        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            StructureTracker.Found f = all.get(i);
            int dist = 0;
            if (c != null && c.field_1724 != null) {
                double dx = f.pos.method_10263() - c.field_1724.method_23317();
                double dy = f.pos.method_10264() - c.field_1724.method_23318();
                double dz = f.pos.method_10260() - c.field_1724.method_23321();
                dist = (int) Math.sqrt(dx * dx + dy * dy + dz * dz);
            }
            String label = prefix + "§r" + f.type.label + " §7(" + f.pos.method_10263() + ", " + f.pos.method_10264() + ", " + f.pos.method_10260() + ") §8• §f" + dist + "m";
            method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    b -> onPick.accept(idx)
            ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
            y += btnH + gap;
        }

        method_37063(class_4185.method_46430(
                class_2561.method_43470("← Back"),
                b -> { state = State.MAIN; rebuild(); }
        ).method_46434(cx - btnW / 2, y + gap, btnW, btnH).method_46431());
    }

    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0101010);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        StructureLocatorModule mod = findModule();
        boolean scanning = mod != null && mod.isEnabled();
        int count = StructureTracker.getFound().size();

        String title = switch (state) {
            case MAIN -> "§b§lStructure Locator";
            case TYPES -> "§b§lSelect Structures";
            case WAYPOINT_LIST -> "§b§lWaypoint a Structure";
            case DELETE_LIST -> "§b§lDelete a Structure";
        };
        context.method_25300(this.field_22793, title, this.field_22789 / 2, this.field_22790 / 2 - 110, 0xFFFFFFFF);
        String subtitle = "§7" + count + " found §8• §7scan: " + (scanning ? "§aon" : "§coff");
        context.method_25300(this.field_22793, subtitle, this.field_22789 / 2, this.field_22790 / 2 - 96, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25421() { return false; }
}
