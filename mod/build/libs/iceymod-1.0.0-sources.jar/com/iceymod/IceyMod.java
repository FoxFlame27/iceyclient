package com.iceymod;

import com.iceymod.hud.HudManager;
import com.iceymod.hud.HudModule;
import com.iceymod.hud.modules.FreecamModule;
import com.iceymod.hud.modules.FreelookModule;
import com.iceymod.hud.modules.PerspectiveModule;
import com.iceymod.hud.modules.WaypointManager;
import com.iceymod.hud.modules.WaypointsModule;
import com.iceymod.hud.modules.ZoomModule;
import com.iceymod.screen.IceyModScreen;
import com.iceymod.screen.StructureMenuScreen;
import com.iceymod.screen.WaypointMenuScreen;
import com.iceymod.structure.StructureTracker;
import com.iceymod.structure.BiomeTracker;
import com.iceymod.screen.BiomeMenuScreen;
import com.iceymod.chat.ChatCoordParser;
import com.iceymod.render.WaypointBeamRenderer;
import com.iceymod.render.HitboxRenderer;
import com.iceymod.render.MinimapRenderer;
import com.iceymod.compat.KeyBindingCompat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

public class IceyMod implements ClientModInitializer {
    public static final String MOD_ID = "iceymod";
    public static final class_2960 LOGO_TEXTURE = class_2960.method_60655(MOD_ID, "textures/gui/logo.png");
    public static final String KEY_CATEGORY = "key.categories.iceymod";

    private static class_304 menuKey;
    private static class_304 zoomKey;
    private static class_304 perspectiveKey;
    private static class_304 waypointKey;
    private static class_304 hideHudKey;
    private static class_304 toggleSprintKey;
    private static class_304 toggleBrightKey;
    private static class_304 toggleTotemKey;
    private static class_304 freelookKey;
    private static class_304 copyCoordsKey;
    private static class_304 structureKey;
    private static class_304 freecamKey;
    private static class_304 biomeKey;

    @Override
    public void onInitializeClient() {
        HudManager.init();
        WaypointManager.init();
        WaypointBeamRenderer.register();
        HitboxRenderer.register();
        MinimapRenderer.register();
        StructureTracker.register();
        BiomeTracker.register();
        ChatCoordParser.register();

        menuKey         = registerKey("key.iceymod.menu",         GLFW.GLFW_KEY_Y);
        zoomKey         = registerKey("key.iceymod.zoom",         GLFW.GLFW_KEY_M);
        perspectiveKey  = registerKey("key.iceymod.perspective",  GLFW.GLFW_KEY_R);
        waypointKey     = registerKey("key.iceymod.waypoint",     GLFW.GLFW_KEY_B);
        hideHudKey      = registerKey("key.iceymod.hidehud",      GLFW.GLFW_KEY_H);
        toggleSprintKey = registerKey("key.iceymod.togglesprint", GLFW.GLFW_KEY_N);
        toggleBrightKey = registerKey("key.iceymod.togglebright", GLFW.GLFW_KEY_G);
        toggleTotemKey  = registerKey("key.iceymod.toggletotem",  GLFW.GLFW_KEY_T);
        freelookKey     = registerKey("key.iceymod.freelook",     GLFW.GLFW_KEY_LEFT_ALT);
        copyCoordsKey   = registerKey("key.iceymod.copycoords",   GLFW.GLFW_KEY_J);
        structureKey    = registerKey("key.iceymod.structure",    GLFW.GLFW_KEY_V);
        freecamKey      = registerKey("key.iceymod.freecam",      GLFW.GLFW_KEY_F4);
        biomeKey        = registerKey("key.iceymod.biome",        GLFW.GLFW_KEY_K);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (wasPressed(menuKey)) {
                if (client.field_1755 == null) {
                    client.method_1507(new IceyModScreen());
                }
            }
            while (wasPressed(perspectiveKey)) {
                HudModule pm = findModule("perspective");
                if (pm instanceof PerspectiveModule) {
                    ((PerspectiveModule) pm).cyclePerspective();
                }
            }
            while (wasPressed(waypointKey)) {
                if (client.field_1755 == null) {
                    client.method_1507(new WaypointMenuScreen());
                }
            }
            while (wasPressed(structureKey)) {
                if (client.field_1755 == null) {
                    client.method_1507(new StructureMenuScreen());
                }
            }
            while (wasPressed(biomeKey)) {
                if (client.field_1755 == null) {
                    client.method_1507(new BiomeMenuScreen());
                }
            }
            while (wasPressed(freecamKey)) {
                HudModule fc = findModule("freecam");
                if (fc instanceof FreecamModule fcm) {
                    fcm.toggle(client);
                }
            }
            while (wasPressed(hideHudKey)) {
                HudManager.toggleHudVisibility();
            }
            while (wasPressed(toggleSprintKey)) {
                HudModule m = findModule("autosprint");
                if (m != null) m.toggle();
            }
            while (wasPressed(toggleBrightKey)) {
                HudModule m = findModule("fullbright");
                if (m != null) m.toggle();
            }
            while (wasPressed(toggleTotemKey)) {
                HudModule m = findModule("autototem");
                if (m != null) m.toggle();
            }

            // Zoom: hold key
            HudModule zm = findModule("zoom");
            if (zm instanceof ZoomModule) {
                ((ZoomModule) zm).setZooming(isPressed(zoomKey));
            }

            // Freelook: hold key — camera rotates while character keeps facing forward
            HudModule fl = findModule("freelook");
            if (fl instanceof FreelookModule flm) {
                boolean shouldBeActive = fl.isEnabled() && isPressed(freelookKey);
                if (shouldBeActive && !FreelookModule.isActive()) {
                    flm.start(client);
                    if (client.field_1724 != null) {
                        client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§b[Icey] §aFreelook ON"), true);
                    }
                } else if (!shouldBeActive && FreelookModule.isActive()) {
                    flm.stop(client);
                    if (client.field_1724 != null) {
                        client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§b[Icey] §7Freelook off"), true);
                    }
                }
            }

            // Copy coords to clipboard on key press
            while (wasPressed(copyCoordsKey)) {
                if (client.field_1724 != null) {
                    int x = (int) Math.floor(client.field_1724.method_23317());
                    int y = (int) Math.floor(client.field_1724.method_23318());
                    int z = (int) Math.floor(client.field_1724.method_23321());
                    String coords = x + ", " + y + ", " + z;
                    client.field_1774.method_1455(coords);
                    client.field_1724.method_7353(
                            net.minecraft.class_2561.method_43470("\u00A7b[Icey] \u00A7rCopied \u00A7a" + coords),
                            true); // actionBar overlay — doesn't spam chat
                }
            }

            HudManager.tick();
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && (client.field_1755 == null
                    || client.field_1755 instanceof net.minecraft.class_408)) {
                HudManager.render(drawContext);
            }
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            // Title screen: no extra corner logo — the Icey Client logo is already drawn
            // in place of the vanilla MINECRAFT logo by LogoDrawerMixin.

            if (screen instanceof class_465) {
                ScreenEvents.afterRender(screen).register((scr, ctx, mouseX, mouseY, delta) -> {
                    // Skip brewing stands — tight layout, text overlaps the window
                    if (scr instanceof net.minecraft.class_472) return;
                    // Skip double chests — taller window pushes the text too far down
                    if (scr instanceof net.minecraft.class_476 gcs
                            && gcs.method_17577().method_17388() == 6) return;

                    int sw = client.method_22683().method_4486();
                    int windowTop = (scr.field_22790 - 166) / 2;
                    int y = Math.max(2, windowTop - 14);
                    ctx.method_27534(
                            client.field_1772,
                            net.minecraft.class_2561.method_43470("\u00A7b\u00A7lIcey Client"),
                            sw / 2, y,
                            0xFFFFFFFF
                    );
                });
            }
        });
    }

    private static HudModule findModule(String id) {
        for (HudModule m : HudManager.getModules()) {
            if (m.getId().equals(id)) return m;
        }
        return null;
    }

    /**
     * Register a key via the compat helper so versions that removed the
     * (String, Type, int, String) KeyBinding constructor don't crash the mod.
     * Returns null if registration fails — all call sites null-check.
     */
    private static class_304 registerKey(String translationKey, int code) {
        try {
            class_304 kb = KeyBindingCompat.create(translationKey, class_3675.class_307.field_1668, code, KEY_CATEGORY);
            if (kb == null) return null;
            return KeyBindingHelper.registerKeyBinding(kb);
        } catch (Throwable t) {
            System.out.println("[IceyMod] Failed to register key " + translationKey + ": " + t.getMessage());
            return null;
        }
    }

    private static boolean wasPressed(class_304 kb) {
        if (kb == null) return false;
        try { return kb.method_1436(); } catch (Throwable t) { return false; }
    }

    private static boolean isPressed(class_304 kb) {
        if (kb == null) return false;
        try { return kb.method_1434(); } catch (Throwable t) { return false; }
    }
}
