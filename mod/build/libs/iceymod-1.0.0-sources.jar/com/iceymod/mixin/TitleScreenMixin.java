package com.iceymod.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder mixin — we no longer override renderBackground, since the
 * nether panorama resource pack provides the textures and we want the
 * vanilla rotating cubemap renderer to use them.
 * Kept as a mixin target for future title-screen tweaks.
 */
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }
}
