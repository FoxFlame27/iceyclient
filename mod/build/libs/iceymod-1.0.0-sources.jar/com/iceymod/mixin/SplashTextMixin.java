package com.iceymod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_4008;
import net.minecraft.class_8519;

/**
 * Replaces the rotating yellow splash text on the title screen with
 * Icey Client–themed one-liners. Cancels the vanilla logic and supplies
 * a fresh random splash each time TitleScreen asks for one.
 */
@Mixin(class_4008.class)
public abstract class SplashTextMixin {

    private static final String[] ICEY_SPLASHES = {
        "icecold!",
        "brrrr!",
        "chilled to perfection!",
        "frostbite ready!",
        "no two snowflakes alike!",
        "permafrost certified!",
        "winter is coming!",
        "freeze tag!",
        "ice ice baby!",
        "subzero!",
        "arctic grade!",
        "Frosty the Snowman approves",
        "snow way!",
        "glacier pace!",
        "hypothermia incoming!",
        "iced out!",
        "cold as space!",
        "frozen solid!",
        "blizzard mode!",
        "icicle approved!",
        "powder day!",
        "cryo-ready!",
        "penguins love it!",
        "northern lights!",
        "quick freeze!",
        "cooler than you!",
        "cold takes only!",
        "minus forty!",
        "keep your cool!"
    };

    @Inject(method = "get", at = @At("HEAD"), cancellable = true, require = 0, expect = 0)
    private void iceymod$iceySplash(CallbackInfoReturnable<class_8519> cir) {
        try {
            String text = ICEY_SPLASHES[ThreadLocalRandom.current().nextInt(ICEY_SPLASHES.length)];
            cir.setReturnValue(new class_8519(text));
        } catch (Throwable ignored) {
            // SplashTextRenderer's constructor signature changed in 1.21.11 —
            // fall through to vanilla splash text rather than crash.
        }
    }
}
