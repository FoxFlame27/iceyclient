package com.iceymod.mixin;

import com.iceymod.hud.modules.FreecamModule;
import com.iceymod.hud.modules.FreelookModule;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While freelook is active, reroute mouse-delta updates away from the
 * client player's yaw/pitch and into FreelookModule's camera state.
 * Non-player entities are unaffected.
 */
@Mixin(class_1297.class)
public abstract class EntityLookMixin {

    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0, expect = 0)
    private void iceymod$freelook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        try {
            class_1297 self = (class_1297) (Object) this;
            class_310 client = class_310.method_1551();
            if (client == null || self != client.field_1724) return;

            // Freecam takes priority — mouse rotates the detached camera,
            // not the player.
            if (FreecamModule.isActive()) {
                FreecamModule.applyDelta(cursorDeltaX, cursorDeltaY);
                ci.cancel();
                return;
            }
            if (FreelookModule.isActive()) {
                FreelookModule.applyDelta(cursorDeltaX, cursorDeltaY);
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }
}
