package com.iceymod.mixin;

import com.iceymod.hud.modules.FreecamModule;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While freecam is active, zero out the keyboard-driven player input so
 * vanilla doesn't try to walk the real player around (W still feeds the
 * camera in FreecamModule.tick — both can read the same key state, but
 * only the camera should ACT on it). Otherwise the player would walk
 * out from under the freecam, possibly into lava.
 */
@Mixin(class_743.class)
public abstract class KeyboardInputMixin extends class_744 {

    @Inject(method = "tick", at = @At("TAIL"), require = 0, expect = 0)
    private void iceymod$freecamSuppressInput(CallbackInfo ci) {
        try {
            if (FreecamModule.isActive()) {
                this.field_54155 = class_10185.field_54098;
                this.field_55868 = class_241.field_1340;
            }
        } catch (Throwable ignored) {}
    }
}
