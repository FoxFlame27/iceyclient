package com.iceymod.mixin;

import com.iceymod.hud.modules.FreecamModule;
import com.iceymod.hud.modules.FreelookModule;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Overrides the camera's rotation with FreelookModule's values after
 * Camera.update() so the rendered view uses the free look direction
 * instead of the entity's real yaw/pitch.
 */
@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Shadow
    protected abstract void setPos(double x, double y, double z);

    // require=0, expect=0 so this mixin silently no-ops on MC versions
    // where Camera.update's signature changed — game still boots, just
    // without freelook/freecam rendering.
    @Inject(method = "update", at = @At("RETURN"), require = 0, expect = 0)
    private void iceymod$applyFreelook(class_1922 world, class_1297 focused, boolean thirdPerson,
                                       boolean inverseView, float tickDelta, CallbackInfo ci) {
        try {
            // Freecam takes precedence over freelook — both override
            // rotation, but freecam ALSO overrides position. Run the
            // per-frame movement update HERE (not in tick) so motion
            // is smooth at render rate instead of stepping at 20 Hz.
            if (FreecamModule.isActive()) {
                FreecamModule.updatePerFrame();
                setPos(FreecamModule.camX(), FreecamModule.camY(), FreecamModule.camZ());
                setRotation(FreecamModule.camYaw(), FreecamModule.camPitch());
                return;
            }
            if (FreelookModule.isRendering() && focused != null) {
                float playerYaw = focused.method_5705(tickDelta);
                float playerPitch = focused.method_5695(tickDelta);
                setRotation(
                    FreelookModule.getRenderYaw(playerYaw),
                    FreelookModule.getRenderPitch(playerPitch)
                );
            }
        } catch (Throwable ignored) {
            // Entity.getYaw / setRotation / setPos could shift between
            // versions — silently skip rather than crash the render pass.
        }
    }
}
