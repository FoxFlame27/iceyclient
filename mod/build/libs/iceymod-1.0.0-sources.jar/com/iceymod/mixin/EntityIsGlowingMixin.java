package com.iceymod.mixin;

import com.iceymod.hud.modules.ItemGlowModule;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Make selected dropped items glow client-side. Server-side glow flag
 * is unchanged — this just overrides the local return value of
 * {@code Entity.isGlowing()} so the vanilla outline-render kicks in
 * for our targets. Same on-screen effect as a Glowing potion or a
 * spectral arrow hit, but local-only and free.
 */
@Mixin(class_1297.class)
public abstract class EntityIsGlowingMixin {

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true, require = 0, expect = 0)
    private void iceymod$forceGlow(CallbackInfoReturnable<Boolean> cir) {
        try {
            class_1297 self = (class_1297) (Object) this;
            if (self instanceof class_1542 item && ItemGlowModule.shouldGlow(item)) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {
            // Item / Items class drift across versions could throw —
            // never let glow logic kill the render frame.
        }
    }
}
